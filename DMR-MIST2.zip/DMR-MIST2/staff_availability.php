<?php
session_start();
$user_id = $_POST['user_id'];

include('dbconnect.php');

$sql = mysql_query("SELECT `status` FROM `staff` WHERE `user_id` = '$user_id' AND `status` = 'AVAILABLE'")or die("Fatal Error");
$rows = @mysql_num_rows($sql);

if($rows ==0)
{
?>
<script type="text/javascript">
alert("<?php echo $user_id;?> staff is not available at the moment");
window.close;
</script>
<?php
}
else
{
?> 
<script type="text/javascript">
alert("<?php echo $user_id;?> staff is currently available");
window.close;
<?php
}
?>