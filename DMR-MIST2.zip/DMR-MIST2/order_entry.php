<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 

<?php

$hospital_no = addslashes($_POST['hospital_no']);

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no`,`fname`,`lname`,`date_of_birth`,`sex`,`occupation`,`next_of_kin`,`phone`,`email`,`address` FROM patients WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows<1)
{
?>
<script type="text/javascript">
alert("Sorry! Patient records not found on this date");
window.location = "medical_consultant_page.php");
</script>
<?php  
exit();
}
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Computerized Physician Order Entry::</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #000033;
	font-weight: bold;
}
.style1 {
	font-size: 12px;
	color: #FF0000;
}
.style3 {font-size: 12px}
.style4 {font-size: 9px}
.style6 {font-size: 9px; color: #000033; }

-->
</style></head>

<body>
<p>Computerized Physician Order Entry</p>
<hr />
<span class="style1">PRESCRIPTION <span class="style6" style="cursor:pointer" onClick="toggleInfo('ans0');">[+]</span></span><br />
<table width="888" align="center">
  <tr>
    <td><div id="ans0">
      <table width="820" height="82" align="center">
        <tr>
          <td valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	$count = 0;
	include('dbconnect.php');
	$query = mysql_query("SELECT `date_added`,`prescribtion_no`,`repeat`,`doctor`,`status`,`number`,`financial_status` FROM `prescribtion` WHERE `hospital_no` = '$hospital_no'")or die("Error");
	$sql = @mysql_num_rows($query);
	if($sql==0)
	{
	 echo "NO RECORDS FOUND";
	} 
	else
	{
	$query1 = mysql_query("SELECT `prescribtion` FROM `prescribtions` WHERE `hospital_no` = '$hospital_no'");
	$query2 = mysql_query("SELECT `price` FROM `prescribtions` WHERE `hospital_no` = '$hospital_no'");
	$query3 = mysql_query("SELECT `dosage` FROM `prescribtions` WHERE `hospital_no` = '$hospital_no'");
	echo "<html>";
	echo "<table width=800 border=1>";
	echo "<tr>";
	echo "<td><strong>Date </strong></td>
        <td><strong>Prescription Number </strong></td>
        <td><strong>Repeat </strong></td>
        <td><strong>Doctor </strong></td>
        <td><strong>Status</strong></td>
        <td><strong>Number of Items</strong></td>
        <td><strong>Financial Status </strong></td>
		<td><strong>Items </strong></td>
		<td><strong>Price </strong></td>
		<td><strong>Dosage </strong></td>
        </tr>";
	while($rows = @mysql_fetch_array($query, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 	}
	echo "<td class = style2>";
	while ($rows = @mysql_fetch_array($query1, MYSQL_ASSOC))
{

while( list ($key, $value) = each($rows) )
{
echo "*".$value.'<br>';
}
}
echo "</td>";
echo "<td class = style2>";
	while ($rows = @mysql_fetch_array($query2, MYSQL_ASSOC))
{

while( list ($key, $value) = each($rows) )
{
echo $value.'<br>';
$cost = $value;
}
$total = $total+$cost;
}
echo "</td>";
echo "<td class = style2>";
	while ($rows = @mysql_fetch_array($query3, MYSQL_ASSOC))
{

while( list ($key, $value) = each($rows) )
{
echo "*".$value.'<br>';
}
}
echo "</td>";
echo "</tr>";
	echo "</table></html>"; 
	}?>
            </p>
              <p>&nbsp;</p>
            <p>TOTAL AMOUNT = <?php echo $total;?> Naira </p>
            </td>
        </tr>
      </table>
      <hr />
      <p class="style3">WRITTEN PRESCRIPTION </p>
      <table width="820" height="82" align="center">
        <tr>
          <td width="414" valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky = mysql_query("SELECT `prescription` FROM `written_prescription` WHERE `hospital_no` = '$hospital_no'")or die("Fatal Error");
   $viky2 = mysql_query("SELECT `date_added` FROM `written_prescription` WHERE `hospital_no` = '$hospital_no'")or die("Lucy Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PRESCRIPTION RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Examination</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2><a href=prescription/$col_value>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
	echo "</table></html>"; 
	
	
	
	}?>
          </p></td>
          <td width="414" valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky2 = mysql_query("SELECT `date_added` FROM `written_prescription` WHERE `hospital_no` = '$hospital_no'")or die("Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PRESCRIPTION RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Date Added</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky2, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
		echo "</table></html>"; 
	
	
	
	}?>
          </p></td>
        </tr>
      </table>
      <p>&nbsp;</p>
    </div></td>
  </tr>
</table>
<hr />
<p><span class="style1">MEDICAL PROCEDURES</span><span class="style4" style="cursor:pointer" onClick="toggleInfo('ans1');" > [+]</span></span></p>
<table width="511" align="center">
  <tr>
    <td><div id="ans1">
      <table width="820" height="82" align="center">
        <tr>
          <td valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	$count = 0;
	include('dbconnect.php');
	$query = mysql_query("SELECT `date`,`section/service`,`number`,`repeat`,`purpose`,`requested_by`,`doctor/staff`,`status`,`financial_status` FROM `procedures` WHERE `hospital_no` = '$hospital_no'")or die("Error");
	$sql = @mysql_num_rows($query);
	if($sql==0)
	{
	 echo "NO RECORDS FOUND";
	} 
	else
	{
	$query1 = mysql_query("SELECT `procedure` FROM `procedure` WHERE `hospital_no` = '$hospital_no'");
	$query2 = mysql_query("SELECT `cost` FROM `procedure` WHERE `hospital_no` = '$hospital_no'");
	echo "<html>";
	echo "<table width=800 border=1>";
	echo "<tr>";
	echo "<td><strong>Date </strong></td>
        <td><strong>Section/Service </strong></td>
        <td><strong>Number of Procedures </strong></td>
        <td><strong>Repeat </strong></td>
        <td><strong>Purpose</strong></td>
        <td><strong>Requested By</strong></td>
        <td><strong>Doctor/Staff </strong></td>
		<td><strong>Status </strong></td>
		<td><strong>Financial Status </strong></td>
		<td><strong>Procedure </strong></td>
		<td><strong>Cost </strong></td>
        </tr>";
	while($rows = @mysql_fetch_array($query, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 	}
	echo "<td class = style2>";
	while ($rows = @mysql_fetch_array($query1, MYSQL_ASSOC))
{

while( list ($key, $value) = each($rows) )
{
echo "*".$value.'<br>';
}
}
echo "</td>";
echo "<td class = style2>";
	while ($rows = @mysql_fetch_array($query2, MYSQL_ASSOC))
{

while( list ($key, $value) = each($rows) )
{
echo "*".$value.'<br>';
$cost2 = $value;
}
$total2 = $total2+$cost2;
}
echo "</td>";
echo "</tr>";
	echo "</table></html>"; 
	}?>
            </p>
              <p>&nbsp;</p>
            <p>TOTAL AMOUNT = <?php echo $total2;?> Naira </p>
            <p>&nbsp;</p></td>
        </tr>
      </table>
      <hr />
      <p class="style3">WRITTEN PROCEDURE REQUEST </p>
      <table width="820" height="82" align="center">
        <tr>
          <td width="414" valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky = mysql_query("SELECT `examination` FROM `written_procedure` WHERE `hospital_no` = '$hospital_no'")or die("Fatal Error");
   $viky2 = mysql_query("SELECT `date_added` FROM `written_procedure` WHERE `hospital_no` = '$hospital_no'")or die("Lucy Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PROCEDURE REQUEST RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Examination</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2><a href=procedure/$col_value>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
	echo "</table></html>"; 
	
	
	
	}?>
          </p></td>
          <td width="414" valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky2 = mysql_query("SELECT `date_added` FROM `written_procedure` WHERE `hospital_no` = '$hospital_no'")or die("Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PROCEDURE REQUEST RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Date Added</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky2, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
		echo "</table></html>"; 
	
	
	
	}?>
          </p></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p></p>
    </div></td>
  </tr>
</table>
<hr />
<p><span class="style1">RESULTS</span><span class="style4" style="cursor:pointer" onClick="toggleInfo('ans2');" > [+]</span></span></p>
<table width="200" align="center">
  <tr>
    <td><div id="ans2">
      <table width="820" height="82" align="center">
        <tr>
          <td valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	$count = 0;
	include('dbconnect.php');
	$query = mysql_query("SELECT `hospital_no`,`procedure`,`result`,`date_added` FROM `results` WHERE `hospital_no` = '$hospital_no'")or die("Error");
	$sql = @mysql_num_rows($query);
	if($sql==0)
	{
	 echo "NO RECORDS FOUND";
	} 
	else
	{
	echo "<html>";
	echo "<table width=800 border=1>";
	echo "<tr>";
	echo "<td><strong>Hospital No </strong></td>
        <td><strong>Procedure </strong></td>
        <td><strong>Result </strong></td>
        <td><strong>Date Added </strong></td>
        </tr>";
	while($rows = @mysql_fetch_array($query, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</td>";	
		}
	echo "</tr>";
	echo "</table></html>"; 
	}
	?>
            </p>
            <p>&nbsp;</p></td>
        </tr>
      </table>
      <hr />
      <p class="style3">WRITTEN PATIENT RESULT </p>
      <table width="820" height="82" align="center">
        <tr>
          <td width="414" valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky = mysql_query("SELECT `results` FROM `written_results` WHERE `hospital_no` = '$hospital_no'")or die("Fatal Error");
   $viky2 = mysql_query("SELECT `date_added` FROM `written_results` WHERE `hospital_no` = '$hospital_no'")or die("Lucy Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PROCEDURE REQUEST RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Examination</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2><a href=results/$col_value>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
	echo "</table></html>"; 
	
	
	
	}?>
          </p></td>
          <td width="414" valign="top" bgcolor="#FFFFC1"><p>
              <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky2 = mysql_query("SELECT `date_added` FROM `written_results` WHERE `hospital_no` = '$hospital_no'")or die("Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PROCEDURE REQUEST RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Date Added</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky2, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
		echo "</table></html>"; 
	
	
	
	}?>
          </p></td>
        </tr>
      </table>
      <p></p>
    </div></td>
  </tr>
</table>
<p>&nbsp;</p>
