<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
$year = date("Y");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function logout()
{window.location = "logout.php"};
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Pharmacist Page| DMR - MIST</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style3 {font-size: 12px}
#Layer1 {
	position:absolute;
	width:397px;
	height:52px;
	z-index:1;
	left: 526px;
	top: 189px;
}
.style11 {color: #FFFFFF}
.style10 {color: #000033}
.style12 {color: #014377}
-->
</style>
</head>
<body>


<div id="bg2">




<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div id="buttons"><strong><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans0');">Search</a><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans1');">View Stock  </a>
      <a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans2');">Issue Items </a><a href="#"  class="but" title="" style="cursor:pointer" onclick="logout();">Logout</a></strong></div>
	 <div id="logo">
	  <div id="Layer1">
	    <div id="layer"></div>
	    <a href="#" class="style1"><?php echo $_SESSION['user_id'];?> Page </a></div>
	  <a href="#" class="style1">DMR - MIST </a>
      <h2><a href="#" id="metamorph">e-NERGY Software Solutions</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">Your Info </h1>	
                        <div class="right_b">
                          <div class="munth">
                            <p>Name: <span class="style10"><?php echo $_SESSION['name'];?></span> </p>
                            <p>Sex: <span class="style3"><?php echo $_SESSION['sex'];?></span></p>
                            <p>Dept: <span class="style3"><?php echo $_SESSION['department'];?></span></p>
                            <p>Phone: <span class="style3"><?php echo $_SESSION['phone'];?></span></p>
                            <p>Email: <span class="style3"><?php echo $_SESSION['email'];?></span></p>
                            <p>Last Login: <span class="style3"><?php echo $_SESSION['last_login'];?></span></p>
                            <p>&nbsp;</p>
                            <p><span class="style3">
                              <input name="Edit" type="button" id="Edit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Edit" />
                            </span> </p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                          </div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">Support</h1>	
                    	<div class="right_w fish_10">
                    	  <div class="munth">
                    	    <p>For technical support, please call any of the following phone numbers. </p>
                    	    <p>&nbsp;</p>
                    	    <p>Victor: 08039098042</p>
                    	    <p>&nbsp;</p>
                    	    <p>You may send us an Email: support@emrsoft.com </p>
                    	    <p>&nbsp;  </p>
                    	    <p>&nbsp;</p>
                    	    <p>&nbsp;</p>
                    	  </div>
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1> Hospital News</h1>
                       <div class="box1">
                        <div class="left_b"><span class="w">Friday, Apr.10, 2010</span><br />
                          The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Saturday, Apr. 11, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Sunday, Apr. 12, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Monday, Apr. 13, 2010</span><br />
                                   The hospital management today welcomed the minister of health of the federation on a two-day visit....
                                     <div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                      </div>
                    <div id="center">
                      <h1>Login as: <span class="style10"><?php echo $_SESSION['user_id'];?></span></h1>
                        <div class="text" id="ans0">
                           <p><span class="style12">Search Prescription </span></p>
                           <p>&nbsp;</p>
                           <table width="427" height="122" align="center">
                             <tr>
                               <td align="center" valign="top" bgcolor="#FFFFC1"><p align="left" class="style3">Search Patient </p>
                                 <p align="left" class="style3">&nbsp;</p>
                                 <form action="pharmacy_patient_search.php" method="post" target="_blank" id="search1">
                                     <table width="375" align="center">
                                       <tr>
                                         <td width="136">Hospital No </td>
                                         <td width="223"><label>
                                           <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF" />
                                         </label></td>
                                       </tr>
                                       <tr>
                                         <td>&nbsp;</td>
                                         <td>&nbsp;</td>
                                       </tr>
                                       <tr>
                                         <td><input name="Search12" type="submit" id="Search12" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                         <td>&nbsp;</td>
                                       </tr>
                                     </table>
                                 </form>
                                 <br />
                                 <div align="left"></div>
                                   <p align="left"></p></td>
                             </tr>
                          </table>
                           </div>
                        
                        
                        <div class="text" id="ans1">
                          <p class="style12">View Stock</p>
                          <p>&nbsp; </p>
                          <table width="414" height="209" align="center">
                            <tr>
                              <td align="center" valign="top" bgcolor="#FFFFC1"><p align="left" class="style3">Search by Name </p>
                                <p align="left" class="style3">&nbsp;</p>
                                <form action="drug_name_search.php" method="post" target="_blank" id="search1">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Name </td>
                                        <td width="223"><label>
                                          <input name="name" type="text" id="name" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search122" type="submit" id="Search122" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <div align="left">
                                    <p>Search by Code  </p>
                                    <p>&nbsp;</p>
                                </div>
                                <form action="drug_code_search.php" method="post" target="_blank" id="search2">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">Code </td>
                                        <td width="223"><label>
                                          <input name="code" type="text" id="code" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search122" type="submit" id="Search1222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                              <p align="left"></p></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p>
                      </div>
                        <div class="text" id="ans2">
                          <p><span class="style12">Issue Items </span></p>
                          <p>&nbsp;</p>
                          <table width="414" height="107" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                  <form id="form2" method="post" action="issue.php">
                                    <p class="style3">Hospital No
                                      <label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                        </label>
                                    </p>
                                    <p class="style3">&nbsp;</p>
                                    <p><span class="style3">
                                      <input name="Submit32" type="submit" id="Submit32" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Issue"/>
                                    </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
                              </form></td>
                            </tr>
                          </table>
                      </div>
                        <p>&nbsp;</p>
                    </div>
                    
                      <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
     <!-- footer begins -->
            <div id="footer">
          
		    <p><span class="style11">&copy;2010. EMR-SOFT V 1.0. Powered by e-NERGY Software Solutions</span></p> 
	</div>
        <!-- footer ends -->
</div>

</div>




</body>
</html>
<?php
}
?>