<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$code1 = $_POST['code1'];
$code2 = $_POST['code2'];
$code3 = $_POST['code3'];
$code4 = $_POST['code4'];
$code5 = $_POST['code5'];
$code6 = $_POST['code6'];
$code7 = $_POST['code7'];
$code8 = $_POST['code8'];
$code9 = $_POST['code9'];
$code10 = $_POST['code10'];

$item1 = $_POST['item1'];
$item2 = $_POST['item2'];
$item3 = $_POST['item3'];
$item4 = $_POST['item4'];
$item5 = $_POST['item5'];
$item6 = $_POST['item6'];
$item7 = $_POST['item7'];
$item8 = $_POST['item8'];
$item9 = $_POST['item9'];
$item10 = $_POST['item10'];

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `accounts` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Patient financial records not found!");
window.location = "accounts_page.php";
</script>
<?php
exit();
}
mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `hospital_no` = '$hospital_no'")or die("Error");
mysql_query("UPDATE `prescribtion` SET `financial_status` = 'CLEARED' where `hospital_no` = '$hospital_no'");
mysql_query("UPDATE `procedures` SET `financial_status` = 'CLEARED' where `hospital_no` = '$hospital_no'");

?>
<script type="text/javascript">
alert("Patient Items Successfully cleared");
window.location = "accounts_page.php";
</script>