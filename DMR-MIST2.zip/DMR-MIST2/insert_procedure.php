<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$instruction = $_POST['instruction'];

$date = date("d")."-".date("M")."-".date("Y");

include('dbconnect.php');
mysql_query("INSERT INTO procedures SET hospital_no = '$hospital_no', schedule = 'NOT YET SCHEDULED'");
$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist! Please try again");
window.location = "medical_consultant_page.php";
</script>
<?php
exit();
}
$complete_blood_test = $_POST['complete_blood_test'];
if($complete_blood_test !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Complete Blood Test', `hospital_no` = '$hospital_no', `cost` = '$complete_blood_test'") or die("ERROR");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Complete Blood Test', `hospital_no` = '$hospital_no', `amount` = '$complete_blood_test', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$hemoglobin = $_POST['hemoglobin'];
if($hemoglobin !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Hemoglobin', `hospital_no` = '$hospital_no', `cost` = '$hemoglobin'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Hemoglobin', `hospital_no` = '$hospital_no', `amount` = '$hemoglobin', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$hematocrit = $_POST['hematocrit'];
if($hematocrit !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Hematocrit', `hospital_no` = '$hospital_no', `cost` = '$hematocrit'");
mysql_query("INSERT INTO `accounts` SET `item` = 'Hematocrit', `hospital_no` = '$hospital_no', `amount` = '$hematocrit', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}

$mch = $_POST['mch'];
if($mch !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='MCH',`hospital_no` = '$hospital_no', `cost` = '$mch'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'MCH', `hospital_no` = '$hospital_no', `section` = 'Lab', `amount` = '$mch', `date_added` = '$date'") or die("ERROR");
}

$mchc = $_POST['mchc'];
if($mchc !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='MCHC',`hospital_no` = '$hospital_no', `cost` = '$mchc'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'MCHC', `hospital_no` = '$hospital_no', `amount` = '$mchc', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}

$mcv = $_POST['mcv'];
if($mcv !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='MCV',`hospital_no` = '$hospital_no', `cost` = '$mcv'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'MCV', `hospital_no` = '$hospital_no', `section` = 'Lab', `amount` = '$mcv', `date_added` = '$date'") or die("ERROR");
}

$white_blood_cell = $_POST['white_blood_cell'];
if($white_blood_cell !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='White Blood Cell',`hospital_no` = '$hospital_no', `cost` = '$white_blood_cell'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'White Blood Cell', `hospital_no` = '$hospital_no', `amount` = '$white_blood_cell', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$wbcdc = $_POST['wbcdc'];
if($wbcdc !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='White Blood Cell Differential Count',`hospital_no` = '$hospital_no', `cost` = '$wbcdc'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'White Blood Cell Differential Count', `hospital_no` = '$hospital_no', `amount` = '$wbcdc', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$neutrophils = $_POST['neutrophils'];
if($neutrophils !='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Neutrophils',`hospital_no` = '$hospital_no', `cost` = '$neutrophils'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Neutrophils', `hospital_no` = '$hospital_no', `amount` = '$neutrophils', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$eosinophils = $_POST['eosinophils'];
if($eosinophils!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Eosinophils',`hospital_no` = '$hospital_no', `cost` = '$eosinophils'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Eosinophils', `hospital_no` = '$hospital_no', `amount` = '$eosinophils', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$basophils = $_POST['basophils'];
if($basophils!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Basophils',`hospital_no` = '$hospital_no', `cost` = '$basophils'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Basophils', `hospital_no` = '$hospital_no', `amount` = '$basophils', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$lymphocyte = $_POST['lymphocyte'];
if($lymphocyte!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Lymphocyte',`hospital_no` = '$hospital_no', `cost` = '$lymphocyte'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Lymphocyte', `hospital_no` = '$hospital_no', `amount` = '$lymphocyte', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$monocyte = $_POST['monocyte'];
if($monocyte!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Monocyte',`hospital_no` = '$hospital_no', `cost` = '$monocyte'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Monocyte', `hospital_no` = '$hospital_no', `amount` = '$monocyte', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$erythrocyte = $_POST['erythrocyte'];
if($erythrocyte!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Erythrocyte',`hospital_no` = '$hospital_no', `cost` = '$erythrocyte'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Erythrocyte', `hospital_no` = '$hospital_no', `amount` = '$erythrocyte', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$esr = $_POST['esr'];
if($esr!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Erythrocyte Sedimentation Rate',`hospital_no` = '$hospital_no', `cost` = '$esr'");
mysql_query("INSERT INTO `accounts` SET `item` = 'Erythrocyte Sedimentation Rate', `hospital_no` = '$hospital_no', `amount` = '$esr', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$reticulocyte = $_POST['reticulocyte'];
if($reticulocyte!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Reticulocyte',`hospital_no` = '$hospital_no', `cost` = '$reticulocyte'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Reticulocyte', `hospital_no` = '$hospital_no', `amount` = '$reticulocyte', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$thrombocyte = $_POST['thrombocyte'];
if($thrombocyte!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Thrombocyte',`hospital_no` = '$hospital_no', `cost` = '$thrombocyte'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Thrombocyte', `hospital_no` = '$hospital_no', `amount` = '$thrombocyte', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$hemostasis = $_POST['hemostasis'];
if($hemostasis!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Hemostasis',`hospital_no` = '$hospital_no', `cost` = '$hemostasis'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Hemostasis', `hospital_no` = '$hospital_no', `amount` = '$hemostasis', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$bleeding_time = $_POST['bleeding_time'];
if($bleeding_time!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Bleeding Time',`hospital_no` = '$hospital_no', `cost` = '$bleeding_time'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Bleeding Time', `hospital_no` = '$hospital_no', `amount` = '$bleeding_time', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$clotting_time = $_POST['clotting_time'];
if($clotting_time!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Clotting Time',`hospital_no` = '$hospital_no', `cost` = '$clotting_time'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Clotting Time', `hospital_no` = '$hospital_no', `amount` = '$clotting_time', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$ppt = $_POST['ppt'];
if($ppt!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='PPT',`hospital_no` = '$hospital_no', `cost` = '$ppt'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'PPT', `hospital_no` = '$hospital_no', `section` = 'Lab', `amount` = '$ppt', `date_added` = '$date'") or die("ERROR");
}
$appt = $_POST['appt'];
if($appt!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='APPT',`hospital_no` = '$hospital_no', `cost` = '$appt'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'APPT', `hospital_no` = '$hospital_no', `amount` = '$appt', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$fibrinogen = $_POST['fibrinogen'];
if($fibrinogen!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Fibrinogen',`hospital_no` = '$hospital_no', `cost` = '$fibrinogen'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Fibrinogen', `hospital_no` = '$hospital_no', `amount` = '$fibrinogen', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$tat = $_POST['tat'];
if($tat!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Thrombocyte Aggregation Test',`hospital_no` = '$hospital_no', `cost` = '$tat'");
mysql_query("INSERT INTO `accounts` SET `item` = 'Thrombocyte Aggregation Test', `hospital_no` = '$hospital_no', `amount` = '$tat', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$thrombin_time = $_POST['thrombin_time'];
if($thrombin_time!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Thrombin time',`hospital_no` = '$hospital_no', `cost` = '$thrombin_time'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Thrombin Time', `hospital_no` = '$hospital_no', `amount` = '$thrombin_time', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$prothrombin_time = $_POST['prothrombin_time'];
if($prothrombin_time!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Prothrombin Time',`hospital_no` = '$hospital_no', `cost` = '$prothrombin_time'");
mysql_query("INSERT INTO `accounts` SET `item` = 'Prothrombin Time', `hospital_no` = '$hospital_no', `amount` = '$prothrombin_time', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$eat = $_POST['eat'];
if($eat!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Erythrocyte Aggregation Test',`hospital_no` = '$hospital_no', `cost` = '$eat'");
mysql_query("INSERT INTO `accounts` SET `item` = 'Erythrocyte Aggregation Test', `hospital_no` = '$hospital_no', `amount` = '$eat', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$arachidonic_acid = $_POST['arachidonic_acid'];
if($arachidonic_acid!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Arachidonic acid',`hospital_no` = '$hospital_no', `cost` = '$arachidonic_acid'");
mysql_query("INSERT INTO `accounts` SET `item` = 'Arachidonic acid', `hospital_no` = '$hospital_no', `amount` = '$arachidonic_acid', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$paf = $_POST['paf'];
if($paf!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Platelet Activating Factor',`hospital_no` = '$hospital_no', `cost` = '$paf'");
mysql_query("INSERT INTO `accounts` SET `item` = 'Platelet Activating Factor', `hospital_no` = '$hospital_no', `amount` = '$paf', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$blood_viscocity = $_POST['blood_viscocity'];
if($blood_viscocity!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Blood Viscocity',`hospital_no` = '$hospital_no', `cost` = '$blood_viscocity'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Blood Viscocity', `hospital_no` = '$hospital_no', `amount` = '$blood_viscocity', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$plasma_viscocity = $_POST['plasma_viscocity'];
if($plasma_viscocity!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Plasma Viscocity',`hospital_no` = '$hospital_no', `cost` = '$plasma_viscocity'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Plasma Viscocity', `hospital_no` = '$hospital_no', `amount` = '$plasma_viscocity', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$serum_iron = $_POST['serum_iron'];
if($serum_iron!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Serum Iron',`hospital_no` = '$hospital_no', `cost` = '$serum_iron'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Serum Iron', `hospital_no` = '$hospital_no', `amount` = '$serum_iron', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$tibc = $_POST['tibc'];
if($tibc!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='TIBC',`hospital_no` = '$hospital_no', `cost` = '$tibc'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'TIBC', `hospital_no` = '$hospital_no', `amount` = '$tibc', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$ferritin = $_POST['ferritin'];
if($ferritin!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Ferritin',`hospital_no` = '$hospital_no', `cost` = '$ferritin'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Ferritin', `hospital_no` = '$hospital_no', `amount` = '$ferritin', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$g6pd = $_POST['g6pd'];
if($g6pd!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='G6PD',`hospital_no` = '$hospital_no', `cost` = '$g6pd'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'G6PD', `hospital_no` = '$hospital_no', `amount` = '$g6pd', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$ctd = $_POST['ctd'];
if($ctd!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Coombs Test Direct',`hospital_no` = '$hospital_no', `cost` = '$ctd'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Coombs Test Direct', `hospital_no` = '$hospital_no', `amount` = '$ctd', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$cti = $_POST['cti'];
if($cti!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Coombs Test Indirect',`hospital_no` = '$hospital_no', `cost` = '$cti'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Coombs Test Indirect', `hospital_no` = '$hospital_no', `amount` = '$cti', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$spirometry = $_POST['spirometry'];
if($spirometry!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Spirometry',`hospital_no` = '$hospital_no', `cost` = '$spriometry'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Spirometry', `hospital_no` = '$hospital_no', `amount` = '$spirometry', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$bronchoscopy = $_POST['bronchoscopy'];
if($bronchoscopy!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Bronchoscopy',`hospital_no` = '$hospital_no', `cost` = '$bronchoscopy'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Bronchoscopy', `hospital_no` = '$hospital_no', `amount` = '$bronchoscopy', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$ultrascan = $_POST['ultrascan'];
if($ultrascan!='')
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `procedure` SET `procedure` ='Ultrascan',`hospital_no` = '$hospital_no', `cost` = '$ultrascan'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'Ultrascan', `hospital_no` = '$hospital_no', `amount` = '$ultrascan', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
}
$x_ray = $_POST['x_ray'];
if($x_ray!='')
{
 include('dbconnect.php');
 
 mysql_query("INSERT INTO `procedure` SET `procedure` ='X-RAY',`hospital_no` = '$hospital_no', `cost` = '$x_ray', `instruction` = '$instruction'");
 mysql_query("INSERT INTO `accounts` SET `item` = 'X-RAY', `hospital_no` = '$hospital_no', `amount` = '$x_ray', `date_added` = '$date', `section` = 'Lab'") or die("ERROR");
 }
$repeat = $_POST['repeat'];
$purpose = $_POST['purpose'];

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `procedure` FROM `procedure` WHERE `hospital_no` = '$hospital_no'");
$number = @mysql_num_rows($sql);


mysql_query("UPDATE `procedures` SET `date` = '$date_added', `section/service` = 'Laboratory', `repeat` = '$repeat',
`purpose` = '$purpose', `requested_by` = '$_SESSION[user_id]', `doctor/staff` = 'Laboratory Staff', `status` = 'WAITING',
`purpose` = '$purpose', `number` = '$number', `financial_status` = 'NOT CLEARED' WHERE `hospital_no` = '$hospital_no'") or die("Error");

?>
<script type="text/javascript">
alert("Patient Procedure Order Record Added");
window.location = "medical_consultant_page.php";
</script>