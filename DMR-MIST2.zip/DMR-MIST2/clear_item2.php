<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$code1 = $_POST['code1'];
$code2 = $_POST['code2'];
$code3 = $_POST['code3'];
$code4 = $_POST['code4'];
$code5 = $_POST['code5'];
$code6 = $_POST['code6'];
$code7 = $_POST['code7'];
$code8 = $_POST['code8'];
$code9 = $_POST['code9'];
$code10 = $_POST['code10'];

$item1 = $_POST['item1'];
$item2 = $_POST['item2'];
$item3 = $_POST['item3'];
$item4 = $_POST['item4'];
$item5 = $_POST['item5'];
$item6 = $_POST['item6'];
$item7 = $_POST['item7'];
$item8 = $_POST['item8'];
$item9 = $_POST['item9'];
$item10 = $_POST['item10'];

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `accounts` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Patient financial records not found!");
window.location = "accounts_page.php";
</script>
<?php
exit();
}
if($code1 != '')
{
 include('dbconnect.php');
 $c1 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code1' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c1);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code1;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code1' AND `hospital_no` = '$hospital_no'")or die("Error");
 mysql_query("UPDATE `prescribtion` SET `financial_status` = 'CLEARED' where `hospital_no` = '$hospital_no'");
 mysql_query("UPDATE `procedures` SET `financial_status` = 'CLEARED' where `hospital_no` = '$hospital_no'");
 }
 }
if($code2 != '')
{
 include('dbconnect.php');
 $c2 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code2' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c2);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code2;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code2' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code3 != '')
{
 include('dbconnect.php');
 $c3 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code3' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c3);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code3;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code3' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code4 != '')
{
 include('dbconnect.php');
 $c4 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code4' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c4);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code4;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code4' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code5 != '')
{
 include('dbconnect.php');
 $c5 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code5' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c5);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code5;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code5' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code6 != '')
{
 include('dbconnect.php');
 $c6 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code6' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c6);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code6;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code6' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code7 != '')
{
 include('dbconnect.php');
 $c7 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code7' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c7);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code7;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code7' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code8 != '')
{
 include('dbconnect.php');
 $c8 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code8' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c8);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code8;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code8' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code9 != '')
{
 include('dbconnect.php');
 $c9 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code9' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c9);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code9;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code9' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code10 != '')
{
 include('dbconnect.php');
 $c10 = mysql_query("SELECT `status` FROM `accounts` WHERE `item` = '$code10' AND `status` = 'PAID' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c10);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code10;?> has already been cleared for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `accounts` SET `status` = 'PAID' WHERE `item` = '$code10' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
?>
<script type="text/javascript">
alert("Patient Items Successfully cleared");
window.location = "accounts_page.php";
</script>