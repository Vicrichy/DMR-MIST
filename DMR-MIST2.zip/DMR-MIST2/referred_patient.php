<?php

session_start();

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$date_of_birth = $_POST['date_of_birth'];
$sex = $_POST['sex'];
$occupation = $_POST['occupation'];
$next_of_kin = $_POST['next_of_kin'];
$visit_status = $_POST['visit_status'];
$referral_hospital = $_POST['referral_hospital'];
$amount_paid = $_POST['amount_paid'];
$hospital_no = $_POST['hospital_no'];
$reg_point = $_POST['reg_point'];
$purpose = $_POST['purpose'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$address = $_POST['address'];
$tech_fee = $_POST['tech_fee'];
$reg_fee = $_POST['reg_fee'];
$medical_personnel = $_POST['medical_personnel'];
$payment_purpose = "$reg_fee, $tech_fee";
$birth_day = $_POST['day'];
$birth_month = $_POST['month'];
$birth_year = $_POST['year'];
$referral_id = $_POST['referral_id'];

$date_of_birth = "$birth_day-$birth_month-$birth_year";
$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows>0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number is already used, Please try again");
window.location = "registration_staff_page.php";
</script>
<?php
exit();
}
else
{
mysql_query("INSERT INTO referred_patient(fname,lname,date_of_birth,sex,occupation,next_of_kin,visit_status,referral_hospital,amount_paid,hospital_no,
reg_point,purpose,phone,email,address,medical_personnel,referral_id,payment_purpose,date_added)VALUES('$fname','$lname','$date_of_birth','$sex','$occupation','$next_of_kin','$visit_status','$referral_hospital','$amount_paid','$hospital_no','$reg_point','$purpose','$phone','$email','$address','$medical_personnel','$referral_id','$payment_purpose','$date_added')") or die("Error");
}
?>
<script type="text/javascript">
alert("New Reffered Patient Record Successfully added");
window.location = "registration_staff_page.php";
</script>