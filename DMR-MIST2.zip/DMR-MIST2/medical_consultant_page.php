<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
$year = date("Y");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script LANGUAGE="JavaScript">

function popUp(URL,popW,popH) {

var w = 480, h = 340;

if (document.all || document.layers) {
   w = screen.availWidth;
   h = screen.availHeight;
}

var topPos = 0, leftPos = (w-popW)/2;


   window.open(URL,'popup','resizable, toolbar=no, location=no, status=no, scrollbars=yes, horizontal scrollbars=yes, scroll=yes, menubar=no, titlebar=no, width=' + popW + ',height=' + popH + ',left=' + leftPos + ',top=' + topPos + ',screenX=' + leftPos + ',screenY=' + topPos);

}
// -->
</script>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function logout()
{window.location = "logout.php"};
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Doctor Page| DMR - MIST</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style3 {font-size: 12px}
#Layer1 {
	position:absolute;
	width:469px;
	height:52px;
	z-index:1;
	left: 526px;
	top: 189px;
}
.style11 {color: #FFFFFF}
.style10 {color: #000033}
.style12 {color: #014377}
.style13 {font-size: 10px}
.style14 {
	font-size: 14px;
	font-weight: bold;
}
-->
</style>
</head>
<body>


<div id="bg2">




<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div id="buttons"><strong><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans0');">Options </a><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans1');">Examination</a>
      <a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans2');">Procedures </a><a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans3');">Prescription </a></strong><strong><a href="#"  class="but" title="" style="cursor:pointer" onclick="logout();">Logout </a></strong></div>
	 <div id="logo">
	  <div id="Layer1">
	    <div id="layer"></div>
	    <a href="#" class="style1"><?php echo $_SESSION['user_id'];?> Page </a></div>
	  <a href="#" class="style1">DMR - MIST </a>
      <h2><a href="#" id="metamorph">e-NERGY Software Solutions</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">Your Info </h1>	
                        <div class="right_b">
                          <div class="munth">
                            <p>Name: <span class="style10"><?php echo $_SESSION['name'];?></span> </p>
                            <p>Sex: <span class="style3"><?php echo $_SESSION['sex'];?></span></p>
                            <p>Dept: <span class="style3"><?php echo $_SESSION['department'];?></span></p>
                            <p>Phone: <span class="style3"><?php echo $_SESSION['phone'];?></span></p>
                            <p>Email: <span class="style3"><?php echo $_SESSION['email'];?></span></p>
                            <p>Last Login: <span class="style3"><?php echo $_SESSION['last_login'];?></span></p>
                            <p>&nbsp;</p>
                            <p><span class="style3">
                              <input name="Edit" type="button" id="Edit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Edit" />
                            </span> </p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                          </div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">Support</h1>	
                    	<div class="right_w fish_10">
                    	  <div class="munth">
                    	    <p>For technical support, please call any of the following phone numbers. </p>
                    	    <p>&nbsp;</p>
                    	    <p>Victor: 08039098042</p>
                    	    <p>&nbsp;</p>
                    	    <p>You may send us an Email: support@emrsoft.com </p>
                    	    <p>&nbsp;  </p>
                    	    <p>&nbsp;</p>
                    	    <p>&nbsp;</p>
                    	  </div>
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1> Hospital News</h1>
                       <div class="box1">
                        <div class="left_b"><span class="w">Friday, Apr.10, 2010</span><br />
                          The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Saturday, Apr. 11, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Sunday, Apr. 12, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Monday, Apr. 13, 2010</span><br />
                                   The hospital management today welcomed the minister of health of the federation on a two-day visit....
                                     <div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                      </div>
                    <div id="center">
                      <h1>Login as: <span class="style10"><?php echo $_SESSION['user_id'];?></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h1>
                      <div class="text" id="ans0">
                          <p class="style12">Search Options </p>
                          <p class="style12">&nbsp;</p>
                          <table width="414" height="209" align="center">
                            <tr>
                              <td align="center" valign="top" bgcolor="#FFFFC1"><p align="left" class="style3">Search Patient </p>
                                <p align="left" class="style3">&nbsp;</p>
                                <form action="patient_medical_history.php" method="post" target="_blank" id="search1">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">Hospital No </td>
                                        <td width="223"><label>
                                          <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search1" type="submit" id="Search1" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <div align="left">
                                    <p>&nbsp;</p>
                                    <p>Search Schedule  </p>
                                    <p>&nbsp;</p>
                                  </div>
                                <form action="schedule_search.php" method="post" target="_blank" id="search2">
                                    <table width="380" align="center">
                                      <tr>
                                        <td width="136">Date</td>
                                        <td><label>
                                          <select name="day" id="day" style="background:#003366; color:#FFFFFF">
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                            <option>13</option>
                                            <option>14</option>
                                            <option>15</option>
                                            <option>16</option>
                                            <option>17</option>
                                            <option>18</option>
                                            <option>19</option>
                                            <option>20</option>
                                            <option>21</option>
                                            <option>22</option>
                                            <option>23</option>
                                            <option>24</option>
                                            <option>25</option>
                                            <option>26</option>
                                            <option>27</option>
                                            <option>28</option>
                                            <option>29</option>
                                            <option>30</option>
                                            <option>31</option>
                                          </select>
                                          <select name="month" id="month" style="background:#003366; color:#FFFFFF">
                                            <option>Jan</option>
                                            <option>Feb</option>
                                            <option>Mar</option>
                                            <option>Apr</option>
                                            <option>May</option>
                                            <option>Jun</option>
                                            <option>Jul</option>
                                            <option>Aug</option>
                                            <option>Sep</option>
                                            <option>Oct</option>
                                            <option>Nov</option>
                                            <option>Dec</option>
                                          </select>
                                          <input name="year" type="text" id="year" value="<?php echo $year;?>" size="5" width="40" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search32" type="submit" id="Search32" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                              <p align="left"></p></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p>
                          <p class="style12">Computerized Physician Order Entry</p>
                          <p class="style12">&nbsp;</p>
                          <table width="414" height="104" align="center">
                            <tr>
                              <td align="center" valign="top" bgcolor="#FFFFC1"><form action="order_entry.php" method="post" target="_blank" id="search1">
                                  <table width="371" align="center">
                                    <tr>
                                      <td width="136">Hospital No </td>
                                      <td width="223"><label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                      </label></td>
                                    </tr>
                                    <tr>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td><input name="Search12" type="submit" id="Search12" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                      <td>&nbsp;</td>
                                    </tr>
                                  </table>
                              </form>
                              <p class="style3">&nbsp;</p></td>
                            </tr>
                          </table>
                          <p class="style12">&nbsp; </p>
                          <p class="style12">Discharge Patient </p>
                          <p class="style12">&nbsp;</p>
                          <table width="414" height="104" align="center">
                            <tr>
                              <td align="center" valign="top" bgcolor="#FFFFC1"><form action="discharge.php" method="post" target="_blank" id="search1">
                                  <table width="371" align="center">
                                    <tr>
                                      <td width="136">Hospital No </td>
                                      <td width="223"><label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                      </label></td>
                                    </tr>
                                    <tr>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td><input name="Search123" type="submit" id="Search123" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                      <td>&nbsp;</td>
                                    </tr>
                                  </table>
                              </form>
                                  <p class="style3">&nbsp;</p></td>
                            </tr>
                          </table>
                        <p>&nbsp;</p>
                          <p class="style12">Patient Daily Report </p>
                          <p class="style12">&nbsp;</p>
                          <table width="414" height="104" align="center">
                            <tr>
                              <td align="center" valign="top" bgcolor="#FFFFC1"><form action="daily_patient_report.php" method="post" target="_blank" id="search1">
                                  <table width="371" align="center">
                                    <tr>
                                      <td width="136">Hospital No </td>
                                      <td width="223"><label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                      </label></td>
                                    </tr>
                                    <tr>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td><input name="Search1232" type="submit" id="Search1232" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                      <td>&nbsp;</td>
                                    </tr>
                                  </table>
                              </form>
                                  <p class="style3">&nbsp;</p></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p>
                      </div>
                      <div class="text" id="ans1">
                          <p class="style12">Examination</p>
                          <p>&nbsp; </p>
                          <table width="414" height="212" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><form id="form1" method="post" action="insert_examination.php">
                                  <table width="399">
                                    <tr>
                                      <td width="127" class="style3">Hospital Number </td>
                                      <td width="256"><label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF" />
                                      </label></td>
                                    </tr>
                                    <tr>
                                      <td>Subjective</td>
                                      <td><textarea name="subjective" id="subjective" style="background:#003366; color:#FFFFFF">N/A</textarea></td>
                                    </tr>
                                    <tr>
                                      <td>Objective </td>
                                      <td><textarea name="objective" id="objective" style="background:#003366; color:#FFFFFF">N/A</textarea></td>
                                    </tr>
                                    <tr>
                                      <td>Assessment 1 </td>
                                      <td><textarea name="assessment1" id="assessment1" style="background:#003366; color:#FFFFFF">N/A</textarea></td>
                                    </tr>
                                    <tr>
                                      <td height="87" colspan="2"><label>
                                        <input name="admission" type="checkbox" id="admission" value="YES" />
                                      Recommend Admission&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />
                                      </label>
                                          <hr />
                                          <label><span class="style3">&nbsp;</span></label></td>
                                    </tr>
                                    <tr>
                                      <td>ICD Code 1 </td>
                                      <td>
                                        <input name="ICD_code_1" type="text" id="ICD_code_1" value="N/A" size="7" width="50" style="background:#003366; color:#FFFFFF"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                        <input name="disease_1" type="text" id="disease_1" value="N/A" style="background:#003366; color:#FFFFFF"/>                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Assessment 2 </td>
                                      <td><textarea name="assessment2" id="assessment2" style="background:#003366; color:#FFFFFF">N/A</textarea></td>
                                    </tr>
                                    <tr>
                                      <td>ICD Code 2 </td>
                                      <td>
                                        <input name="ICD_code_2" type="text" id="ICD_code_2" value="N/A" size="7" width="50" style="background:#003366; color:#FFFFFF"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                        <input name="disease_2" type="text" id="disease_2" value="N/A" style="background:#003366; color:#FFFFFF"/>                                      </td>
                                    </tr>
                                  </table>
                                  <p>
                                    <input name="Submit" type="submit" id="Submit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add" onclick="logout();" />
                                  </p>
                                  <p>&nbsp;</p>
                                  <p>
                                    <input name="Search3422" type="button" id="Search3422" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Written Examination" onclick="javascript:popUp('http://localhost/dmr-mist/written_examination.php',1000,900)"/>
                                  </p>
                              </form></td>
                            </tr>
                          </table>
                      </div>
                      <div class="text" id="ans2">
                        <p class="style12">Procedures</p>
                          <p class="style12">&nbsp; </p>
                          <table width="414" height="82" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>LABORATORY</p>
                                  <form id="form3" method="post" action="insert_procedure.php">
                                    <p class="style3">HERMATOLOGY</p>
                                    <hr />
                                    <table width="414" class="style13">
                                      <tr>
                                        <td colspan="2">Hospital No </td>
                                        <td colspan="6"><label>
                                          <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td width="20"><label>
                                          <input name="complete_blood_test" type="checkbox" id="complete_blood_test" value="500" />
                                        </label></td>
                                        <td width="162">Complete Blood Count </td>
                                        <td width="20"><input name="hemoglobin" type="checkbox" id="hemoglobin" value="500" /></td>
                                        <td width="164" class="style13">Hemoglobin</td>
                                        <td width="20"><input name="hematocrit" type="checkbox" id="hematocrit" value="500" /></td>
                                        <td width="167">Hematocrit</td>
                                        <td width="20"><input name="mch" type="checkbox" id="mch" value="500" /></td>
                                        <td width="176" class="style13">MCH</td>
                                      </tr>
                                      <tr>
                                        <td><input name="mchc" type="checkbox" id="mchc" value="500" /></td>
                                        <td class="style13">MCHC</td>
                                        <td><input name="mcv" type="checkbox" id="mcv" value="500" /></td>
                                        <td class="style13">MCV</td>
                                        <td><input name="white_blood_cell" type="checkbox" id="white_blood_cell" value="500" /></td>
                                        <td class="style13">White Blood Cell </td>
                                        <td><input name="wbcdc" type="checkbox" id="wbcdc" value="500" /></td>
                                        <td class="style13">White Blood Cell Differential Count </td>
                                      </tr>
                                      <tr class="style13">
                                        <td><input name="neutrophils" type="checkbox" id="neutrophils" value="500" /></td>
                                        <td class="style13">Neutrophils</td>
                                        <td><input name="eosinophils" type="checkbox" id="eosinophils" value="500" /></td>
                                        <td class="style13">Eosinophils</td>
                                        <td><input name="basophils" type="checkbox" id="basophils" value="500" /></td>
                                        <td class="style13">Basophils</td>
                                        <td><input name="lymphocyte" type="checkbox" id="lymphocyte" value="500" /></td>
                                        <td class="style13">Lymphocyte</td>
                                      </tr>
                                      <tr class="style13">
                                        <td><input name="monocyte" type="checkbox" id="monocyte" value="500" /></td>
                                        <td class="style13">Monocyte</td>
                                        <td><input name="erythrocyte" type="checkbox" id="erythrocyte" value="500" /></td>
                                        <td class="style13">Erythrocyte</td>
                                        <td><input name="esr" type="checkbox" id="esr" value="500" /></td>
                                        <td class="style13">Erythrocyte Sedimentation Rate (ESR) </td>
                                        <td><input name="reticulocyte" type="checkbox" id="reticulocyte" value="500" /></td>
                                        <td class="style13">Reticulocyte</td>
                                      </tr>
                                      <tr class="style13">
                                        <td><input name="thrombocyte" type="checkbox" id="thrombocyte" value="500" /></td>
                                        <td class="style13">Thrombocyte</td>
                                        <td><input name="hemostasis" type="checkbox" id="hemostasis" value="500" /></td>
                                        <td class="style13">Hemostasis</td>
                                        <td><input name="bleeding_time" type="checkbox" id="bleeding_time" value="500" /></td>
                                        <td class="style13">Bleeding Time </td>
                                        <td><input name="clotting_time" type="checkbox" id="clotting_time" value="500" /></td>
                                        <td class="style13">Clotting Time </td>
                                      </tr>
                                      <tr class="style13">
                                        <td><input name="ppt" type="checkbox" id="ppt" value="500" /></td>
                                        <td class="style13">PPT</td>
                                        <td><input name="appt" type="checkbox" id="appt" value="500" /></td>
                                        <td class="style13">APPT</td>
                                        <td><input name="fibrinogen" type="checkbox" id="fibrinogen" value="500" /></td>
                                        <td class="style13">Fibrinogen</td>
                                        <td><input name="tat" type="checkbox" id="tat" value="500" /></td>
                                        <td class="style13">Thrombocyte Aggregation Test </td>
                                      </tr>
                                      <tr>
                                        <td><input name="thrombin_time" type="checkbox" id="thrombin_time" value="500" /></td>
                                        <td class="style13">Thrombin Time </td>
                                        <td><input name="prothrombin_time" type="checkbox" id="prothrombin_time" value="500" /></td>
                                        <td class="style13">Prothrombin Time </td>
                                        <td><input name="eat" type="checkbox" id="eat" value="500" /></td>
                                        <td class="style13">Erythrocyte Aggregation Test </td>
                                        <td><input name="arachidonic_acid" type="checkbox" id="arachidonic_acid" value="500" /></td>
                                        <td class="style13">Arachidonic Acid </td>
                                      </tr>
                                      <tr>
                                        <td><input name="paf" type="checkbox" id="paf" value="500" /></td>
                                        <td class="style13">Platelet Activating Factor </td>
                                        <td><input name="blood_viscocity" type="checkbox" id="blood_viscocity" value="500" /></td>
                                        <td class="style13">Blood Viscosity </td>
                                        <td><input name="plasma_viscocity" type="checkbox" id="plasma_viscocity" value="500" /></td>
                                        <td class="style13">Plasma Viscosity </td>
                                        <td><input name="serum_iron" type="checkbox" id="serum_iron" value="500" /></td>
                                        <td class="style13">Serum Iron </td>
                                      </tr>
                                      <tr>
                                        <td><input name="tibc" type="checkbox" id="tibc" value="500" /></td>
                                        <td class="style13">TIBC</td>
                                        <td><input name="ferritin" type="checkbox" id="ferritin" value="500" /></td>
                                        <td class="style13">Ferritin</td>
                                        <td><input name="g6pd" type="checkbox" id="g6pd" value="500" /></td>
                                        <td class="style13">G6PD</td>
                                        <td><input name="ctd" type="checkbox" id="ctd" value="500" /></td>
                                        <td class="style13">Coombs Test Direct </td>
                                      </tr>
                                      <tr>
                                        <td><input name="cti" type="checkbox" id="cti" value="500" /></td>
                                        <td colspan="7" class="style13">Coombs Test Indirect </td>
                                      </tr>
                                    </table>
                                    <p>PULMONOLOGY</p>
                                    <hr />
                                    <table width="414">
                                      <tr>
                                        <td width="20"><span class="style3">
                                          <input name="spirometry" type="checkbox" id="spirometry" value="500" />
                                        </span></td>
                                        <td width="164" class="style13">Spirometry</td>
                                        <td width="20"><span class="style3">
                                          <input name="bronchoscopy" type="checkbox" id="bronchoscopy" value="500" />
                                        </span></td>
                                        <td width="168" class="style13">Bronchoscopy</td>
                                        <td width="20">&nbsp;</td>
                                        <td width="166" class="style13">&nbsp;</td>
                                        <td width="20">&nbsp;</td>
                                        <td width="171" class="style13">&nbsp;</td>
                                      </tr>
                                    </table>
                                    <p>RADIOGRAPHY</p>
                                    <hr />
                                    <table width="414">
                                      <tr>
                                        <td width="20"><span class="style3">
                                          <input name="x_ray" type="checkbox" id="x_ray" value="1500" />
                                        </span></td>
                                        <td width="164" class="style13">X-Ray</td>
                                        <td width="20"><span class="style3">
                                          <input name="ultrascan" type="checkbox" id="ultrascan" value="1500" />
                                        </span></td>
                                        <td width="168" class="style13">UltraScan</td>
                                        <td width="20">&nbsp;</td>
                                        <td width="166" class="style13">X-ray Instructions </td>
                                        <td><label>
                                          <textarea name="instruction" id="instruction" style="background:#003366; color:#FFFFFF"></textarea>
                                        </label></td>
                                      </tr>
                                    </table>
                                    <br />
                                    <table width="414">
                                      <tr>
                                        <td width="20"><span class="style3">
                                          <input name="repeat" type="checkbox" id="repeat" value="YES" />
                                        </span></td>
                                        <td width="164" class="style13">Repeat </td>
                                        <td width="63" class="style13">Purpose
                                          <label></label></td>
                                        <td width="165"><select name="purpose" id="purpose" style="background:#003366; color:#FFFFFF">
                                            <option>Lab Check</option>
                                        </select></td>
                                        <td width="166" class="style13">&nbsp;</td>
                                        <td width="20">&nbsp;</td>
                                        <td width="171" class="style13">&nbsp;</td>
                                      </tr>
                                    </table>
                                    <p>&nbsp;</p>
                                    <p class="style3">
                                      <input name="Submit3" type="submit" id="Submit3" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add" />
                                    </p>
                                    <p class="style3">&nbsp;</p>
                                    <p class="style3">
                                      <input name="Search34222" type="button" id="Search34222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Written Request" onclick="javascript:popUp('http://localhost/dmr-mist/written_procedure.php',1000,900)"/>
                                    </p>
                                  </form>
                              <p>&nbsp;</p></td>
                            </tr>
                          </table>
                      </div>
                      <div class="text" id="ans3">
                        <p class="style12">Prescription</p>
                          <p class="style12">&nbsp;</p>
                          <table width="442" height="212" align="center">
                            <!--DWLayoutTable-->
                            <tr>
                              <td width="418" height="407" valign="top" bgcolor="#FFFFC1"><p class="style14">Create Prescribtion</p>
                                <p>&nbsp;</p>
                                <form>
                                  <table width="375" align="center">
                                    <tr>
                                      <td width="136"><p>&nbsp;</p>
                                      <p>View Existing Stock </p>
                                      <p>&nbsp;</p></td>
                                      <td width="223">&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td><input name="Search34223" type="submit" id="Search34223" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" onclick="javascript:popUp('http://localhost/dmr-mist/sh_all_stock.php',1000,200)"/></td>
                                      <td>&nbsp;</td>
                                    </tr>
                                  </table>
                                </form>
                                <p>&nbsp;</p>
                                <form id="form2" method="post" action="insert_prescribtion.php">
                                    <p class="style3">Hospital No
                                      <label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                      </label>
                                    </p>
                                    <p class="style3">&nbsp;</p>
                                  <table width="338" align="center">
                                      <tr>
                                        <td width="62" class="style13">CODE</td>
                                        <td width="8" class="style13">&nbsp;</td>
                                        <td width="76" class="style13">QUANTITY</td>
                                        <td width="8" class="style13">&nbsp;</td>
                                        <td width="151" class="style13">DOSAGE</td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code1" type="text" id="code1" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity1" type="text" id="quantity1" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="take1a" type="text" id="take1a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          </span>x<span class="style3">
                                          <input name="take1b" type="text" id="take1b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                                                                  </span></td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code2" type="text" id="code2" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity2" type="text" id="quantity2" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="take2a" type="text" id="take2a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          </span>x                                        <span class="style3">
                                          <input name="take2b" type="text" id="take2b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code3" type="text" id="code3" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity3" type="text" id="quantity3" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13">
                                          <input name="take3a" type="text" id="take3a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          x
                                        <input name="take3b" type="text" id="take3b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code4" type="text" id="code4" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity4" type="text" id="quantity4" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="take4a" type="text" id="take4a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          </span> x <span class="style3">
                                          <input name="take4b" type="text" id="take4b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                      </tr>
                                    <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code5" type="text" id="code5" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF" />
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity5" type="text" id="quantity5" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td>
                                           <input name="take5a" type="text" id="take5a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                       x                                          <input name="take5b" type="text" id="take5b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>                                        </td>
                                    </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code6" type="text" id="code6" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity6" type="text" id="quantity6" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td><span class="style3">
                                          <input name="take6a" type="text" id="take6a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          </span> x <span class="style3">
                                          <input name="take6b" type="text" id="take6b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code7" type="text" id="code7" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity7" type="text" id="quantity7" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td><span class="style3">
                                          <input name="take7a" type="text" id="take7a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          </span> x <span class="style3">
                                          <input name="take7b" type="text" id="take7b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code8" type="text" id="code8" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity8" type="text" id="quantity8" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td><span class="style13"><span class="style3">
                                          <input name="take8a" type="text" id="take8a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          </span> </span>x<span class="style13"> <span class="style3">
                                          <input name="take8b" type="text" id="take8b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                                                                  </span></span></td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code9" type="text" id="code9" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity9" type="text" id="quantity9" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="take9a" type="text" id="take9a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                        </span>                                           x <span class="style3">
                                        <input name="take9b" type="text" id="take9b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                      </tr>
                                      <tr>
                                        <td class="style13"><span class="style3">
                                          <input name="code10" type="text" id="code10" value="MED/" size="7" maxlength="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td class="style13"><span class="style3">
                                          <input name="quantity10" type="text" id="quantity10" size="7" width="70" style="background:#003366; color:#FFFFFF"/>
                                        </span></td>
                                        <td class="style13">&nbsp;</td>
                                        <td><span class="style13"><span class="style3">
                                          <input name="take10a" type="text" id="take10a" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                          </span> </span>x<span class="style13"> <span class="style3">
                                          <input name="take10b" type="text" id="take10b" size="7" width="50" style="background:#003366; color:#FFFFFF"/>
                                                                                  </span></span></td>
                                      </tr>
                                  </table>
                                    <p>&nbsp;</p>
                                    <p> <span class="style3">
                                          <input name="repeat2" type="checkbox" id="repeat2" value="YES" />
                                    </span>Repeat</p>
                                    <p>&nbsp;</p>
                                  <p>&nbsp;&nbsp; <span class="style3">
                                      <input name="Submit32" type="submit" id="Submit32" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add"/>
                                    </span></p>
                                    <p>&nbsp;</p>
                                  <p>
                                      <input name="Search3423" type="button" id="Search3423" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Written Prescription" onclick="javascript:popUp('http://localhost/dmr-mist/written_prescription.php',1000,900)"/>
                                  </p>
                              </form></td>
                            </tr>
                          </table>
                          <p class="style12">&nbsp;</p>
                      </div>
                      <p>&nbsp;</p>
                    </div>
                    
                      <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
     <!-- footer begins -->
            <div id="footer">
          
		    <p><span class="style11">&copy;2010. EMR-SOFT V 1.0. Powered by e-NERGY Software Solutions</span></p> 
	</div>
        <!-- footer ends -->
</div>

</div>




</body>
</html>
<?php
}
?>