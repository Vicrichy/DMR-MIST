<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$code1 = $_POST['code1'];
$code2 = $_POST['code2'];
$code3 = $_POST['code3'];
$code4 = $_POST['code4'];
$code5 = $_POST['code5'];
$code6 = $_POST['code6'];
$code7 = $_POST['code7'];
$code8 = $_POST['code8'];
$code9 = $_POST['code9'];
$code10 = $_POST['code10'];

$item1 = $_POST['item1'];
$item2 = $_POST['item2'];
$item3 = $_POST['item3'];
$item4 = $_POST['item4'];
$item5 = $_POST['item5'];
$item6 = $_POST['item6'];
$item7 = $_POST['item7'];
$item8 = $_POST['item8'];
$item9 = $_POST['item9'];
$item10 = $_POST['item10'];

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist!");
window.location = "pharmacist_page.php";
</script>
<?php
exit();
}
if($code1 != 'MED/')
{
 include('dbconnect.php');
 $c1 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code1' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c1);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code1;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 include('dbconnect.php');
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code1' AND `hospital_no` = '$hospital_no'")or die("Error");
 }
 }
if($code2 != 'MED/')
{
 include('dbconnect.php');
 $c2 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code2' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c2);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code2;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code2' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code3 != 'MED/')
{
 include('dbconnect.php');
 $c3 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code3' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c3);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code3;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code3' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code4 != 'MED/')
{
 include('dbconnect.php');
 $c4 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code4' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c4);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code4;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code4' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code5 != 'MED/')
{
 include('dbconnect.php');
 $c5 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code5' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c5);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code5;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code5' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code6 != 'MED/')
{
 include('dbconnect.php');
 $c6 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code6' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c6);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code6;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code6' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code7 != 'MED/')
{
 include('dbconnect.php');
 $c7 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code7' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c7);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code7;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code7' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code8 != 'MED/')
{
 include('dbconnect.php');
 $c8 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code8' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c8);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code8;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code8' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code9 != 'MED/')
{
 include('dbconnect.php');
 $c9 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code9' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c9);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code9;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code9' AND `hospital_no` = '$hospital_no'");
 }
 }
if($code10 != 'MED/')
{
 include('dbconnect.php');
 $c10 = mysql_query("SELECT `status` FROM `prescribtions` WHERE `prescribtion` = '$code10' AND `status` = 'ISSUED' AND `hospital_no` = '$hospital_no'");
 $status = @mysql_num_rows($c10);
 if($status >=1)
 {
 ?>
 <script type="text/javascript">
 alert("<?php echo $code10;?> has already been issued for this patient");
 </script>
 <?php
 }
 else
 {
 mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `prescribtion` = '$code10' AND `hospital_no` = '$hospital_no'");
 }
 }
 include('dbconnect.php');
 mysql_query("UPDATE `prescribtion` SET `status` = 'DISPENSED' WHERE `hospital_no` = '$hospital_no'");
?>
<script type="text/javascript">
alert("Prescription Items Successfully issued");
window.location = "pharmacist_page.php";
</script>