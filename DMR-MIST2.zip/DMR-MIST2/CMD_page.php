<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
$year = date("Y");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function logout()
{window.location = "logout.php"};
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>CMD Page| DMR - MIST</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style3 {font-size: 12px}
#Layer1 {
	position:absolute;
	width:397px;
	height:52px;
	z-index:1;
	left: 526px;
	top: 189px;
}
.style11 {color: #FFFFFF}
.style10 {color: #000033}
.style12 {color: #014377}
-->
</style>
</head>
<body>


<div id="bg2">




<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div id="buttons"><strong><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans0');">Staff</a><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans1');">Patients</a>
      <a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans2');">Wards </a><a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans3');">Accounts </a></strong><strong><a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans4');">View Reports </a></strong></div>
	 <div id="logo">
	  <div id="Layer1">
	    <div id="layer"></div>
	    <a href="#" class="style1"><?php echo $_SESSION['user_id'];?> Page </a></div>
	  <a href="#" class="style1">DMR - MIST </a>
      <h2><a href="#" id="metamorph">e-NERGY Software Solutions</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">Your Info </h1>	
                        <div class="right_b">
                          <div class="munth">
                            <p>Name: <span class="style10"><?php echo $_SESSION['name'];?></span> </p>
                            <p>Sex: <span class="style3"><?php echo $_SESSION['sex'];?></span></p>
                            <p>Dept: <span class="style3"><?php echo $_SESSION['department'];?></span></p>
                            <p>Phone: <span class="style3"><?php echo $_SESSION['phone'];?></span></p>
                            <p>Email: <span class="style3"><?php echo $_SESSION['email'];?></span></p>
                            <p>Last Login: <span class="style3"><?php echo $_SESSION['last_login'];?></span></p>
                            <p>&nbsp;</p>
                            <p><span class="style3">
                              <input name="Edit" type="button" id="Edit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Edit" />
                            </span> </p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                          </div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">Support</h1>	
                    	<div class="right_w fish_10">
                    	  <div class="munth">
                    	    <p>For technical support, please call any of the following phone numbers. </p>
                    	    <p>&nbsp;</p>
                    	    <p>Victor: 08039098042</p>
                    	    <p>&nbsp;</p>
                    	    <p>You may send us an Email: support@emrsoft.com </p>
                    	    <p>&nbsp;  </p>
                    	    <p>&nbsp;</p>
                    	    <p>&nbsp;</p>
                    	  </div>
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1> Hospital News</h1>
                       <div class="box1">
                        <div class="left_b"><span class="w">Friday, Apr.10, 2010</span><br />
                          The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Saturday, Apr. 11, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Sunday, Apr. 12, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Monday, Apr. 13, 2010</span><br />
                                   The hospital management today welcomed the minister of health of the federation on a two-day visit....
                                     <div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                      </div>
                    <div id="center">
                      <h1>Login as: <span class="style10"><?php echo $_SESSION['user_id'];?></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="Search123" type="submit" id="Search123" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Logout" onclick="logout();" />
                      </h1>
                        <div class="text" id="ans0">
                          <p class="style12">Staff Information</p>
                          <p class="style12">&nbsp; </p>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>Staff Information - By User id </p>
                                <p>&nbsp;</p>
                                <form action="any_staff_user_id_search.php" method="post" target="_blank" id="search1">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">User Id </td>
                                        <td width="223"><label>
                                          <select name="user_id" id="user_id" style="background:#003366; color:#FFFFFF">
                                            <option>Records</option>
                                            <option>Accounts</option>
                                            <option>Pharmacist</option>
                                            <option>Laboratory Staff</option>
                                            <option>Medical Consultant</option>
                                            <option>CMD</option>
                                            <option>CMAC</option>
                                            <option>Dir. Of Nursing</option>
                                            <option>Dir. Of Pharmacy</option>
                                            <option>Chief Accountant</option>
                                            <option>Ward Nurse</option>
                                            <option>Clinic Nurse</option>
                                          </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search1" type="submit" id="Search1" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                <p>Staff Information - By Name</p>
                                <p>&nbsp;</p>
                                <form action="any_staff_name_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Name</td>
                                        <td width="223"><label>
                                          <input name="name" type="text" id="name" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td width="223"><label></label></td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search33" type="submit" id="Search33" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <table width="414" height="56" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                <p>Show all staff records</p>
                                <p>&nbsp; </p>
                                <form action="sh_all_staff.php" method="post" target="_blank" id="search4">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136"><input name="Search34" type="submit" id="Search34" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" onclick="javascript:popUp('http://localhost/dmr-mist/sh_all_patient_records.php',1000,200)"/></td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                <p>Staff Availability Information - By User id</p>
                                <p>&nbsp; </p>
                                <form action="staff_availability.php" method="post" target="_blank" id="search1">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">User Id </td>
                                        <td width="223"><label>
                                        <select name="user_id" id="user_id" style="background:#003366; color:#FFFFFF">
                                          <option>Records</option>
                                          <option>Accounts</option>
                                          <option>Pharmacist</option>
                                          <option>Laboratory Staff</option>
                                          <option>Medical Consultant</option>
                                          <option>CMD</option>
                                          <option>CMAC</option>
                                          <option>Dir. Of Nursing</option>
                                          <option>Dir. Of Pharmacy</option>
                                          <option>Chief Accountant</option>
                                          <option>Ward Nurse</option>
                                          <option>Clinic Nurse</option>
                                        </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search14" type="submit" id="Search14" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                <p>Staff Login History - By User id </p>
                                <p>&nbsp;</p>
                                <form action="staff_logon.php" method="post" target="_blank" id="search1">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">User Id </td>
                                        <td width="223"><label>
                                        <select name="user_id" id="user_id" style="background:#003366; color:#FFFFFF">
                                          <option>Records</option>
                                          <option>Accounts</option>
                                          <option>Pharmacist</option>
                                          <option>Laboratory Staff</option>
                                          <option>Medical Consultant</option>
                                          <option>CMD</option>
                                          <option>CMAC</option>
                                          <option>Dir. Of Nursing</option>
                                          <option>Dir. Of Pharmacy</option>
                                          <option>Chief Accountant</option>
                                          <option>Ward Nurse</option>
                                          <option>Clinic Nurse</option>
                                        </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search142" type="submit" id="Search142" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                      </div>
                        <div class="text" id="ans1">
                          <p class="style12">Patient Information</p>
                          <p>&nbsp; </p>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>By Hospital Number</p>
                                <p>&nbsp;</p>
                                <form action="hos_no_search.php" method="post" target="_blank" id="search1">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">Hospital No </td>
                                        <td width="223"><label>
                                          <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search13" type="submit" id="Search13" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                <p>By Date of Registration</p>
                                <p>&nbsp; </p>
                                <form action="date_search.php" method="post" target="_blank" id="search2">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">Date</td>
                                        <td><label>
                                          <select name="day" id="day" style="background:#003366; color:#FFFFFF">
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                            <option>13</option>
                                            <option>14</option>
                                            <option>15</option>
                                            <option>16</option>
                                            <option>17</option>
                                            <option>18</option>
                                            <option>19</option>
                                            <option>20</option>
                                            <option>21</option>
                                            <option>22</option>
                                            <option>23</option>
                                            <option>24</option>
                                            <option>25</option>
                                            <option>26</option>
                                            <option>27</option>
                                            <option>28</option>
                                            <option>29</option>
                                            <option>30</option>
                                            <option>31</option>
                                        </select>
                                          <select name="month" id="month" style="background:#003366; color:#FFFFFF">
                                            <option>Jan</option>
                                            <option>Feb</option>
                                            <option>Mar</option>
                                            <option>Apr</option>
                                            <option>May</option>
                                            <option>Jun</option>
                                            <option>Jul</option>
                                            <option>Aug</option>
                                            <option>Sep</option>
                                            <option>Oct</option>
                                            <option>Nov</option>
                                            <option>Dec</option>
                                        </select>
                                          <input name="year" type="text" id="year" value="<?php echo $year;?>" size="5" width="40" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search323" type="submit" id="Search323" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                <p>By Names </p>
                                <p>&nbsp;</p>
                                <form action="name_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Surname</td>
                                        <td width="223"><label>
                                          <input name="lname" type="text" id="lname" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>First Name </td>
                                        <td width="223"><label>
                                          <input name="fname" type="text" id="fname" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search334" type="submit" id="Search334" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>By Surname Only</p>
                                  <p>&nbsp;</p>
                                  <form action="surname_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Surname</td>
                                        <td width="223"><label>
                                          <input name="lname" type="text" id="lname" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search3322" type="submit" id="Search3322" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>By First Name Only</p>
                                  <p>&nbsp;</p>
                                  <form action="fname_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">First Name </td>
                                        <td width="223"><label>
                                          <input name="fname" type="text" id="fname" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search3332" type="submit" id="Search3332" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <table width="414" height="56" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>&nbsp;</p>
                                <p>Show all Patient registration records </p>
                                <p>&nbsp;</p>
                                <form action="sh_all_patient_records.php" method="post" target="_blank" id="search4">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136"><input name="Search342" type="submit" id="Search342" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" onclick="javascript:popUp('http://localhost/dmr-mist/sh_all_patient_records.php',1000,200)"/></td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                      </div>
                        <div class="text" id="ans2">
                          <p class="style12">Ward Information</p>
                          <p class="style12">&nbsp; </p>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>By Ward Name </p>
                                <p>&nbsp;</p>
                                <form action="ward_name_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Name</td>
                                        <td width="223"><label>
                                          <select name="name" id="name" style="background:#003366; color:#FFFFFF">
                                            <option>A&amp;E</option>
                                            <option>Male Surgical</option>
                                            <option>Female Surgical</option>
                                            <option>Maternity</option>
                                            <option>Post Natal</option>
                                            <option>Labour</option>
                                            <option>Pediatric</option>
                                          </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search3342" type="submit" id="Search3342" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>View Ward Reports by Date </p>
                                  <p>&nbsp;</p>
                                  <form action="ward_report_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Date</td>
                                        <td><label>
                                          <select name="day" id="day" style="background:#003366; color:#FFFFFF">
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                            <option>13</option>
                                            <option>14</option>
                                            <option>15</option>
                                            <option>16</option>
                                            <option>17</option>
                                            <option>18</option>
                                            <option>19</option>
                                            <option>20</option>
                                            <option>21</option>
                                            <option>22</option>
                                            <option>23</option>
                                            <option>24</option>
                                            <option>25</option>
                                            <option>26</option>
                                            <option>27</option>
                                            <option>28</option>
                                            <option>29</option>
                                            <option>30</option>
                                            <option>31</option>
                                          </select>
                                          <select name="month" id="month" style="background:#003366; color:#FFFFFF">
                                            <option>Jan</option>
                                            <option>Feb</option>
                                            <option>Mar</option>
                                            <option>Apr</option>
                                            <option>May</option>
                                            <option>Jun</option>
                                            <option>Jul</option>
                                            <option>Aug</option>
                                            <option>Sep</option>
                                            <option>Oct</option>
                                            <option>Nov</option>
                                            <option>Dec</option>
                                          </select>
                                          <input name="year" type="text" id="year" value="<?php echo $year;?>" size="5" width="40" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>Ward</td>
                                        <td><select name="ward" id="ward" style="background:#003366; color:#FFFFFF">
                                            <option>A&amp;E</option>
                                            <option>Male Surgical</option>
                                            <option>Female Surgical</option>
                                            <option>Maternity</option>
                                            <option>Post Natal</option>
                                            <option>Labour</option>
                                            <option>Pediatric</option>
                                        </select></td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search33222" type="submit" id="Search33222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show all wards </p>
                                <form action="sh_all_ward.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136"><input name="Search33322" type="submit" id="Search33322" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show admissions by ward </p>
                                  <p>&nbsp;</p>
                                  <form action="cmd_admission_name_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Name</td>
                                        <td width="223"><label>
                                          <select name="ward" id="ward" style="background:#003366; color:#FFFFFF">
                                            <option>A&amp;E</option>
                                            <option>Male Surgical</option>
                                            <option>Female Surgical</option>
                                            <option>Maternity</option>
                                            <option>Post Natal</option>
                                            <option>Labour</option>
                                            <option>Pediatric</option>
                                          </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search33422" type="submit" id="Search33422" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <p>&nbsp;</p>
                                <p>Show admission by patient</p>
                                <p>&nbsp;</p>
                                <form action="cmd_admission_hospital_no_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Hospital No </td>
                                        <td width="223"><label>
                                          <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search33423" type="submit" id="Search33423" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <p>&nbsp;</p>
                                <p>Show all admission records</p>
                                <p>&nbsp;</p>
                                <form action="sh_all_admission_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136"><input name="Search3332222" type="submit" id="Search3332222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                              <p> </p></td>
                            </tr>
                          </table>
                      </div>
                      <div class="text" id="ans3">
                        <p class="style12">Accounts</p>
                          <p class="style12">&nbsp;</p>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>Show By Hospital No. </p>
                                <p>&nbsp;</p>
                                <form action="receipt_search.php" method="post" target="_blank" id="search1">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">Hospital No </td>
                                        <td width="223"><label>
                                          <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search132" type="submit" id="Search132" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show By  Date </p>
                                  <p>&nbsp;</p>
                                  <form action="receipt_date_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Date</td>
                                        <td><label>
                                          <select name="day" id="day" style="background:#003366; color:#FFFFFF">
                                            <option>01</option>
                                            <option>02</option>
                                            <option>03</option>
                                            <option>04</option>
                                            <option>05</option>
                                            <option>06</option>
                                            <option>07</option>
                                            <option>08</option>
                                            <option>09</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                            <option>13</option>
                                            <option>14</option>
                                            <option>15</option>
                                            <option>16</option>
                                            <option>17</option>
                                            <option>18</option>
                                            <option>19</option>
                                            <option>20</option>
                                            <option>21</option>
                                            <option>22</option>
                                            <option>23</option>
                                            <option>24</option>
                                            <option>25</option>
                                            <option>26</option>
                                            <option>27</option>
                                            <option>28</option>
                                            <option>29</option>
                                            <option>30</option>
                                            <option>31</option>
                                          </select>
                                          <select name="month" id="month" style="background:#003366; color:#FFFFFF">
                                            <option>Jan</option>
                                            <option>Feb</option>
                                            <option>Mar</option>
                                            <option>Apr</option>
                                            <option>May</option>
                                            <option>Jun</option>
                                            <option>Jul</option>
                                            <option>Aug</option>
                                            <option>Sep</option>
                                            <option>Oct</option>
                                            <option>Nov</option>
                                            <option>Dec</option>
                                          </select>
                                          <input name="year" type="text" id="year" value="<?php echo $year;?>" size="5" width="40" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search332222" type="submit" id="Search332222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show all Records</p>
                                  <p>&nbsp;</p>
                                  <form action="sh_all_receipt.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136"><input name="Search333222" type="submit" id="Search333222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show by Section and Date </p>
                                  <p>&nbsp;</p>
                                  <form action="receipt_section_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Date</td>
                                        <td><label>
                                          <select name="day" id="day" style="background:#003366; color:#FFFFFF">
                                            <option>01</option>
                                            <option>02</option>
                                            <option>03</option>
                                            <option>04</option>
                                            <option>05</option>
                                            <option>06</option>
                                            <option>07</option>
                                            <option>08</option>
                                            <option>09</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                            <option>13</option>
                                            <option>14</option>
                                            <option>15</option>
                                            <option>16</option>
                                            <option>17</option>
                                            <option>18</option>
                                            <option>19</option>
                                            <option>20</option>
                                            <option>21</option>
                                            <option>22</option>
                                            <option>23</option>
                                            <option>24</option>
                                            <option>25</option>
                                            <option>26</option>
                                            <option>27</option>
                                            <option>28</option>
                                            <option>29</option>
                                            <option>30</option>
                                            <option>31</option>
                                          </select>
                                          <select name="month" id="month" style="background:#003366; color:#FFFFFF">
                                            <option>Jan</option>
                                            <option>Feb</option>
                                            <option>Mar</option>
                                            <option>Apr</option>
                                            <option>May</option>
                                            <option>Jun</option>
                                            <option>Jul</option>
                                            <option>Aug</option>
                                            <option>Sep</option>
                                            <option>Oct</option>
                                            <option>Nov</option>
                                            <option>Dec</option>
                                          </select>
                                          <input name="year" type="text" id="year" value="<?php echo $year;?>" size="5" width="40" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>Section</td>
                                        <td><label>
                                          <select name="section" id="section" style="background:#003366; color:#FFFFFF">
                                            <option>Pharmacy</option>
                                            <option>Lab</option>
                                            <option>Records</option>
                                            <option>A&amp;E ward</option>
                                            <option>Male Surgical ward</option>
                                            <option>Female Surgical ward</option>
                                            <option>Maternity</option>
                                            <option>Post Natal</option>
                                            <option>Labour</option>
                                            <option>Pediatric</option>
                                          </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search3322223" type="submit" id="Search3322223" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                              <p></p></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p>
                          <p class="style12">Pharmacy Stock </p>
                          <p>&nbsp;</p>
                          <table width="414" height="212" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p align="left" class="style3">Search by Name </p>
                                <p align="left" class="style3">&nbsp;</p>
                                <form action="drug_name_search.php" method="post" target="_blank" id="search1">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Name </td>
                                        <td width="223"><label>
                                          <input name="name" type="text" id="name" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search12" type="submit" id="Search12" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <div align="left">
                                    <p>Search by Code  </p>
                                    <p>&nbsp;</p>
                                </div>
                                <form action="drug_code_search.php" method="post" target="_blank" id="search2">
                                    <table width="371" align="center">
                                      <tr>
                                        <td width="136">Code </td>
                                        <td width="223"><label>
                                          <input name="code" type="text" id="code" style="background:#003366; color:#FFFFFF"  />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search1222" type="submit" id="Search1222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <div align="left">
                                    <p>Show all stock  </p>
                                    <p>&nbsp;</p>
                                </div>
                                <form action="sh_all_stock.php" method="post" target="_blank" id="search4">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136"><input name="Search3422" type="submit" id="Search3422" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" onclick="javascript:popUp('http://localhost/dmr-mist/sh_all_patient_records.php',1000,200)"/></td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p>
                      </div>
                      <div class="text" id="ans4">
                          <p class="style12">Show Reports</p>
                          <p class="style12">&nbsp; </p>
                          <table width="414" height="109" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><p>Show Report by Staff </p>
                                <p>&nbsp;</p>
                                <form action="cmd_report_search.php" method="post" target="_blank" id="search1">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Staff </td>
                                        <td width="223"><label>
                                          <select name="staff" id="staff" style="background:#003366; color:#FFFFFF">
                                            <option>Dir. of Pharmacy</option>
                                            <option>Chief Accountant</option>
                                            <option>Dir. of Nursing</option>
                                            <option>CMAC</option>
                                          </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search1322" type="submit" id="Search1322" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View" /></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show Report by  Date and Staff </p>
                                  <p>&nbsp;</p>
                                  <form action="cmd_report_date_search.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Date</td>
                                        <td><label>
                                          <select name="day" id="day" style="background:#003366; color:#FFFFFF">
                                            <option>01</option>
                                            <option>02</option>
                                            <option>03</option>
                                            <option>04</option>
                                            <option>05</option>
                                            <option>06</option>
                                            <option>07</option>
                                            <option>08</option>
                                            <option>09</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                            <option>13</option>
                                            <option>14</option>
                                            <option>15</option>
                                            <option>16</option>
                                            <option>17</option>
                                            <option>18</option>
                                            <option>19</option>
                                            <option>20</option>
                                            <option>21</option>
                                            <option>22</option>
                                            <option>23</option>
                                            <option>24</option>
                                            <option>25</option>
                                            <option>26</option>
                                            <option>27</option>
                                            <option>28</option>
                                            <option>29</option>
                                            <option>30</option>
                                            <option>31</option>
                                          </select>
                                          <select name="month" id="month" style="background:#003366; color:#FFFFFF">
                                            <option>Jan</option>
                                            <option>Feb</option>
                                            <option>Mar</option>
                                            <option>Apr</option>
                                            <option>May</option>
                                            <option>Jun</option>
                                            <option>Jul</option>
                                            <option>Aug</option>
                                            <option>Sep</option>
                                            <option>Oct</option>
                                            <option>Nov</option>
                                            <option>Dec</option>
                                          </select>
                                          <input name="year" type="text" id="year" value="<?php echo $year;?>" size="5" width="40" style="background:#003366; color:#FFFFFF" />
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>Staff </td>
                                        <td><label>
                                          <select name="staff" id="staff" style="background:#003366; color:#FFFFFF">
                                            <option>Dir. of Pharmacy</option>
                                            <option>Chief Accountant</option>
                                            <option>Dir. of Nursing</option>
                                            <option>CMAC</option>
                                          </select>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search3322222" type="submit" id="Search3322222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show all Reports by date </p>
                                  <p>&nbsp;</p>
                                  <form action="cmd_report_date_only.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136">Date</td>
                                        <td><label>
                                          <select name="day" id="day" style="background:#003366; color:#FFFFFF">
                                            <option>01</option>
                                            <option>02</option>
                                            <option>03</option>
                                            <option>04</option>
                                            <option>05</option>
                                            <option>06</option>
                                            <option>07</option>
                                            <option>08</option>
                                            <option>09</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                            <option>13</option>
                                            <option>14</option>
                                            <option>15</option>
                                            <option>16</option>
                                            <option>17</option>
                                            <option>18</option>
                                            <option>19</option>
                                            <option>20</option>
                                            <option>21</option>
                                            <option>22</option>
                                            <option>23</option>
                                            <option>24</option>
                                            <option>25</option>
                                            <option>26</option>
                                            <option>27</option>
                                            <option>28</option>
                                            <option>29</option>
                                            <option>30</option>
                                            <option>31</option>
                                          </select>
                                          <select name="month" id="month" style="background:#003366; color:#FFFFFF">
                                            <option>Jan</option>
                                            <option>Feb</option>
                                            <option>Mar</option>
                                            <option>Apr</option>
                                            <option>May</option>
                                            <option>Jun</option>
                                            <option>Jul</option>
                                            <option>Aug</option>
                                            <option>Sep</option>
                                            <option>Oct</option>
                                            <option>Nov</option>
                                            <option>Dec</option>
                                          </select>
                                          <input name="year" type="text" id="year" value="<?php echo $year;?>" size="5" width="40" style="background:#003366; color:#FFFFFF"/>
                                        </label></td>
                                      </tr>
                                      <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td><input name="Search33222222" type="submit" id="Search33222222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td>&nbsp;</td>
                                      </tr>
                                    </table>
                                </form>
                                <hr />
                                  <p>Show all Reports </p>
                                  <p>&nbsp;</p>
                                  <form action="sh_all_cmd_reports.php" method="post" target="_blank" id="search3">
                                    <table width="375" align="center">
                                      <tr>
                                        <td width="136"><input name="Search33322222" type="submit" id="Search33322222" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="View"/></td>
                                        <td width="223">&nbsp;</td>
                                      </tr>
                                    </table>
                              </form></td>
                            </tr>
                          </table>
                      </div>
                        <p>&nbsp;</p>
                    </div>
                    
                      <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
     <!-- footer begins -->
            <div id="footer">
          
		    <p><span class="style11">&copy;2010. EMR-SOFT V 1.0. Powered by e-NERGY Software Solutions</span></p> 
	</div>
        <!-- footer ends -->
</div>

</div>




</body>
</html>
<?php
}
?>