<?php

session_start();

$ward = $_POST['ward'];
$deaths = $_POST['deaths'];
$nurses = $_POST['nurses'];
$general_summary = $_POST['general_summary'];
$critical_cases = $_POST['critical_cases'];
$referrals = $_POST['referrals'];
$discharges = $_POST['discharges'];
$admissions = $_POST['admissions'];
$births = $_POST['births'];
$recommendations = $_POST['recommendations'];
$problems = $_POST['problems'];
$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');
mysql_query("INSERT INTO report(ward,deaths,nurses,general_summary,critical_cases,referrals,discharges,admissions,births,
recommendations,problems,date_added)VALUES('$ward','$deaths','$nurses','$general_summary','$critical_cases','$referrals','$discharges','$admissions','$births','$recommendations','$problems','$date_added')");
?>
<script type="text/javascript">
alert("New report Successfully added");
window.location = "nurse_page.php";
</script>