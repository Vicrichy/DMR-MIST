<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$code1 = $_POST['code1'];
$code2 = $_POST['code2'];
$code3 = $_POST['code3'];
$code4 = $_POST['code4'];
$code5 = $_POST['code5'];
$code6 = $_POST['code6'];
$code7 = $_POST['code7'];
$code8 = $_POST['code8'];
$code9 = $_POST['code9'];
$code10 = $_POST['code10'];

$quantity1 = $_POST['quantity1'];
$quantity2 = $_POST['quantity2'];
$quantity3 = $_POST['quantity3'];
$quantity4 = $_POST['quantity4'];
$quantity5 = $_POST['quantity5'];
$quantity6 = $_POST['quantity6'];
$quantity7 = $_POST['quantity7'];
$quantity8 = $_POST['quantity8'];
$quantity9 = $_POST['quantity9'];
$quantity10 = $_POST['quantity10'];
$take1a = $_POST['take1a'];
$take1b = $_POST['take1b'];
$take2a = $_POST['take2a'];
$take3a = $_POST['take3a'];
$take4a = $_POST['take4a'];
$take5a = $_POST['take5a'];
$take6a = $_POST['take6a'];
$take7a = $_POST['take7a'];
$take8a = $_POST['take8a'];
$take9a = $_POST['take9a'];
$take10a = $_POST['take10a'];
$take2b = $_POST['take2b'];
$take3b = $_POST['take3b'];
$take4b = $_POST['take4b'];
$take5b = $_POST['take5b'];
$take6b = $_POST['take6b'];
$take7b = $_POST['take7b'];
$take8b = $_POST['take8b'];
$take9b = $_POST['take9b'];
$take10b = $_POST['take10b'];

$dosage1 = "$quantity1: $take1a X $take1b";
$dosage2 = "$quantity2: $take2a X $take2b";
$dosage3 = "$quantity3: $take3a X $take3b";
$dosage4 = "$quantity4: $take4a X $take4b";
$dosage5 = "$quantity5: $take5a X $take5b";
$dosage6 = "$quantity6: $take6a X $take6b";
$dosage7 = "$quantity7: $take7a X $take7b";
$dosage8 = "$quantity8: $take8a X $take8b";
$dosage9 = "$quantity9: $take9a X $take9b";
$dosage10 = "$quantity10: $take10a X $take10b";

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist!");
window.location = "medical_consultant_page.php";
</script>
<?php
exit();
}
if($code1 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code1'");
 $name = @mysql_result($ag, 0, "name");
 $c1 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code1'");
 $price1 = @mysql_result($c1,0,"unit_price");
 $price1 = $price1 * $quantity1;
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price1', `dosage` = '$dosage1',`quantity` = '$quantity1'") or die("Error");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code1'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity1;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code1'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price1', `date_added` = '$date_added', `section` = 'Pharmacy', `quantity` = '$quantity1'") or die("ERROR");
}
if($code2 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code2'");
 $name = @mysql_result($ag, 0, "name");
 $c2 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code2'");
 $price2 = @mysql_result($c2,0,"unit_price");
 $price2 = $price2 * $quantity2;
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price2', `dosage` = '$dosage2', `quantity` = '$quantity2'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code2'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity2;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code2'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price2', `date_added` = '$date_added',`section` = 'Pharmacy', `quantity` = '$quantity2'") or die("ERROR");
}
if($code3 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code3'");
 $name = @mysql_result($ag, 0, "name");
 $c3 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code3'");
 $price3 = @mysql_result($c3,0,"unit_price");
 $price3 = $price3 * $quantity3;
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price3', `dosage` = '$dosage3',`quantity` = '$quantity3'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code3'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity3;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code3'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price3', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity3'") or die("ERROR");
}
if($code4 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code4'");
 $name = @mysql_result($ag, 0, "name");
 $c4 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code4'");
 $price4 = @mysql_result($c4,0,"unit_price");
 $price4 = $price4 * $quantity4; 
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price4', `dosage` = '$dosage4',`quantity` = '$quantity4'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code4'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity4;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code4'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price4', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity4") or die("ERROR");
}
if($code5 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code5'");
 $name = @mysql_result($ag, 0, "name");
 $c5 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code5'");
 $price5 = @mysql_result($c5,0,"unit_price");
 $price5 = $price5 * $quantity5; 
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price5', `dosage` = '$dosage5',`quantity` = '$quantity5'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code5'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity5;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code5'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price5', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity5'") or die("ERROR");
}
if($code6 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code6'");
 $name = @mysql_result($ag, 0, "name");
 $c6 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code6'");
 $price6 = @mysql_result($c6,0,"unit_price");
 $price6 = $price6 * $quantity6; 
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price6', `dosage` = '$dosage6',`quantity` = '$quantity6'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code6'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity6;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code6'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price6', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity6'") or die("ERROR");
}
if($code7 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code7'");
 $name = @mysql_result($ag, 0, "name");
 $c7 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code7'");
 $price7 = @mysql_result($c7,0,"unit_price");
 $price7 = $price7 * $quantity7; 
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price7', `dosage` = '$dosage7',`quantity` = '$quantity7'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code7'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity7;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code7'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price7', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity7'") or die("ERROR");
}
if($code8 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code8'");
 $name = @mysql_result($ag, 0, "name");
 $c8 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code8'");
 $price8 = @mysql_result($c8,0,"unit_price");
 $price8 = $price8 * $quantity8; 
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price8', `dosage` = '$dosage8',`quantity` = '$quantity8'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code8'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity8;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code8'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price8', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity8") or die("ERROR");
}
if($code9 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code9'");
 $name = @mysql_result($ag, 0, "name");
 $c9 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code9'");
 $price9 = @mysql_result($c9,0,"unit_price");
 $price9 = $price9 * $quantity9;
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price9', `dosage` = '$dosage9',`quantity` = '$quantity9'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code9'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity9;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code9'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price9', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity9'") or die("ERROR");
}
if($code10 != 'MED/')
{
 include('dbconnect.php');
 $ag = mysql_query("SELECT `name` FROM `pharmacy` WHERE `code` = '$code10'");
 $name = @mysql_result($ag, 0, "name");
 $c10 = mysql_query("SELECT `unit_price` FROM `pharmacy` WHERE `code` = '$code10'");
 $price10 = @mysql_result($c10,0,"unit_price");
 $price10 = $price10 * $quantity10; 
 mysql_query("INSERT INTO `prescribtions` SET `prescribtion` = '$name', `hospital_no` = '$hospital_no', `price` = '$price10', `dosage` = '$dosage10',`quantity` = '$quantity10'");
 $query = mysql_query("SELECT `balance` FROM `pharmacy` WHERE `code` = '$code10'");
 $balance = @mysql_result($query,0, "balance");
 $n_balance = $balance - $quantity10;
 mysql_query("UPDATE `pharmacy` SET `balance` = '$n_balance' WHERE `code` = '$code10'");
 mysql_query("INSERT INTO `accounts` SET `item` = '$name', `hospital_no` = '$hospital_no', `amount` = '$price10', `date_added` = '$date_added',`section` = 'Pharmacy',`quantity` = '$quantity10'") or die("ERROR");
}
$code = rand();
$no = "UUTH/PRES/$code";
include('dbconnect.php');

$sql = mysql_query("SELECT `prescribtion` FROM `prescribtions` WHERE `hospital_no` = '$hospital_no'");
$number = @mysql_num_rows($sql);
$repeat = $_POST['repeat'];

mysql_query("INSERT INTO `prescribtion` SET `date_added` = '$date_added', `prescribtion_no` = '$no', `repeat` = '$repeat', `doctor` = '$_SESSION[user_id]', `number` = '$number', `hospital_no` = '$hospital_no', `financial_status` = 'NOT CLEARED'");
?>
<script type="text/javascript">
alert("Patient Prescription Record Successfully added");
window.location = "medical_consultant_page.php";
</script>