<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$procedure1 = $_POST['procedure1'];
$procedure2 = $_POST['procedure2'];
$procedure3 = $_POST['procedure3'];
$procedure4 = $_POST['procedure4'];
$procedure5 = $_POST['procedure5'];
$procedure6 = $_POST['procedure6'];
$procedure7 = $_POST['procedure7'];
$procedure8 = $_POST['procedure8'];
$procedure9 = $_POST['procedure9'];
$procedure10 = $_POST['procedure10'];

$result1 = $_POST['result1'];
$result2 = $_POST['result2'];
$result3 = $_POST['result3'];
$result4 = $_POST['result4'];
$result5 = $_POST['result5'];
$result6 = $_POST['result6'];
$result7 = $_POST['result7'];
$result8 = $_POST['result8'];
$result9 = $_POST['result9'];
$result10 = $_POST['result10'];

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `procedures` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist!");
window.location = "laboratory_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');

$sql = mysql_query("SELECT `schedule` FROM `procedures` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Patient has not yet been scheduled!");
window.location = "laboratory_page.php";
</script>
<?php
exit();
}
if(($procedure1 != '') && ($result1 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure1', `result` = '$result1', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure2 != '') && ($result2 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure2', `result` = '$result2', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure3 != '') && ($result3 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure3', `result` = '$result3', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure4 != '') && ($result4 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure4', `result` = '$result4', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure5 != '') && ($result5 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure5', `result` = '$result5', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure6 != '') && ($result6 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure6', `result` = '$result6', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure7 != '') && ($result7 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure7', `result` = '$result7', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure8 != '') && ($result8 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure8', `result` = '$result8', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure9 != '') && ($result9 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure9', `result` = '$result9', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
if(($procedure10 != '') && ($result10 != ''))
{
 include('dbconnect.php');
 mysql_query("INSERT INTO `results` SET `procedure` = '$procedure10', `result` = '$result10', `date_added` = '$date_added', `hospital_no` = '$hospital_no'") or die("Error");
 }
 mysql_query("UPDATE `procedures` SET `status` = 'PATIENT TESTED' WHERE `hospital_no` = '$hospital_no'");
?>
<script type="text/javascript">
alert("Patient Laboratory Results Record Successfully added");
window.location = "laboratory_page.php";
</script>