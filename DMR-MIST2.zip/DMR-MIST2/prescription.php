<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
$year = date("Y");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script LANGUAGE="JavaScript">

function popUp(URL,popW,popH) {

var w = 480, h = 340;

if (document.all || document.layers) {
   w = screen.availWidth;
   h = screen.availHeight;
}

var topPos = 0, leftPos = (w-popW)/2;


   window.open(URL,'popup','resizable, toolbar=no, location=no, status=no, scrollbars=yes, horizontal scrollbars=yes, scroll=yes, menubar=no, titlebar=no, width=' + popW + ',height=' + popH + ',left=' + leftPos + ',top=' + topPos + ',screenX=' + leftPos + ',screenY=' + topPos);

}
// -->
</script>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function logout()
{window.location = "logout.php"};
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Laboratory Page| DMR - MIST</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style3 {font-size: 12px}
#Layer1 {
	position:absolute;
	width:397px;
	height:52px;
	z-index:1;
	left: 526px;
	top: 189px;
}
.style11 {color: #FFFFFF}
.style10 {color: #000033}
.style12 {color: #014377}
.style13 {font-size: 10px}
-->
</style>
</head>
<body>


<div id="bg2">




<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div id="buttons"></div>
	 <div id="logo">
	  <div id="Layer1">
	    <div id="layer"></div>
	    <a href="#" class="style1"><?php echo $_SESSION['user_id'];?> Page </a></div>
	  <a href="#" class="style1">DMR - MIST </a>
      <h2><a href="#" id="metamorph">e-NERGY Software Solutions</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">Your Info </h1>	
                        <div class="right_b">
                          <div class="munth">
                            <p>Name: <span class="style10"><?php echo $_SESSION['name'];?></span> </p>
                            <p>Sex: <span class="style3"><?php echo $_SESSION['sex'];?></span></p>
                            <p>Dept: <span class="style3"><?php echo $_SESSION['department'];?></span></p>
                            <p>Phone: <span class="style3"><?php echo $_SESSION['phone'];?></span></p>
                            <p>Email: <span class="style3"><?php echo $_SESSION['email'];?></span></p>
                            <p>Last Login: <span class="style3"><?php echo $_SESSION['last_login'];?></span></p>
                            <p>&nbsp;</p>
                            <p><span class="style3">
                              <input name="Edit" type="button" id="Edit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Edit" />
                            </span> </p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                          </div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">Support</h1>	
                    	<div class="right_w fish_10">
                    	  <div class="munth">
                    	    <p>For technical support, please call any of the following phone numbers. </p>
                    	    <p>&nbsp;</p>
                    	    <p>Victor: 08039098042</p>
                    	    <p>&nbsp;</p>
                    	    <p>You may send us an Email: support@emrsoft.com </p>
                    	    <p>&nbsp;  </p>
                    	    <p>&nbsp;</p>
                    	    <p>&nbsp;</p>
                    	  </div>
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1> Hospital News</h1>
                       <div class="box1">
                        <div class="left_b"><span class="w">Friday, Apr.10, 2010</span><br />
                          The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Saturday, Apr. 11, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Sunday, Apr. 12, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Monday, Apr. 13, 2010</span><br />
                                   The hospital management today welcomed the minister of health of the federation on a two-day visit....
                                     <div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                      </div>
                    <div id="center">
                      <h1>Login as: <span class="style10"><?php echo $_SESSION['user_id'];?></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h1>
                      <div class="text" id="ans3">
                        <p class="style12">Prescription</p>
                          <p class="style12">&nbsp;</p>
                          <p class="style12">&nbsp;</p>
                      </div>
                      <p>&nbsp;</p>
                    </div>
                    
                      <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
     <!-- footer begins -->
            <div id="footer">
          
		    <p><span class="style11">&copy;2010. EMR-SOFT V 1.0. Powered by e-NERGY Software Solutions</span></p> 
	</div>
        <!-- footer ends -->
</div>

</div>




</body>
</html>
<?php
}
?>