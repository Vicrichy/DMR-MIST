<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search Results:: Lab Results Search</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000033;
}
-->
</style></head>

<body>

<p>
  <?php

$day = addslashes($_POST['day']);
$month = addslashes($_POST['month']);
$year = addslashes($_POST['year']);

$date = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no`,`procedure`,`result`,`date_added` FROM results WHERE `date_added`='$date'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
  <script type="text/javascript">
alert("Sorry! Records not found on this date");
window.location = "laboratory_page.php");
</script>
  <?php  
exit();
}
else
{
echo "<html>";
	echo "<table width=950 height=187 align=center>";
	echo "<tr>";
	echo " <td valign=top bgcolor=#FFFFC1><table width=942 border=1>";
	echo "<tr>";
	echo "<td width=76><strong>Hospital No </strong></td>
        <td width=76><strong>Procedure </strong></td>
        <td width=76><strong>Result </strong></td>
        <td width=76><strong>Date Added </strong></td>
        </tr>";
	while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	}
	
	echo "</table></html>"; 
}
?>	
</p>
<p>&nbsp;</p>
<p align="center"><strong>WRITTEN RESULTS </strong></p>
<table width="820" height="82" align="center">
  <tr>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p>
      <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky = mysql_query("SELECT `results` FROM `written_results` WHERE `hospital_no` = '$hospital_no'")or die("Fatal Error");
   $viky2 = mysql_query("SELECT `date_added` FROM `written_results` WHERE `hospital_no` = '$hospital_no'")or die("Lucy Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PROCEDURE REQUEST RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Examination</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2><a href=results/$col_value>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
	echo "</table></html>"; 
	
	
	
	}?>
    </p></td>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p>
      <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky2 = mysql_query("SELECT `date_added` FROM `written_results` WHERE `hospital_no` = '$hospital_no'")or die("Error");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN PROCEDURE REQUEST RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Date Added</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky2, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
		echo "</table></html>"; 
	
	
	
	}?>
    </p></td>
  </tr>
</table>
<p>&nbsp;</p>
