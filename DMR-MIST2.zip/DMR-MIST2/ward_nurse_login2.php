<?php
session_start();

$user_id1 = $_SESSION['user_id1'];
$password = $_SESSION['password'];
$name = $_SESSION['name'];

if($user_id1 == 'Ward Nurse')
 {
  include('dbconnect.php');
  $sql = mysql_query("SELECT * FROM `staff` WHERE `user_id`='$user_id1' AND `password`='$password' AND `name` = '$name'")or die("Error");

$num_rows = @mysql_num_rows($sql);

if($num_rows==1)
{
$_SESSION['auth']= 3;

while($row = mysql_fetch_array($sql) )
{
  $_SESSION['name']= $row['name'];
  $_SESSION['user_id']= $row['user_id']; 
  $_SESSION['sex'] = $row['sex'];
  $_SESSION['phone'] = $row['phone'];
  $_SESSION['email'] = $row['email'];
  $_SESSION['department'] = $row['department'];
  $_SESSION['last_login'] = $row['time'];
}  
  include('dbconnect.php');  
  mysql_query("INSERT INTO login SET user_id = '$user_id1', time = NOW(), name = '$_SESSION[name]'");
  include('dbconnect.php');
  mysql_query("UPDATE `staff` SET `time` = NOW(), `status` = 'AVAILABLE' WHERE `user_id` = '$user_id1' AND `password` = '$password'") or die("Error");

header("location:ward_nurse_page.php");
exit();
}
}
else
{
?>
<script type="text/javascript">
alert("INVALID USER ID OR PASSWORD");
window.location = "index.php";
</script>
<?php
}
?>