<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$ward = $_POST['ward'];
$bed = $_POST['bed'];
$reason = $_POST['reason'];

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');
$check = mysql_query("SELECT `hospital_no` FROM `admission` WHERE `hospital_no` = '$hospital_no'");

$num_rows2 = @mysql_num_rows($check);
if($num_rows2 ==0)
{
?>
<script type="text/javascript">
alert("ERROR: Patient Has not been admitted!");
window.location = "ward_nurse_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist! Please try again");
window.location = "ward_nurse_page.php";
</script>
<?php
exit();
}
$discharge = mysql_query("SELECT `hospital_no` FROM `discharge` WHERE `hospital_no` = '$hospital_no'");
$row = @mysql_num_rows($discharge);
if($row ==0)
{
?>
<script type="text/javascript">
alert("Doctor has not yet discharged this patient!");
window.location = "ward_nurse_page.php";
</script>
<?php
exit();
}
$ag = mysql_query("SELECT `status` FROM `accounts` WHERE `hospital_no` = '$hospital_no' AND `status` = ''");
$finance = @mysql_num_rows($ag);
if($finance >0)
{
?>
<script type="text/javascript">
alert("ERROR: Patient has not cleared debt with accounts");
window.location = "ward_nurse_page.php";
</script>
<?php
}
include('dbconnect.php');
mysql_query("UPDATE `discharge` SET `ward` = '$ward',`bed` = '$bed',`reason`= '$reason',`date_added` = '$date_added' WHERE `hospital_no` = '$hospital_no'");

include('dbconnect.php');
$vik = mysql_query("SELECT `no_of_beds` FROM `wards` WHERE `name` = '$ward'");
$no_of_beds = @mysql_result($vik, 0, "no_of_beds");
$no_of_beds = $no_of_beds + 1;

include('dbconnect.php');
$viky = mysql_query("SELECT `no_of_patients` FROM `wards` WHERE `name` = '$ward'");
$no_of_patients = @mysql_result($viky, 0, "no_of_patients");
$no_of_patients = $no_of_patients - 1;

include('dbconnect.php');
mysql_query("UPDATE `wards` SET `no_of_beds` = '$no_of_beds', `no_of_patients` = '$no_of_patients' WHERE `name` = '$ward'");
mysql_query("UPDATE `patients` SET `admission` = 'DISCHARGED' WHERE `hospital_no` = '$hospital_no'");
mysql_query("UPDATE `examination` SET `admission` = 'DISCHARGED' WHERE `hospital_no` = '$hospital_no'");
mysql_query("DELETE FROM `admission` WHERE `hospital_no` = '$hospital_no'");
?>
<script type="text/javascript">
alert("Patient has successfully been discharged");
window.location = "ward_nurse_page.php";
</script>