<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$systole = $_POST['systole'];
$diastole = $_POST['diastole'];
$puls = $_POST['pulse'];
$temperature = $_POST['temperature'];
$weight = $_POST['weight'];
$height = $_POST['height'];
$oxygen = $_POST['oxygen'];
$respiration = $_POST['respiration'];
$regular = $_POST['regular'];
$normal = $_POST['normal'];
$pulse = "$puls($regular,$normal)";


$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

mysql_query("INSERT INTO  vital_signs(hospital_no,systole,diastole,pulse,temperature,weight,height,oxygen,respiration,date_added)VALUES('$hospital_no','$systole','$diastole','$pulse','$temperature','$weight','$height','$oxygen','$respiration','$date_added')") or die("ERROR::");
?>
<script type="text/javascript">
alert("New Patient Vital Signs successfully added");
window.location = "nurse_page.php";
</script>