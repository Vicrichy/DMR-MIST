<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search Results::Ward Search</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000033;
}
-->
</style></head>

<body>

<?php

$count=0;


include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no`,`ward`,`bed`,`reason`,`date_added`,`discharged_by` FROM discharge ORDER by id");

echo "<html>";
	echo "<table width=950 height=187 align=center>";
	echo "<tr>";
	echo " <td valign=top bgcolor=#FFFFC1><table width=942 border=1>";
	echo "<tr>";
	echo "<td width=76><strong>Hospital No </strong></td>
        <td width=76><strong>Ward </strong></td>
        <td width=76><strong>Bed </strong></td>
        <td width=76><strong>Reason Discharged</strong></td>
        <td width=75><strong>Date Discharged  </strong></td>
        <td width=75><strong>Doctor Incharge  </strong></td>
		</tr>";
	while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	}
	
	echo "</table></html>"; 

?>	