<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$activity = $_POST['activity'];
$consultant = $_POST['consultant'];
$sleep = $_POST['sleep'];
$communication = $_POST['communication'];
$nutrition = $_POST['nutrition'];
$family = $_POST['family'];
$elimination = $_POST['elimination'];
$problems = $_POST['problems'];
$temperature = $_POST['temperature'];
$palpation = $_POST['palpation'];
$pulse = $_POST['pulse'];
$percussion = $_POST['percussion'];
$respiration = $_POST['respiration'];
$auscultation = $_POST['auscultation'];
$blood_pressure = $_POST['blood_pressure'];
$general_summary = $_POST['general_summary'];
$apex_beat = $_POST['apex_beat'];
$ward = $_POST['ward'];
$death = $_POST['death'];

$ad_month = $_POST['month'];
$ad_day = $_POST['day'];
$ad_year = $_POST['year'];

$admission_date = "$ad_day-$ad_month-$ad_year";
echo $admission_date;
exit();
$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no`,`ward` FROM `admission` WHERE `hospital_no`='$hospital_no' AND `ward`='$ward'");
$num_rows = @mysql_num_rows($sql);

if($num_rows<1)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry! Patient Admission Record not found");
window.location = "ward_nurse_page.php";
</script>
<?php
exit();
}
mysql_query("INSERT INTO  patient_report(hospital_no,activity,consultant,sleep,admission_date,communication,nutrition,family,elimination,
problems,temperature,palpation,pulse,percussion,respiration,auscultation,blood_pressure,general_summary,apex_beat,ward,date_added,death)VALUES('$hospital_no','$activity','$consultant','$sleep','$admission_date','$communication','$nutrition','$family','$elimination','$problems','$temperature','$palpation','$pulse','$percussion','$respiration','$auscultation','$blood_pressure','$general_summary','$apex_beat','$ward','$date_added','$death')") or die("ERROR::");
?>
<script type="text/javascript">
alert("New Patient Report successfully added");
window.location = "ward_nurse_page.php";
</script>