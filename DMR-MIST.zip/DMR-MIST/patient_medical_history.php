<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 

<?php

$hospital_no = addslashes($_POST['hospital_no']);

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no`,`fname`,`lname`,`date_of_birth`,`sex`,`occupation`,`next_of_kin`,`phone`,`email`,`address` FROM patients WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows<1)
{
?>
<script type="text/javascript">
alert("Sorry! Patient records not found on this date");
window.location = "medical_consultant_page.php");
</script>
<?php  
exit();
}
else
$_SESSION['hospital_no'] = $hospital_no;
{
include('dbconnect.php');
while($rows = @mysql_fetch_array($sql) )
 {
   $hospital_no = $rows['hospital'];
   $fname = $rows['fname'];
   $lname = $rows['lname'];
   $date_of_birth = $rows['date_of_birth'];
   $sex = $rows['sex'];
   $occupation = $rows['occupation'];
   $next_of_kin = $rows['next_of_kin'];
   $phone = $rows['phone'];
   $email = $rows['email'];
   $address = $rows['address'];
  } 
   
   $sql3 = mysql_query("SELECT * FROM `examination` WHERE `hospital_no` = '$hospital_no'");
   while($rows3 = @mysql_fetch_array($sql3))
   {
    $subjective = $rows3['subjective'];
	$objective = $rows3['objective'];
	$assessment1 = $rows3['assessment1'];
	$ICD_code_1 = $rows3['ICD_code_1'];
	$assessment2 = $rows3['assessment2'];
	$ICD_code_2 = $rows3['ICD_code_2'];
	}
}
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search Results:: Patient Medical History</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #000033;
	font-weight: bold;
}
.style1 {font-size: 12px}
-->
</style></head>

<body>
<p>Patient General Information </p>
<table width="820" height="82" align="center">
  <tr>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p><span class="style1">Hospital No: <?php echo $_SESSION['hospital_no'];?></span></p>
      <p><span class="style1">First Name: <?php echo $fname;?></span></p>
      <p><span class="style1">Last Name: <?php echo $lname;?></span></p>
	  <p><span class="style1">Date of Birth: <?php echo $date_of_birth;?></span></p>
	  <p><span class="style1">Sex: <?php echo $sex;?></span></p>    </td>
    <td width="394" valign="top" bgcolor="#FFFFC1"><p><span class="style1">Occupation: <?php echo $occupation;?></span></p>
      <p><span class="style1">Next Of Kin: <?php echo $next_of_kin;?></span></p>
      <p><span class="style1">Phone: <?php echo $phone;?></span></p>
      <p><span class="style1">Email: <?php echo $email;?></span></p>
    <p><span class="style1">Address: <?php echo $address;?></span></p></td>
  </tr>
</table>
<hr>
<p>Patient Schedule Information</p>
<table width="820" height="82" align="center">
  <tr>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p>
      <?php include('dbconnect.php');
   $sql2 = mysql_query("SELECT * FROM `schedule` WHERE `hospital_no` = '$_SESSION[hospital_no]'");
   $num_rows2 = @mysql_num_rows($sql2);
   if($num_rows2==0)
   {
    echo "NO PATIENT SCHEDULE FOUND";
    }
	else
	{	
   while($rows2 = @mysql_fetch_array($sql2))
   {
    $reference = $rows2['reference'];
	$service = $rows2['service'];
	$schedule = $rows2['schedule'];
	$medical_personnel = $rows2['medical_personnel'];
	$purpose = $rows2['purpose'];
	$status = $rows2['status'];
	}
	echo "<p><span class=style1>Patient Category: $reference</span></p>
      <p><span class=style1>Service/Station: $service</span></p>
	  <p><span class=style1>Schedule: $schedule</span></p></td>
	  <td width=394 valign=top bgcolor=#FFFFC1><p><span class=style1>Personnel to Visit: $medical_personnel</span></p>
      <p><span class=style1>Purpose of Visit: $purpose</span></p>
      <p><span class=style1>Status: $status</span></p>
      </td>
	  
	  ";
	
	
	} ?> 
      </p>
  </tr>
</table>
<hr>
<p>Patient Vital Signs Record </p>
<table width="820" height="82" align="center">
  <tr>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p>
      <?php include('dbconnect.php');
   $sql3 = mysql_query("SELECT * FROM `vital_signs` WHERE `hospital_no` = '$_SESSION[hospital_no]'");
   $num_rows3 = @mysql_num_rows($sql3);
   if($num_rows3==0)
   {
    echo "NO PATIENT VITAL SIGNS RECORD FOUND";
    }
	else
	{	
   while($rows3 = @mysql_fetch_array($sql3))
   {
    $systole = $rows3['systole'];
	$diastole = $rows3['diastole'];
	$pulse = $rows3['pulse'];
	$temperature = $rows3['temperature'];
	$weight = $rows3['weight'];
	$height = $rows3['height'];
	$oxygen = $rows3['oxygen'];
	$respiration = $rows3['respiration'];
	}
	echo "<p><span class=style1>Systole: $systole mmHg</span></p>
      <p><span class=style1>Diastole: $diastole mmHg</span></p>
	  <p><span class=style1>Pulse: $pulse x/min</span></p>
	  <p><span class=style1>Temperature: $temperature C</span></p></td>
	  <td width=394 valign=top bgcolor=#FFFFC1><p><span class=style1>Weight: $weight Kg</span></p>
      <p><span class=style1>Height: $height M</span></p>
      <p><span class=style1>Oxygen: $oxygen %</span></p>
	  <p><span class=style1>Respiration: $respiration X/Min</span></p>
      </td>
	  
	  ";
	
	
	} ?>
    </p></td>
  </tr>
</table>
<hr />
<p>Patient Examination Record </p>
<table width="820" height="82" align="center">
  <tr>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p>
      <?php include('dbconnect.php');
   $exam = mysql_query("SELECT * FROM `examination` WHERE `hospital_no` = '$_SESSION[hospital_no]'");
   $num_rows4 = @mysql_num_rows($exam);
   if($num_rows4==0)
   {
    echo "NO PATIENT EXAMINATION RECORD FOUND";
    }
	else
	{	
   while($rows4 = @mysql_fetch_array($exam))
   {
    $subjective = $rows4['subjective'];
	$objective = $rows4['objective'];
	$assessment1 = $rows4['assessment1'];
	$ICD_code_1 = $rows4['ICD_code_1'];
	$assessment2 = $rows4['assessment2'];
	$ICD_code_2 = $rows4['ICD_code_2'];
	$admission = $rows4['admission'];
	}
	echo "<p><span class=style1>History: $subjective</span></p>
      <p><span class=style1>Objective: $objective</span></p>
	  <p><span class=style1>Assessment 1: $assessment1</span></p></td>
	  <p><span class=style1>Admitted: $admission</span></p>
	  <td width=394 valign=top bgcolor=#FFFFC1><p><span class=style1>ICD Code 1: $ICD_code_1</span></p>
      <p><span class=style1>Assessment 2: $assessment2</span></p>
      <p><span class=style1>ICD Code 2: $ICD_code_2</span></p>
	  
	  
      </td>
	  
	  ";
	
	
	} ?>
    </p></td>
  </tr>
</table>
<hr />
<p>Patient Written Examination </p>
<table width="820" height="82" align="center">
  <tr>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p>
      <?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky = mysql_query("SELECT `examination` FROM `written_examination` WHERE `hospital_no` = '$_SESSION[hospital_no]'");
   $viky2 = mysql_query("SELECT `date_added` FROM `written_examination` WHERE `hospital_no` = '$_SESSION[hospital_no]'");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN EXAMINATION RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Examination</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2><a href=examination/$col_value>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
	echo "</table></html>"; 
	
	
	
	}?>
	
	
	</p></td>
    <td width="414" valign="top" bgcolor="#FFFFC1"><p><?php 
	  $count = 0;
	  include('dbconnect.php');
   $viky2 = mysql_query("SELECT `date_added` FROM `written_examination` WHERE `hospital_no` = '$_SESSION[hospital_no]'");
   $rowz = @mysql_num_rows($viky);
   if($rowz==0)
   {
    echo "NO PATIENT WRITTEN EXAMINATION RECORD FOUND";
    }
	else
	{
	echo "<html>";
	echo "<table width=414 border=1>";
	echo "<tr>";
	echo "<td><strong>Date Added</strong></td>
	 
        </tr>";
	while($rows = @mysql_fetch_array($viky2, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	    
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	 	}
		
	
		echo "</table></html>"; 
	
	
	
	}?></td>
  </tr>
</table>
<p>&nbsp; </p>
<p>&nbsp; </p>
