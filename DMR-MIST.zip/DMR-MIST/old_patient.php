<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$purpose = $_POST['purpose'];
$medical_personnel = $_POST['medical_personnel'];
$amount_paid = $_POST['amount_paid'];
$visit_status = $_POST['visit_status'];
$reg_point = $_POST['reg_point'];
$payment_purpose = $_POST['payment_purpose'];
$tech_fee = $_POST['tech_fee'];
$reg_fee = $_POST['reg_fee'];
$payment_purpose = "$reg_fee, $tech_fee";

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist! Please try again");
window.location = "registration_staff_page.php";
</script>
<?php
exit();
}
mysql_query("INSERT INTO old_patient(hospital_no,purpose,medical_personnel,amount_paid,visit_status,reg_point,payment_purpose,date_added)VALUES('$hospital_no','$purpose','$medical_personnel','$amount_paid','$visit_status','$reg_point','$payment_purpose','$date_added')");
?>
<script type="text/javascript">
alert("Patient Record Updated");
window.location = "registration_staff_page.php";
</script>