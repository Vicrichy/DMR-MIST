<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search Results:: Lab Patient Search</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000033;
}
-->
</style></head>

<body>

<p>
  <?php

$hospital_no = addslashes($_POST['hospital_no']);

include('dbconnect.php');
$ag = mysql_query("SELECT `hospital_no` FROM `procedures` WHERE `hospital_no` = '$hospital_no'");
$ag_status = @mysql_num_rows($ag);
if($ag_status ==0)
{
?>
  <script type="text/javascript">
alert("ERROR: Patient record not found!");
window.location = "laboratory_page.php";
</script>
  <?php
exit();
}
include('dbconnect.php');
$check = mysql_query("SELECT `financial_status` FROM `procedures` WHERE `hospital_no` = '$hospital_no' AND `financial_status` = 'CLEARED'");
$status = @mysql_num_rows($check);
if($status ==0)
{
?>
  <script type="text/javascript">
alert("ERROR: Patient not cleared by accounts section!");
window.location = "laboratory_page.php";
</script>
  <?php
exit();
}
else
{
$sql = mysql_query("SELECT `date`,`section/service`,`number`,`repeat`,`purpose`,`requested_by`,`doctor/staff`,`status`,`financial_status`,`schedule` FROM procedures WHERE `hospital_no`='$hospital_no'");
$query1 = mysql_query("SELECT `procedure` FROM `procedure` WHERE `hospital_no` = '$hospital_no'");
echo "<html>";
	echo "<table width=950 height=187 align=center>";
	echo "<tr>";
	echo " <td valign=top bgcolor=#FFFFC1><table width=942 border=1>";
	echo "<tr>";
	echo "<td width=76><strong>Date </strong></td>
        <td width=76><strong>Section/Service </strong></td>
        <td width=76><strong>No.of Procedures </strong></td>
        <td width=76><strong>Repeat </strong></td>
        <td width=75><strong>Purpose</strong></td>
        <td width=77><strong>Requested by</strong></td>
        <td width=76><strong>Doctor/Staff </strong></td>
        <td width=75><strong>Status  </strong></td>
        <td width=75><strong>Financial Status</strong></td>
		<td width=75><strong>Schedule</strong></td>
		<td width=75><strong>Procedures</strong></td>
        </tr>";
	while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	}
	echo "<td>";
	while ($rows = @mysql_fetch_array($query1, MYSQL_ASSOC))
{

while( list ($key, $value) = each($rows) )
{
echo "*".$value.'<br>';
}
}
echo "</td>";
	echo "</tr>";
	echo "</table></html>"; 
}
?>	
</p>
<p>&nbsp;</p>
