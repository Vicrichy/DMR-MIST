<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Written Procedure Request</title>
<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 12px;
	color: #000033;
}
-->
</style>
</head>

<body>
<blockquote>
  <p><img src="Images/scroll2.gif" alt="scroll" width="670" height="760" />  </p>
  <table width="663">
    <tr>
      <td><form action="insert_written_procedure.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
        <p><span class="style1">UPLOAD WRITTEN EXAMINATION </span></p>
        <table width="359" align="center">
          <tr>
            <td width="100"><span class="style1">Hospital No </span></td>
            <td width="181"><label>
              <input name="hospital_no" type="text" id="hospital_no" />
            </label></td>
          </tr>
          <tr>
            <td width="100"><span class="style1">Upload</span></td>
            <td><label>
              <input name="userfile" type="file" id="userfile" />
            </label></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><input name="Submit" type="submit" id="Submit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Submit" onclick="logout();" /></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
            </form>
      </td>
    </tr>
  </table>
  <p>&nbsp;</p>
</blockquote>
</body>
</html>
