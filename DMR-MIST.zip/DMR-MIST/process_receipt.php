<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 

<?php
$date = date("d")."-".date("M")."-".date("Y");
$hospital_no = addslashes($_POST['hospital_no']);
$code = rand();
include('dbconnect.php');
$ag = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");
$ag_status = @mysql_num_rows($ag);
if($ag_status ==0)
{
?>
<script type="text/javascript">
alert("ERROR: Patient record not found!");
window.location = "accounts_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');
$check = mysql_query("SELECT `hospital_no` FROM `accounts` WHERE `hospital_no` = '$hospital_no'");
$status = @mysql_num_rows($check);
if($status ==0)
{
?>
<script type="text/javascript">
alert("ERROR: Patient does not have any financial records!");
window.location = "accounts_page.php";
</script>
<?php
exit();
}
else
{
include('dbconnect.php');
$sql = mysql_query("SELECT `hospital_no`,`item`,`amount`,`status`,`date_added` FROM accounts WHERE `hospital_no`='$hospital_no'");
$sql1 = mysql_query("SELECT `item` FROM accounts WHERE `hospital_no`='$hospital_no'");
$item = '';
while($rows = @mysql_fetch_array($sql1, MYSQL_ASSOC))
	{
	  foreach($rows as $col_value)
	 {
	   $value = $col_value;
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 
	 $count++;
	 $item = $item ."$value<br>";
 	} 
$vik = @mysql_num_rows($sql);
if($vik==0)
{
 echo "NO FINANCIAL RECORDS FOUND";
}
else
{
$becky = mysql_query("SELECT `amount` FROM `accounts` WHERE `hospital_no` = '$hospital_no' AND `status` = 'PAID'");
while($rows = @mysql_fetch_array($becky, MYSQL_ASSOC))
	{
	  foreach($rows as $col_value)
	 {
	   $value = $col_value;
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 
	 $count++;
	 $total += $value;
 	} 
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Receipt::</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000033;
}
.style1 {
	font-size: 18px;
	font-weight: bold;
}
-->
</style></head>

<body onLoad="window.print();">
<table width="923" height="90">
  <tr>
    <td width="138" valign="top"><img src="Images/stethoscope2.jpg" alt="logo" width="138" height="97" /></td>
    <td width="773" valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <div align="center" class="style1">
      <p>UNIVERSITY OF UYO TEACHING HOSPITAL</p>
      <p>ABAK, AKWA IBOM STATE. </p>
    </div></td>
  </tr>
</table>
<hr />
<br>
<table width="920" height="56">
  <tr>
    <td width="277"><strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OFFICIAL RECEIPT</strong> </td>
    <td width="456"><div align="center"><strong>RECEIPT NO:</strong> <?php echo $code;?> </div></td>
    <td width="171"><strong><?php echo $date;?></strong></td>
  </tr>
</table>
<p><br>
  <br>
  <?php
echo "<html>";
	echo "<table width=950 height=187 align=center>";
	echo "<tr>";
	echo " <td valign=top bgcolor=#FFFFFF><table width=942>";
	echo "<tr>";
	echo "<td width=76><strong>Hospital No </strong></td>
        <td width=76><strong>Item </strong></td>
        <td width=76><strong>Amount(In Naira) </strong></td>
        <td width=76><strong>Status </strong></td>
        <td width=75><strong>Date Paid</strong></td>
        </tr>";
	while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</td>";
	}
	
	echo "</tr>";
	echo "</table></html>"; 
}
}
include('dbconnect.php');
mysql_query("INSERT INTO receipt(code,hospital_no,total,date,items)VALUES('$code','$hospital_no','$total','$date','$item')")or die ("FATAL ERROR");
?>
</p>
<p>&nbsp;</p>
<hr />
<p><strong>TOTAL AMOUNT = </strong><?php echo $total;?></p>
<p>&nbsp;</p>
<p>-----------------------------------------	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-------------------------------------------</p>
<p>For Accounts &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Patient's Signature &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
