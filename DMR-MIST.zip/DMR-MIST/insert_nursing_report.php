<?php

session_start();

$report = $_POST['report'];
$system_month = date("M");
$system_day = date("d");
$system_year = date("Y");
$sent_to = $_POST['sent_to'];
$date_added = "$system_day-$system_month-$system_year";

$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];

$report_date = "$day-$month-$year";

include('dbconnect.php');

mysql_query("INSERT INTO  staff_reports(staff,date,report,report_date,sent_to)VALUES('Dir. Of Nursing','$date_added','$report','$report_date','$sent_to')") or die("Error");

?>
<script type="text/javascript">
alert("Your report has successfully been Added");
window.location = "dir_of_nursing_page.php";
</script>