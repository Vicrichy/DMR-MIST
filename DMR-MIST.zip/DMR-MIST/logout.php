<?php
session_start();

include('dbconnect.php');
mysql_query("UPDATE staff SET status = 'NOT AVAILABLE' WHERE `user_id` = '$_SESSION[user_id]'");

session_unset();

session_destroy();


header("location:index.php");
?>