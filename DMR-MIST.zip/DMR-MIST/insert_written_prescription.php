<?php

$hospital_no = addslashes($_POST['hospital_no']);
$pix = $_POST['pix'];
$code = rand();

$month = date("M");
$day = date("d");
$year = date("Y");

$date = "$day-$month-$year";

//picture uploading
$file_name = $_FILES['userfile']['name'];
$file_ext = strtolower(substr($file_name,strrpos($file_name,".")));

if ((($_FILES["userfile"]["type"] == "image/gif")
|| ($_FILES["userfile"]["type"] == "image/jpeg")
|| ($_FILES["userfile"]["type"] == "image/jpg")
|| ($_FILES["userfile"]["type"] == "image/pjpeg"))
&& ($_FILES["userfile"]["size"] < 4000000))
  {
  if ($_FILES["userfile"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["userfile"]["error"] ."<br />";
    }
		if (file_exists("prescription/" .$code.$file_ext))
      {
      echo $_FILES["userfile"]["name"] . " already exists.   <a href=javascript:history.back()> << Return </a>";
      }
    else
      {
	  
       move_uploaded_file($_FILES["userfile"]["tmp_name"],
      "prescription/" .$code.$file_ext);
      //echo "Stored in: " . "pix/" . $_FILES["userfile"]["name"];
      }
    }
else
  {
  echo "Invalid file";
  }

include('dbconnect.php');

$query = mysql_query("INSERT INTO written_prescription(hospital_no,prescription,date_added)VALUES('$hospital_no','$code$file_ext','$date')")or die("Error");

?>
<script type="text/javascript">
alert("Written Prescription Successfully added");
window.close();
</script>