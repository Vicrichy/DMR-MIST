<?php
session_start();

$hospital_no = $_POST['hospital_no'];

include('dbconnect.php');
$sql = mysql_query("SELECT `hospital_no` FROM `admission` WHERE `hospital_no` = '$hospital_no'")or die("Fatal Error");
$num_rows = @mysql_num_rows($sql);

if($num_rows ==0)
{
?>
<script type="text/javascript">
alert("ERROR: Patient's admission records not found");
window.location = "medical_consultant_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');

mysql_query("INSERT INTO `discharge` SET `hospital_no` = '$hospital_no', `discharged_by` = '$_SESSION[name]'")or die("Fatal Error");
?>
<script type="text/javascript">
alert("Patient Successfully discharged! Patient yet to be cleared by ward nurse");
window.location = "medical_consultant_page.php";
</script>