<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
$year = date("Y");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function logout()
{window.location = "logout.php"};
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Home| DMR - MIST</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style3 {font-size: 12px}
#Layer1 {
	position:absolute;
	width:397px;
	height:52px;
	z-index:1;
	left: 526px;
	top: 189px;
}
.style11 {color: #FFFFFF}
-->
</style>
</head>
<body>


<div id="bg2">




<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div id="buttons">
      <a href="#" class="but"  title="">Home</a>
      <a href="#" class="but" title="">Blog</a>
      <a href="#"  class="but" title="">Gallery</a>
      <a href="#"  class="but" title="">About us</a>
      <a href="#" class="but" title="">Contact us</a>    </div>
	<div id="logo">
	  <div id="Layer1">
	    <div id="layer"></div>
	    <a href="#" class="style1">ACCOUNTS PAGE </a></div>
	  <a href="#" class="style1">DMR - MIST </a>
      <h2><a href="#" id="metamorph">e-NERGY Software Solutions</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">Your Info </h1>	
                        <div class="right_b">
                          <div class="munth">
                            <p>Name: Dr Bassey </p>
                            <p>Phone: 08039098042</p>
                            <p>Email: cmd@ucth.com </p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                          </div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">Support</h1>	
                    	<div class="right_w fish_10">
                    	  <div class="munth">
                    	    <p>For technical support, please call any of the following phone numbers. </p>
                    	    <p>&nbsp;</p>
                    	    <p>Victor: 08039098042</p>
                    	    <p>&nbsp;</p>
                    	    <p>You may send us an Email: support@emrsoft.com </p>
                    	    <p>&nbsp;  </p>
                    	    <p>&nbsp;</p>
                    	    <p>&nbsp;</p>
                    	  </div>
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1> Hospital News</h1>
                       <div class="box1">
                        <div class="left_b"><span class="w">Friday, Apr.10, 2010</span><br />
                          The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Saturday, Apr. 11, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Sunday, Apr. 12, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Monday, Apr. 13, 2010</span><br />
                                   The hospital management today welcomed the minister of health of the federation on a two-day visit....
                                     <div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                      </div>
                    <div id="center">
                      <h1>Welcome to EMR-SOFT </h1>
                        <div class="text">
                        	<span>About EMR-SOFT </span>
                      	</div>
                         <div class="text">
                           <p><img src="images/stethoscope2.jpg" class="img" width="120" height="90" alt="" />The online “Digital  Medical Record-Management Information System Technology” (EMR-SOFT) solution is  a solid, integrated, user friendly software application<strong>. </strong>It has been  specially designed and developed for providing digital quality  service delivery to support the operations of clinical processes,  management and decision making functions in the hospital. </p>
                           <p>The technology allows you to create and  maintain medical record database through a system that utilizes ICT Equipments  and Software to address and overcome  the over boring manual procedures for accessing daily medical records of patients. With EMR-SOFT solution, you can guarantee  automatic processing of medical records, update and print on time as well as  standardize the system of obtaining reports and statistical information from  the hospital. </p>
                           <p>Moreover, health personnel who may be  far from their work place can in a case of emergency access patients’ record  online via the Internet (as allowable by the operating Institution) and  immediately render medical services or advice as the case may be. </p>
                        </div>
                        
                        <div class="text">
                          <h1>User Login  </h1>
                          <p>&nbsp;</p>
                          <form id="form1" method="post" action="staff_login.php">
                            <table bgcolor="#FFFFC1">
                              <tr>
                                <td bgcolor="#FFFFC1" class="style3">Name</td>
                                <td colspan="3"><input name="name" type="text" id="name" style="background:#003366" /></td>
                              </tr>
                              <tr>
                                <td bgcolor="#FFFFC1" class="style3">Password</td>
                                <td colspan="3"><input name="password" type="password" id="password" style="background:#003366" /></td>
                              </tr>
                              <tr>
                                <td bgcolor="#FFFFC1" class="style3">User Id </td>
                                <td colspan="3"><select name="user_id" id="user_id" onchange="selAction(this);" style="background:#003366">
                                    <option bindto="" value="Please Select an employee type:">Please Select a Login type:</option>
                                    <option bindto="">Medical Consultant</option>
                                    <option>Records</option>
                                    <option bindto="">Pharmacist</option>
                                    <option bindto="">Laboratory Staff</option>
                                    <option bindto="">Accounts</option>
                                    <option bindto="trVol" value="Nursing Officer">Nursing Officer</option>
                                    <option bindto="trMan" value="Management">Management</option>
                                </select></td>
                              </tr>
                              <tbody id="trVol" style="display:none;">
                                <tr>
                                  <td bgcolor="#FFFFC1" class="style3">Select Nursing Officer Type</td>
                                  <td><select name="user_id1" id="user_id1" style="background:#003366">
                                      <option selected="selected"></option>
                                      <option>Clinic Nurse</option>
                                      <option>Ward Nurse</option>
                                  </select></td>
                                </tr>
                              </tbody>
                              <tbody id="trMan" style="display:none;">
                                <tr>
                                  <td bgcolor="#FFFFC1" class="style3">Select Managment Position</td>
                                  <td><select name="user_id2" id="user_id2" style="background:#003366">
                                      <option selected="selected"></option>
                                      <option>CMD</option>
                                      <option>CMAC</option>
                                      <option>Chief Accountant</option>
                                      <option>Dir. of Pharmacy</option>
                                      <option>Dir. of Nursing</option>
                                  </select></td>
                                </tr>
                              </tbody>
                              <tr>
                                <td></tbody></td>
                              </tr>
                              <tr>
                                <td><input name="Login" type="submit" id="Login" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Login" /></td>
                              </tr>
                            </table>
                            <p>&nbsp;</p>
                          </form>
                          <p>&nbsp;</p>
                      </div>
                        <p>&nbsp;</p>
                    </div>
                    
                      <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
     <!-- footer begins -->
            <div id="footer">
          
		    <p><span class="style11">&copy;2010. EMR-SOFT V 1.0. Powered by Circuitworks</span></p> 
	</div>
        <!-- footer ends -->
</div>

</div>




</body>
</html>
