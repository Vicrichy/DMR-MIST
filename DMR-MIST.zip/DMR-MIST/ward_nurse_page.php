<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
$year = date("Y");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script LANGUAGE="JavaScript">

function popUp(URL,popW,popH) {

var w = 480, h = 340;

if (document.all || document.layers) {
   w = screen.availWidth;
   h = screen.availHeight;
}

var topPos = 0, leftPos = (w-popW)/2;


   window.open(URL,'popup','resizable, toolbar=no, location=no, status=no, scrollbars=yes, horizontal scrollbars=yes, scroll=yes, menubar=no, titlebar=no, width=' + popW + ',height=' + popH + ',left=' + leftPos + ',top=' + topPos + ',screenX=' + leftPos + ',screenY=' + topPos);

}
// -->
</script>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function logout()
{window.location = "logout.php"};
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Nurse Page| DMR - MIST</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style3 {font-size: 12px}
#Layer1 {
	position:absolute;
	width:397px;
	height:52px;
	z-index:1;
	left: 526px;
	top: 189px;
}
.style11 {color: #FFFFFF}
.style10 {color: #000033}
.style12 {color: #014377}
.style13 {font-size: 10px}
.style14 {font-size: 12px; color: #FF0000; }
-->
</style>
</head>
<body>


<div id="bg2">




<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div id="buttons"><strong><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans0');">Ward Report  </a><a href="#" class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans1');">Patients</a>
      <a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans2');">Admission</a><a href="#"  class="but" title="" style="cursor:pointer" onClick="toggleInfo('ans3');">Discharge</a></strong><strong><a href="#"  class="but" title="" style="cursor:pointer" onclick="logout();">Logout </a></strong></div>
	 <div id="logo">
	  <div id="Layer1">
	    <div id="layer"></div>
	    <a href="#" class="style1"><?php echo $_SESSION['user_id'];?> Page </a></div>
	  <a href="#" class="style1">DMR - MIST </a>
      <h2><a href="#" id="metamorph">e-NERGY Software Solutions</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">Your Info </h1>	
                        <div class="right_b">
                          <div class="munth">
                            <p>Name: <span class="style10"><?php echo $_SESSION['name'];?></span> </p>
                            <p>Sex: <span class="style3"><?php echo $_SESSION['sex'];?></span></p>
                            <p>Dept: <span class="style3"><?php echo $_SESSION['department'];?></span></p>
                            <p>Phone: <span class="style3"><?php echo $_SESSION['phone'];?></span></p>
                            <p>Email: <span class="style3"><?php echo $_SESSION['email'];?></span></p>
                            <p>Last Login: <span class="style3"><?php echo $_SESSION['last_login'];?></span></p>
                            <p>&nbsp;</p>
                            <p><span class="style3">
                              <input name="Edit" type="button" id="Edit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Edit" />
                            </span> </p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                          </div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">Support</h1>	
                    	<div class="right_w fish_10">
                    	  <div class="munth">
                    	    <p>For technical support, please call any of the following phone numbers. </p>
                    	    <p>&nbsp;</p>
                    	    <p>Victor: 08039098042</p>
                    	    <p>&nbsp;</p>
                    	    <p>You may send us an Email: support@emrsoft.com </p>
                    	    <p>&nbsp;  </p>
                    	    <p>&nbsp;</p>
                    	    <p>&nbsp;</p>
                    	  </div>
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1> Hospital News</h1>
                       <div class="box1">
                        <div class="left_b"><span class="w">Friday, Apr.10, 2010</span><br />
                          The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Saturday, Apr. 11, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Sunday, Apr. 12, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Monday, Apr. 13, 2010</span><br />
                                   The hospital management today welcomed the minister of health of the federation on a two-day visit....
                                     <div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                      </div>
                    <div id="center">
                      <h1>Login as: <span class="style10"><?php echo $_SESSION['user_id'];?></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h1>
                      <div class="text" id="ans0">
                          <p class="style12">Daily Ward Report </p>
                          <p class="style12">&nbsp;</p>
                          <table width="454" bgcolor="#FFFFC1">
                            <tr>
                              <td width="44"><a class="style13">Ward</a></td>
                              <td width="144"><select name="ward" id="ward" style="background:#003366; color:#FFFFFF">
                                  <option>A&amp;E</option>
                                  <option>Male Surgical</option>
                                  <option>Female Surgical</option>
                                  <option>Maternity</option>
                                  <option>Post Natal</option>
                              </select></td>
                              <td width="10">&nbsp;</td>
                              <td width="88"><a class="style13">No. of Discharges </a></td>
                              <td width="144"><input name="discharges" type="text" id="discharges" style="background:#003366; color:#FFFFFF"/></td>
                            </tr>
                            <tr>
                              <td><a class="style13">No. of Deaths </a></td>
                              <td><label>
                                <input name="deaths" type="text" id="deaths" style="background:#003366; color:#FFFFFF"/>
                              </label></td>
                              <td>&nbsp;</td>
                              <td><a class="style13">No. of Admissions </a></td>
                              <td><input name="admissions" type="text" id="admissions" style="background:#003366; color:#FFFFFF"/></td>
                            </tr>
                            <tr>
                              <td><a class="style13">No. of Nurses on duty </a></td>
                              <td><input name="nurses" type="text" id="nurses" style="background:#003366; color:#FFFFFF"/></td>
                              <td>&nbsp;</td>
                              <td><a class="style13">No. of Births (if any) </a></td>
                              <td><input name="births" type="text" id="births" style="background:#003366; color:#FFFFFF"/></td>
                            </tr>
                            <tr>
                              <td colspan="2"><a class="style13">General Summary (include referrals) </a></td>
                              <td>&nbsp;</td>
                              <td><a class="style13">Recommendations</a></td>
                              <td rowspan="2"><input name="recommendations" type="text" id="recommendations" value="" style="background:#003366; color:#FFFFFF"/></td>
                            </tr>
                            <tr>
                              <td align="center"><span class="style13"></span></td>
                              <td align="center"><input name="general_summary" type="text" id="general_summary" value="" style="background:#003366; color:#FFFFFF"/></td>
                              <td>&nbsp;</td>
                              <td align="left"><span class="style13"></span></td>
                            </tr>
                            <tr>
                              <td><a class="style13">No. of Critical Cases </a></td>
                              <td><input name="critical_cases" type="text" id="critical_cases" style="background:#003366; color:#FFFFFF"/></td>
                              <td>&nbsp;</td>
                              <td><a class="style13">Problems Encountered </a></td>
                              <td rowspan="2"><input name="problems" type="text" id="problems" value="" style="background:#003366; color:#FFFFFF"/></td>
                            </tr>
                            <tr>
                              <td><a class="style13">No. of Referrals </a></td>
                              <td><input name="referrals" type="text" id="referrals" style="background:#003366; color:#FFFFFF"/></td>
                              <td>&nbsp;</td>
                              <td align="center"><span class="style13"></span></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p>
                      </div>
                      <div class="text" id="ans1">
                          <p class="style12">Patient Daily Report </p>
                          <p>&nbsp;</p>
                          <table width="455" height="212" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><form id="form1" method="post" action="insert_patient_daily_report.php">
                                  <table width="447">
                                    <tr>
                                      <td width="66"><a class="style13">Hospital No. </a></td>
                                      <td width="147"><input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/></td>
                                      <td width="10">&nbsp;</td>
                                      <td width="75"><p class="style13">Activity/</p>
                                          <p class="style13">exercise</p></td>
                                      <td width="151"><input name="activity" type="text" id="activity" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Consultant</a></td>
                                      <td><label>
                                        <input name="consultant" type="text" id="consultant" style="background:#003366; color:#FFFFFF"/>
                                      </label></td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Sleep/rest</a></td>
                                      <td><input name="sleep" type="text" id="sleep" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Date of Admission </a></td>
                                      <td><label>
                                        <select name="day" id="day"style="background:#003366; color:#FFFFFF" >
                                          <option>1</option>
                                          <option>2</option>
                                          <option>3</option>
                                          <option>4</option>
                                          <option>5</option>
                                          <option>6</option>
                                          <option>7</option>
                                          <option>8</option>
                                          <option>9</option>
                                          <option>10</option>
                                          <option>11</option>
                                          <option>12</option>
                                          <option>13</option>
                                          <option>14</option>
                                          <option>15</option>
                                          <option>16</option>
                                          <option>17</option>
                                          <option>18</option>
                                          <option>19</option>
                                          <option>20</option>
                                          <option>21</option>
                                          <option>22</option>
                                          <option>23</option>
                                          <option>24</option>
                                          <option>25</option>
                                          <option>26</option>
                                          <option>27</option>
                                          <option>28</option>
                                          <option>29</option>
                                          <option>30</option>
                                          <option>31</option>
                                        </select>
                                        <select name="month" id="select2" style="background:#003366; color:#FFFFFF">
                                          <option>Jan</option>
                                          <option>Feb</option>
                                          <option>Mar</option>
                                          <option>Apr</option>
                                          <option>May</option>
                                          <option>Jun</option>
                                          <option>Jul</option>
                                          <option>Aug</option>
                                          <option>Sep</option>
                                          <option>Oct</option>
                                          <option>Nov</option>
                                          <option>Dec</option>
                                        </select>
                                        <input name="year" type="text" id="year" size="5" width="40" style="background:#003366; color:#FFFFFF"/>
                                      </label></td>
                                      <td>&nbsp;</td>
                                      <td><p class="style13">Communication</p>
                                          <p class="style13">/special senses </p></td>
                                      <td><input name="communication" type="text" id="communication" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Nutrition</a></td>
                                      <td><input name="nutrition" type="text" id="nutrition" value="" style="background:#003366; color:#FFFFFF"/></td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Family/social relationship </a></td>
                                      <td><input name="family" type="text" id="family" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Elimination</a></td>
                                      <td><input name="elimination" type="text" id="elimination" value="" style="background:#003366; color:#FFFFFF"/></td>
                                      <td>&nbsp;</td>
                                      <td><p class="style13">Problems</p>
                                          <p class="style13"> Encountered </p></td>
                                      <td><input name="problems2" type="text" id="problems2" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Temperature</a></td>
                                      <td><input name="temperature" type="text" id="temperature" size="5" width="40" style="background:#003366; color:#FFFFFF"/>
                                          <span class="style3">C</span> </td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Palpation</a></td>
                                      <td><input name="palpation" type="text" id="palpation" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Pulse</a></td>
                                      <td><input name="pulse" type="text" id="pulse" size="5" width="40" style="background:#003366; color:#FFFFFF"/>
                                          <span class="style3">X/min</span> </td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Percussion</a></td>
                                      <td><input name="percussion" type="text" id="percussion" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Respiration</a></td>
                                      <td><input name="respiration" type="text" id="respiration" size="5" width="40" style="background:#003366; color:#FFFFFF"/>
                                          <span class="style3">X/min</span> </td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Auscultation</a></td>
                                      <td><input name="auscultation" type="text" id="auscultation" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Blood Pressure </a></td>
                                      <td><input name="blood_pressure" type="text" id="blood_pressure" size="5" width="40" style="background:#003366; color:#FFFFFF"/>
                                          <span class="style3">mmHg</span> </td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">General Summary </a></td>
                                      <td><input name="general_summary" type="text" id="general_summary" value="" style="background:#003366; color:#FFFFFF"/></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Apex Beat </a></td>
                                      <td><input name="apex_beat" type="text" id="apex_beat" size="5" width="40" style="background:#003366; color:#FFFFFF"/>                                      </td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Ward or Clinic </a></td>
                                      <td><select name="select" id="select" style="background:#003366; color:#FFFFFF">
                                          <option>A&amp;E</option>
                                          <option>Male Surgical</option>
                                          <option>Female Surgical</option>
                                          <option>Maternity</option>
                                          <option>Post Natal</option>
                                      </select></td>
                                    </tr>
                                  </table>
                                <p>&nbsp;</p>
                                <p>Death
                                  <label>
                                      <input name="death" type="checkbox" id="death" value="YES" />
                                                                        </label>
                                                                  </p>
                                <p>&nbsp;</p>
                                <p>
                                    <input name="Add2" type="submit" id="Add2" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add" />
                                  </p>
                              </form></td>
                            </tr>
                          </table>
                          </div>
                      <div class="text" id="ans2">
                        <p class="style12">Ward Admission </p>
                          <p class="style12">&nbsp;</p>
                          <table width="396" height="212" align="center">
                            <tr>
                              <td valign="top" bgcolor="#FFFFC1"><form id="form3" method="post" action="insert_admission.php">
                                  <table width="390">
                                    <tr>
                                      <td width="42"><a class="style13">Hospital No. </a></td>
                                      <td width="145"><label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF"/>
                                      </label></td>
                                      <td width="1">&nbsp;</td>
                                      <td width="48"><a class="style13">Ward</a></td>
                                      <td width="130"><select name="select2" id="select3" style="background:#003366; color:#FFFFFF">
                                          <option>A&amp;E</option>
                                          <option>Male Surgical</option>
                                          <option>Female Surgical</option>
                                          <option>Maternity</option>
                                          <option>Post Natal</option>
                                      </select></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Bed</a></td>
                                      <td><label>
                                        <select name="bed" id="bed" style="background:#003366; color:#FFFFFF">
                                          <option>1</option>
                                          <option>2</option>
                                          <option>3</option>
                                          <option>4</option>
                                          <option>5</option>
                                          <option>6</option>
                                          <option>7</option>
                                          <option>8</option>
                                          <option>9</option>
                                          <option>10</option>
                                          <option>11</option>
                                          <option>12</option>
                                          <option>13</option>
                                          <option>14</option>
                                          <option>15</option>
                                          <option>16</option>
                                          <option>17</option>
                                          <option>18</option>
                                          <option>19</option>
                                          <option>20</option>
                                          <option>21</option>
                                          <option>22</option>
                                          <option>23</option>
                                          <option>24</option>
                                          <option>25</option>
                                          <option>26</option>
                                          <option>27</option>
                                          <option>28</option>
                                          <option>29</option>
                                          <option>30</option>
                                          <option>31</option>
                                          <option>32</option>
                                          <option>33</option>
                                          <option>34</option>
                                          <option>35</option>
                                          <option>36</option>
                                          <option>37</option>
                                          <option>38</option>
                                          <option>39</option>
                                          <option>40</option>
                                        </select>
                                        <span class="style13"><a href="#" onclick="javascript:popUp('http://localhost/dmr-mist/sh_all_ward.php',1000,200)">[View ward details]</a> </span></label></td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Purpose</a></td>
                                      <td><span class="style3">
                                        <select name="purpose" id="purpose" style="background:#003366; color:#FFFFFF">
                                          <option>Recovery</option>
                                          <option>Examination</option>
                                          <option>Surgery</option>
                                          <option>Delivery</option>
                                        </select>
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Next of Kin </a></td>
                                      <td><label>
                                        <input name="next_of_kin" type="text" id="next_of_kin" style="background:#003366; color:#FFFFFF"/>
                                      </label></td>
                                      <td>&nbsp;</td>
                                      <td><span class="style13"></span></td>
                                      <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td><span class="style13"></span></td>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                      <td><span class="style13"></span></td>
                                      <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Amount Paid </a></td>
                                      <td><select name="amount_paid" id="amount_paid" style="background:#003366; color:#FFFFFF">
                                          <option>200</option>
                                          <option>250</option>
                                          <option>450</option>
                                      </select></td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Payment Purpose </a></td>
                                      <td><label>
                                        <input name="reg_fee" type="checkbox" id="reg_fee" value="Registration Fee" />
                                        <a>Registration fee </a>
                                        <input name="tech_fee" type="checkbox" id="tech_fee" value="Technology Fee" />
                                        <a>Other Charges </a> </label></td>
                                    </tr>
                                  </table>
                                <p>
                                    <input name="Add" type="submit" id="Add" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add"/>
                                  </p>
                              </form>
                              <p class="style14">&nbsp;</p></td>
                            </tr>
                          </table>
                          <p class="style12">&nbsp; </p>
                      </div>
                      <div class="text" id="ans3">
                        <p class="style12">Patient Discharge </p>
                          <p class="style12">&nbsp;</p>
                          <table width="412" height="118" align="center">
                            <tr>
                              <td width="434" valign="top" bgcolor="#FFFFC1"><form id="form3" method="post" action="insert_discharge.php">
                                  <table width="404">
                                    <tr>
                                      <td width="58"><a class="style13">Hospital No. </a></td>
                                      <td width="144"><label>
                                        <input name="hospital_no" type="text" id="hospital_no" style="background:#003366; color:#FFFFFF" />
                                      </label></td>
                                      <td width="10">&nbsp;</td>
                                      <td width="48"><a class="style13">Ward</a></td>
                                      <td width="468"><select name="select3" id="select4" style="background:#003366; color:#FFFFFF">
                                          <option>A&amp;E</option>
                                          <option>Male Surgical</option>
                                          <option>Female Surgical</option>
                                          <option>Maternity</option>
                                          <option>Post Natal</option>
                                      </select></td>
                                    </tr>
                                    <tr>
                                      <td><a class="style13">Bed</a></td>
                                      <td><label>
                                        <select name="select3" id="select5" style="background:#003366; color:#FFFFFF">
                                          <option>1</option>
                                          <option>2</option>
                                          <option>3</option>
                                          <option>4</option>
                                          <option>5</option>
                                          <option>6</option>
                                          <option>7</option>
                                          <option>8</option>
                                          <option>9</option>
                                          <option>10</option>
                                          <option>11</option>
                                          <option>12</option>
                                          <option>13</option>
                                          <option>14</option>
                                          <option>15</option>
                                          <option>16</option>
                                          <option>17</option>
                                          <option>18</option>
                                          <option>19</option>
                                          <option>20</option>
                                          <option>21</option>
                                          <option>22</option>
                                          <option>23</option>
                                          <option>24</option>
                                          <option>25</option>
                                          <option>26</option>
                                          <option>27</option>
                                          <option>28</option>
                                          <option>29</option>
                                          <option>30</option>
                                          <option>31</option>
                                          <option>32</option>
                                          <option>33</option>
                                          <option>34</option>
                                          <option>35</option>
                                          <option>36</option>
                                          <option>37</option>
                                          <option>38</option>
                                          <option>39</option>
                                          <option>40</option>
                                        </select>
                                        <span class="style13"><a href="#" onclick="javascript:popUp('http://localhost/dmr-mist/sh_all_ward.php',1000,200)">[View ward details]</a> </span></label></td>
                                      <td>&nbsp;</td>
                                      <td><a class="style13">Reason</a></td>
                                      <td><label>
                                        <textarea name="reason" id="reason" style="background:#003366; color:#FFFFFF"></textarea>
                                      </label></td>
                                    </tr>
                                  </table>
                                <p>
                                    <input name="Add3" type="submit" id="Add3" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add"/>
                                  </p>
                              </form></td>
                            </tr>
                          </table>
                          <p class="style12">&nbsp;</p>
                      </div>
                      <p>&nbsp;</p>
                    </div>
                    
                      <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
     <!-- footer begins -->
            <div id="footer">
          
		    <p><span class="style11">&copy;2010. EMR-SOFT V 1.0. Powered by e-NERGY Software Solutions</span></p> 
	</div>
        <!-- footer ends -->
</div>

</div>




</body>
</html>
<?php
}
?>