<?php

session_start();

$item = $_POST['item'];
$cost = $_POST['cost'];
$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');

mysql_query("INSERT INTO  expenditure(item,cost,date)VALUES('$item','$cost','$date_added')") or die("Error");

?>
<script type="text/javascript">
alert("Expenditure Added");
window.location = "chief_accountant_page.php";
</script>