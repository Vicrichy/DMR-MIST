<?php 
// start session 
session_start(); 
if ($_SESSION['auth'] != 3 ) { 
    // check if authentication was performed 
    // else die with error 
   echo "<br><br><div align=center><font color=black><h1><b>UNAUTHORIZED ACCESS?!!</h1><br>
<br>THE PAGE IS AUTHENTICALLY PROTECTED!!!
<p><i><b>Please login with correct details</p></i></b>";
} 
else { 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
<!--
var storedDiv = null;
function getDiv(oID) {
if(document.getElementById) {
return document.getElementById(oID);
} else if( document.all ) {
return document.all[oID];
} else { return null; }
}
window.onload = function () {
for( var i = 0, y; y = getDiv('ans'+i); i++ ) {
y.style.display = 'none'
}
};
function toggleInfo(oID) {
var oDiv = getDiv(oID); if( !oDiv ) { return; }
oDiv.style.display = (oDiv.style.display=='none') ? 'block' : 'none'
if( storedDiv && storedDiv != oDiv ) { storedDiv.style.display = 'none'
} storedDiv = oDiv;
}
//--></script>
<script type="text/javascript">
function logout()
{window.location = "logout.php"};
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>|Management Page</title>
<style type="text/css">
<!--
.style1 {	font-family: "Century Gothic";
	font-weight: bold;
	font-size: 36px;
	color: #000033;
}
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.style4 {color: #000033; font-weight: bold; font-style: italic; font-size: 16px; }
.style7 {
	font-size: 14px;
	color: #CCCCCC;
	font-weight: bold;
}
.style9 {
	color: #CCCCCC;
	font-weight: bold;
}
.style10 {color: #000033}
.style3 {font-size: 12px}
.style11 {color: #000033; font-weight: bold; }
.style12 {
	color: #FF0000;
	font-size: 12px;
}
-->
</style>
</head>

<body>
<table width="947" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="105" colspan="11" valign="middle" bgcolor="#FFFFC1"><p class="style1">CIRCUIT WORKS LTD <span class="style4">EMR-SOFT</span></p>      </td>
  </tr>
<script type="text/javascript">
alert("Welcome <?php echo "$_SESSION[name]";?>! You have been granted access");
</script> 
  <tr>
    <td width="24" height="31" bgcolor="#FFFFC1">&nbsp;</td>
    <td width="177" align="center" valign="middle" bgcolor="#000033"><span class="style7" style="cursor:pointer" onClick="toggleInfo('ans0');">Staff Information </span></td>
    <td width="12" valign="top" bgcolor="#FFFFC1"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="177" align="center" valign="middle" bgcolor="#000033"><span class="style7" style="cursor:pointer" onClick="toggleInfo('ans1');">Patient Information </span></td>
    <td width="12" valign="top" bgcolor="#FFFFC1"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td colspan="2" align="center" valign="middle" bgcolor="#000033"><span class="style9" style="cursor:pointer" onClick="toggleInfo('ans2');">Ward Information </span></td>
    <td width="12" valign="top" bgcolor="#FFFFC1"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="177" align="center" valign="middle" bgcolor="#000033"><span class="style9" style="cursor:pointer" onClick="toggleInfo('ans3');">Account Information  </span></td>
    <td width="53" bgcolor="#FFFFC1">&nbsp;</td>
    <td width="126" bgcolor="#FFFFC1">&nbsp;</td>
  </tr>
  <tr>
    <td height="20" colspan="11" valign="top" bgcolor="#FFFFC1"><hr /></td>
  </tr>
  <tr>
    <td height="404" colspan="11" valign="top"><div class="style11" id="ans0">
        <p>Staff Information </p>
        <table width="773" height="212" align="center">
          <tr>
            <td align="center" valign="top" bgcolor="#FFFFC1"><p class="style3">Name: <span class="style10"><?php echo $_SESSION['name'];?></span></p>
            <p class="style3">Sex: <?php echo $_SESSION['sex'];?></p>
            <p class="style3">Department: <?php echo $_SESSION['department'];?></p>
            <p class="style3">Phone: <?php echo $_SESSION['phone'];?></p>
            <p class="style3">Email: <?php echo $_SESSION['email'];?></p>
            <p class="style3">Last Login: <?php echo $_SESSION['last_login'];?></p>
            <p class="style3">
              <input name="Edit" type="button" id="Edit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Edit" />
            </p></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </div>
      <div class="style11" id="ans1">
        <p>New registration </p>
        <table width="773" height="212" align="center">
          <tr>
            <td valign="top" bgcolor="#FFFFC1"><form id="form1" name="form1" method="post" action="">
              <table width="766">
                <tr>
                  <td width="127" class="style3">First Name </td>
                  <td width="256"><label>
                    <input name="fname" type="text" id="fname" />
                  </label></td>
                  <td width="37">&nbsp;</td>
                  <td width="159"><span class="style3">Hospital No. </span></td>
                  <td width="162"><input name="hospital_no" type="text" id="hospital_no" /></td>
                </tr>
                <tr>
                  <td><span class="style3">Last Name </span></td>
                  <td><input name="lname" type="text" id="lname" /></td>
                  <td>&nbsp;</td>
                  <td><span class="style3">Registration Point </span></td>
                  <td><label>
                    <select name="registration_point" id="registration_point">
                      <option>Registration Point 1</option>
                      <option>Registration Point 2</option>
                      <option>Registration Point 3</option>
                      <option>Registration Point 4</option>
                    </select>
                  </label></td>
                </tr>
                <tr>
                  <td><span class="style3">Date of Birth </span></td>
                  <td><input name="date_of_birth" type="text" id="date_of_birth" /> 
                    <span class="style12">[dd-mm-yy]</span></td>
                  <td>&nbsp;</td>
                  <td><span class="style3">Purpose</span></td>
                  <td><input name="purpose" type="text" id="purpose" /></td>
                </tr>
                <tr>
                  <td><span class="style3">Sex</span></td>
                  <td><input name="sex" type="text" id="sex" /></td>
                  <td>&nbsp;</td>
                  <td><span class="style3">Phone</span></td>
                  <td><input name="phone" type="text" id="phone" /></td>
                </tr>
                <tr>
                  <td><span class="style3">Occupation</span></td>
                  <td><input name="occupation" type="text" id="occupation" /></td>
                  <td>&nbsp;</td>
                  <td><span class="style3">Email</span></td>
                  <td><input name="email" type="text" id="email" /></td>
                </tr>
                <tr>
                  <td><span class="style3">Next of Kin </span></td>
                  <td><input name="next_of_kin" type="text" id="next_of_kin" /></td>
                  <td>&nbsp;</td>
                  <td><span class="style3">Address</span></td>
                  <td><textarea name="address" id="address"></textarea></td>
                </tr>
                <tr>
                  <td><span class="style3">Visit Status </span></td>
                  <td><select name="visit_status" id="visit_status">
                    <option>Not Attended to</option>
                    <option>Attended to</option>
                                    </select></td>
                  <td>&nbsp;</td>
                  <td><span class="style3">Medical Personnel </span></td>
                  <td><select name="medical personnel" id="medical personnel">
                    <option>Medical Consultant</option>
                                    </select></td>
                </tr>
              </table>
                         <p>
                           <input name="Submit" type="submit" id="Submit" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add" onclick="logout();" />
                         </p>
            </form>
            </td>
          </tr>
        </table>
        <hr />
        <p>Old Patient </p>
        <table width="773" height="68" align="center">
          <tr>
            <td bgcolor="#FFFFC1"><form id="form3" name="form3" method="post" action="">
              <table width="443" align="center">
                <tr>
                  <td width="121"><span class="style3">Hospital No. </span></td>
                  <td width="172"><input name="hospital_no" type="text" id="hospital_no" /></td>
                  <td width="134"><input name="Search" type="button" id="Search" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Search" onclick="toggleInfo('ans4');" /></td>
                </tr>
              </table>
                        </form>
            </td>
          </tr>
        </table>
        <p>&nbsp;</p>
      </div>      
      <div class="style11" id="ans2">
        <p>View Registrations </p>
        <table width="773" height="212" align="center">
          <tr>
            <td bgcolor="#FFFFC1">&nbsp;</td>
          </tr>
        </table>
        <p>&nbsp;</p>
    </div>      
      <div class="style11" id="ans3">
        <p>Ward Admission </p>
        <table width="773" height="212" align="center">
          <tr>
            <td valign="top" bgcolor="#FFFFC1"><form id="form2" name="form2" method="post" action="">
              <table width="604">
                <tr>
                  <td width="134"><span class="style3">Hospital No. </span></td>
                  <td width="189"><label>
                    <input name="hospital_no" type="text" id="hospital_no" />
                  </label></td>
                  <td width="189">&nbsp;</td>
                </tr>
                <tr>
                  <td><span class="style3">First Name </span></td>
                  <td><input name="fname" type="text" id="fname" /></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><span class="style3">Last Name </span></td>
                  <td><input name="lname" type="text" id="lname" /></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><span class="style3">Ward</span></td>
                  <td><label>
                    <select name="ward" id="ward">
                      <option>A&amp;E</option>
                      <option>Male Surgical</option>
                      <option>Female Surgical</option>
                      <option>Maternity</option>
                      <option>Post Natal</option>
                    </select>
                  </label></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><span class="style3">Bed</span></td>
                  <td><select name="bed" id="bed">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                                    </select></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><span class="style3">Patient's Case </span></td>
                  <td><input name="patient_case" type="text" id="patient_case" /></td>
                  <td><span class="style12">*State Patient's health issue </span></td>
                </tr>
                <tr>
                  <td><span class="style3">Next of Kin </span></td>
                  <td><input name="next_of_kin" type="text" id="next_of_kin" /></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><span class="style3">Bill Paid </span></td>
                  <td><label>
                    <select name="bill_paid" id="bill_paid">
                      <option>Yes</option>
                      <option>No</option>
                    </select>
                  </label></td>
                  <td>&nbsp;</td>
                </tr>
              </table>
                        <p>
                          <input name="Submit2" type="submit" id="Submit2" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Add" onclick="logout();" />
                        </p>
            </form>
            </td>
          </tr>
        </table>
        <p>&nbsp;</p>
    </div>      <p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td height="30">&nbsp;</td>
    <td colspan="3" valign="middle" bgcolor="#FFFFC1"><span class="style10">&copy;2010. EMR-SOFT V 1.0. Powered by Circuitworks </span></td>
  <td bgcolor="#FFFFC1">&nbsp;</td>
    <td width="145" valign="middle" bgcolor="#FFFFC1"><span class="style3"><a href="#"> Help</a>|<a href="#">FAQ</a>|<a href="#">Contact</a></span></td>
    <td colspan="4" valign="middle" bgcolor="#FFFFC1"><span class="style10">Login: <?php echo $_SESSION['user_id'];?> </span></td>
  <td valign="middle" bgcolor="#FFFFC1"><input name="Login" type="button" id="Login" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Logout" onclick="logout();" /></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td width="32"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>

</body>
</html>
<?php
}
?>