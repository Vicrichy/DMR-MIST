<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search Results:: Pharmacy Prescription Search</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000033;
}
-->
</style></head>

<body>

<?php

$day = addslashes($_POST['day']);
$month = addslashes($_POST['month']);
$year = addslashes($_POST['year']);
$date = "$day-$month-$year";

	include('dbconnect.php');
	$query = mysql_query("SELECT `date_added`,`prescribtion_no`,`repeat`,`doctor`,`status`,`number`,`financial_status` FROM `prescribtion` WHERE `date_added` = '$date'")or die("Error");
	$sql = @mysql_num_rows($query);
	$query1 = mysql_query("SELECT `prescribtion` FROM `prescribtions` WHERE `date_added` = '$date'");
	$query2 = mysql_query("SELECT `price` FROM `prescribtions` WHERE `date_added` = '$date'");
	$query3 = mysql_query("SELECT `dosage` FROM `prescribtions` WHERE `date_added` = '$date'");
	echo "<html>";
	echo "<table width=950 height=187 align=center>";
	echo "<tr>";
	echo "<td valign=top bgcolor=#FFFFC1><table width=800 border=1>";
	echo "<tr>";
	echo "<td><strong>Date </strong></td>
        <td><strong>Prescription Number </strong></td>
        <td><strong>Repeat </strong></td>
        <td><strong>Doctor </strong></td>
        <td><strong>Status</strong></td>
        <td><strong>Number of Items</strong></td>
        <td><strong>Financial Status </strong></td>
		</tr>";
	while($rows = @mysql_fetch_array($query, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td class = style2>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 	echo "</td>";
		}
	

echo "</tr>";
echo "</table></html>"; 


?>