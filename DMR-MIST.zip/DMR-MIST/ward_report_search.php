<?php
session_start();
if($_SESSION['auth']!=3)
{
  header("location:index.php");
 }
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search Results::Ward Report Search</title><style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000033;
}
-->
</style></head>

<body>

<?php

$count=0;
$ward = addslashes($_POST['ward']);
$day = addslashes($_POST['day']);
$month = addslashes($_POST['month']);
$year = addslashes($_POST['year']);

$date = "$day-$month-$year";

include('dbconnect.php');

$sql = mysql_query("SELECT `ward`,`deaths`,`nurses`,`general_summary`,`critical_cases`,`referrals`,`discharges`,`admissions`, `births`,`recommendations`,`problems` FROM report WHERE `ward`='$ward' AND `date_added` = '$date'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("Sorry! Ward record does not exist");
window.location = "dir_of_nursing_page.php");
</script>
<?php  
exit();
}
else
{
echo "<html>";
	echo "<table width=950 height=187 align=center>";
	echo "<tr>";
	echo " <td valign=top bgcolor=#FFFFC1><table width=942 border=1>";
	echo "<tr>";
	echo "<td width=76><strong>Ward </strong></td>
        <td width=76><strong>Deaths </strong></td>
        <td width=76><strong>Nurses </strong></td>
        <td width=76><strong>General Summary </strong></td>
        <td width=75><strong>No. Of Critical Cases  </strong></td>
		<td width=75><strong>No.Of Referrals  </strong></td>
        <td width=75><strong>No. Of Discharges  </strong></td>
		<td width=75><strong>No. Of Admissions  </strong></td>
		<td width=75><strong>No. Of Births  </strong></td>
		<td width=75><strong>Recommendations  </strong></td>
		<td width=75><strong>Problems  </strong></td>
		
		</tr>";
	while($rows = @mysql_fetch_array($sql, MYSQL_ASSOC))
	{
	 echo "<tr>";
	 foreach($rows as $col_value)
	 {
	   echo "<td>$col_value</td>";
	  } 
	 // $_SESSION['title'] = $row['title'];
	 // $_SESSION['field'] = $row['field'];
	 // $_SESSION['download'] = $row['downloads'];
	 $count++;
	 echo "</tr>";
	}
	
	echo "</table></html>"; 
}
?>	