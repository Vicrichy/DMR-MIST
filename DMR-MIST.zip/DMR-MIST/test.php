<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
var $ = Object.prototype.$ = function(id){ return document.getElementById ? document.getElementById(id) : document.all ? document.all[id] : null };//Thanks to Essential
function showHideTableRow(tr, show){
if(!tr){ return false; }
  try{
      tr.style.display = (show) ? 'table-row' : 'none';
     return true;
     }
catch(e){
tr.style.display = (show) ? 'block' : 'none';
return true;
}
}
function selAction(sel){
for(var i=0; i<sel.options.length; i++){
var trID = sel.options[i].getAttribute('bindTo');
if(trID !== ''){
var tr = $(sel.options[i].getAttribute('bindTo'));
var rtnVal = showHideTableRow(tr, i == sel.selectedIndex);
 // if(!rtnVal){ alert('Table group "' + sel[sel.selectedIndex].value + '" not found'); }//Uncomment this to debug
}
}
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style3 {font-size: 12px}
-->
</style>
</head>

<body>
<table>
<tr>
<td>Name</td>
<td colspan="3"><input name="name" type="text" id="name" /></td>
</tr>
<tr>
  <td>Password</td>
  <td colspan="3"><input name="password" type="password" id="password" /></td>
</tr>
<tr>
  <td>User Id </td>
  <td colspan="3"><select name="type" onchange="selAction(this);">
    <option bindto="" value="Please Select an employee type:">Please Select a Login type:</option>
    <option bindto="" value="Medical Consultant">Medical Consultant</option>
    <option bindto="" value="Registration Staff">Registration Staff</option>
    <option bindto="" value="Pharmacist">Pharmacist</option>
    <option bindto="" value="Laboratory Staff">Laboratory Staff</option>
    <option bindto="" value="Accounts">Accounts</option>
    <option bindto="trVol" value="Nursing Officer">Nursing Officer</option>
    <option bindto="trMan" value="Management">Management</option>
  </select></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td colspan="3">&nbsp;</td>
</tr>

<tbody id="trVol" style="display:none;">
<tr>
<td>Select Nursing Officer Type</td>
<td><select name="type">
<option>Clinic Nurse</option>
<option>Ward Nurse</option>
</select></td>
</tr>
</tbody>
<tbody id="trMan" style="display:none;">
<tr>
<td>Select Managment Position</td>
<td><select name="type">
<option>CMD</option>
<option>CMAC</option>
<option>Chief Accountant</option>
<option>Dir. of Pharmacy</option>
<option>Dir. of Planning</option>
<option>Dir. of Nursing</option>
</select></td>
</tr>
<tr>
  <td><input name="Login" type="submit" id="Login" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Login" /></td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td colspan="2"><p class="style3">Forgot Password? <a href="#">Click Here</a></p>
    <p class="style3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;</p>
    <p class="style3">&nbsp;V.1.0. &copy;2010 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Help</a>|<a href="#">FAQ</a>|<a href="#">Contact</a></p>
    </td>
  </tr>
</tbody>
</table>
<table width="394" align="center">
  <!--DWLayoutTable-->
  <tr>
    <td width="127"><span class="style3">User Id </span></td>
    <td colspan="3"><label>
      <select name="user_id" id="user_id">
        <option>Registration Staff</option>
        <option>Medical Consultant</option>
        <option>Pharmacist</option>
        <option>Laboratory Staff</option>
        <option>Management</option>
        <option>Nursing Officer</option>
        <option>Accounts</option>
      </select>
    </label></td>
  </tr>
  <tr>
    <td><span class="style3">Password</span></td>
    <td colspan="3"><input name="password2" type="password" id="password2" /></td>
  </tr>
  <tr>
    <td><span class="style3">Name</span></td>
    <td colspan="3"><input name="name2" type="text" id="name2" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><label></label></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input name="Login2" type="submit" id="Login2" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Login" /></td>
  </tr>
  <tr>
    <td height="49" colspan="4" valign="top" background="#"><p class="style3">Forgot Password? <a href="#">Click Here</a></p>
        <p class="style3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p class="style3">&nbsp;V.1.0. &copy;2010 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Help</a>|<a href="#">FAQ</a>|<a href="#">Contact</a></p></td>
  </tr>
  <tr>
    <td height="5"></td>
    <td width="47"></td>
    <td width="54"></td>
    <td width="57"></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>

</body>
</html>