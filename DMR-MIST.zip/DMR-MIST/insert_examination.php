<?php

session_start();
$_SESSION['auth'] = 3;
$hospital_no = $_POST['hospital_no'];
$subjective = $_POST['subjective'];
$objective = $_POST['objective'];
$assessment1 = $_POST['assessment1'];
$ICD_code_1 = $_POST['ICD_code_1'];
$assessment2 = $_POST['assessment2'];
$ICD_code_2 = $_POST['ICD_code_2'];
$disease_1 = $_POST['disease_1'];
$disease_2 = $_POST['disease_2'];
$admission = $_POST['admission'];
$ICD_code_1 = "$ICD_code_1($disease_1)";

$ICD_code_2 = "$ICD_code_2($disease_2)";
$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

if($admission != '')
{
include('dbconnect.php');
mysql_query("INSERT INTO `admission` SET `hospital_no` = '$hospital_no'");
}

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist! Please try again");
window.location = "medical_consultant_page.php";
</script>
<?php
exit();
}
else
{
include('dbconnect.php');
mysql_query("INSERT INTO examination(hospital_no,subjective,objective,assessment1,ICD_code_1,assessment2,ICD_code_2,date_added,admission)VALUES('$hospital_no','$subjective','$objective','$assessment1','$ICD_code_1','$assessment2','$ICD_code_2','$date_added','$admission')") or die("Error");
include('dbconnect.php');
mysql_query("UPDATE `patients` SET `doctor_incharge` = '$_SESSION[name]' WHERE `hospital_no` = '$hospital_no'");
}
?>
<script type="text/javascript">
alert("Patient Examination Record Added");
window.location = "medical_consultant_page.php";
</script>