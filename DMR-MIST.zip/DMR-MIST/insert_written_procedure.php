<?php

$hospital_no = addslashes($_POST['hospital_no']);
$pix = $_POST['pix'];


$month = date("M");
$day = date("d");
$year = date("Y");

$date = "$day-$month-$year";
$code = rand();
//picture uploading
$file_name = $_FILES['userfile']['name'];
$file_ext = strtolower(substr($file_name,strrpos($file_name,".")));

if ((($_FILES["userfile"]["type"] == "image/gif")
|| ($_FILES["userfile"]["type"] == "image/jpeg")
|| ($_FILES["userfile"]["type"] == "image/jpg")
|| ($_FILES["userfile"]["type"] == "image/pjpeg"))
&& ($_FILES["userfile"]["size"] < 4000000))
  {
  if ($_FILES["userfile"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["userfile"]["error"] ."<br />";
    }
		if (file_exists("procedure/" .$code.$file_ext))
      {
      echo $_FILES["userfile"]["name"] . " already exists.   <a href=javascript:history.back()> << Return </a>";
      }
    else
      {
	  
       move_uploaded_file($_FILES["userfile"]["tmp_name"],
      "procedure/" .$code.$file_ext);
      //echo "Stored in: " . "pix/" . $_FILES["userfile"]["name"];
      }
    }
else
  {
  echo "Invalid file";
  }
$procedure = "$code$file_ext";
include('dbconnect.php');
$query = mysql_query("INSERT INTO written_procedure(hospital_no,date_added,examination)VALUES('$hospital_no','$date','$procedure')")or die("Error");

?>
<script type="text/javascript">
alert("Written Procedure Request Successfully added");
window.close();
</script>