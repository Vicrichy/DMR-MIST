﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
var $ = Object.prototype.$ = function(id){ return document.getElementById ? document.getElementById(id) : document.all ? document.all[id] : null };//Thanks to Essential
function showHideTableRow(tr, show){
if(!tr){ return false; }
  try{
      tr.style.display = (show) ? 'table-row' : 'none';
     return true;
     }
catch(e){
tr.style.display = (show) ? 'block' : 'none';
return true;
}
}
function selAction(sel){
for(var i=0; i<sel.options.length; i++){
var trID = sel.options[i].getAttribute('bindTo');
if(trID !== ''){
var tr = $(sel.options[i].getAttribute('bindTo'));
var rtnVal = showHideTableRow(tr, i == sel.selectedIndex);
 // if(!rtnVal){ alert('Table group "' + sel[sel.selectedIndex].value + '" not found'); }//Uncomment this to debug
}
}
}
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Home| EMR - SOFT</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style3 {font-size: 12px}
.style4 {color: #FFFFFF}
-->
</style>
</head>
<body>


<div id="bg2">




<div id="bg3">
<!-- header begins -->
<div id="header">
	 <div class="style4" id="buttons"><marquee>...providing digital medical solutions</marquee> </div>
	 <div id="logo"><a href="#" class="style1">EMR - SOFT  </a>
      <h2><a href="#" id="metamorph">e-NERGY Software Solutions</a></h2>
    </div>
   
</div>
<!-- header ends -->
        <!-- content begins -->
       	<div id="content">
            <div id="main">
                <div id="main_bot">
                    <div id="main_top">
                    <div id="right">
                   	  <h1 class="tit_right1">CMD</h1>	
                        <div class="right_b">
                          <div class="munth">
                            <p><img src="Image008.jpg" alt="" width="96" height="120" /></p>
                            <p>Name: Dr Bassey </p>
                            <p>Phone: 08039098042</p>
                            <p>Email: cmd@ucth.com </p>
                            <p><em>&quot;we strive to give our best to the patients we handle&quot; - CMD </em></p>
                            <p>&nbsp;</p>
                          </div>
                          	
           	  		  </div>
                        <h1 class="tit_right2">CMAC</h1>	
                    	<div class="right_w fish_10">
                    	  <div class="munth">
                    	    <p><img src="Image008.jpg" alt="vik" width="96" height="120" /></p>
                    	    <p>&nbsp;</p>
                    	    <p>Name: Dr Otu </p>
                    	    <p>Phone: 08039098042</p>
                    	    <p>Email: cmac@ucth.com</p>
                    	    <p>&nbsp;  </p>
                    	    <p><em>&quot;we strive to give our best to the patients we handle&quot;</em><em> - CMAC </em></p>
                    	    <p>&nbsp;</p>
                    	  </div>
               	  	  </div>
                    	
                        
                    </div>
                    <div id="left">
                   	   <h1> Hospital News</h1>
                       <div class="box1">
                        <div class="left_b"><span class="w">Friday, Apr.10, 2010</span><br />
                          The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                       <div class="box2">
                           <div class="left_b"><span class="w">Saturday, Apr. 11, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                       <div class="box3">
                           <div class="left_b"><span class="w">Sunday, Apr. 12, 2010</span><br />
                             The hospital management today welcomed the minister of health of the federation on a two-day visit....
<div class="read"><a href="#"> read more</a></div>
                         </div>
                       </div>
                      <div class="box4">
                          <div class="left_b"><span class="w">Monday, Apr. 13, 2010</span><br />
                                   The hospital management today welcomed the minister of health of the federation on a two-day visit....
                                     <div class="read"><a href="#"> read more</a></div>
                        </div>
                      </div>
                      </div>
                    <div id="center">
                      <h1>Welcome to EMR-SOFT </h1>
                        <div class="text">
                        	<span>About EMR-SOFT </span>
                      	</div>
                         <div class="text">
                           <p><img src="images/stethoscope2.jpg" class="img" width="120" height="90" alt="" />The online “Digital  Medical Record-Management Information System Technology” (EMR-SOFT) solution is  a solid, integrated, user friendly software application<strong>. </strong>It has been  specially designed and developed for providing digital quality  service delivery to support the operations of clinical processes,  management and decision making functions in the hospital. </p>
                           <p>The technology allows you to create and  maintain medical record database through a system that utilizes ICT Equipments  and Software to address and overcome  the over boring manual procedures for accessing daily medical records of patients. With EMR-SOFT solution, you can guarantee  automatic processing of medical records, update and print on time as well as  standardize the system of obtaining reports and statistical information from  the hospital. </p>
                           <p>Moreover, health personnel who may be  far from their work place can in a case of emergency access patients’ record  online via the Internet (as allowable by the operating Institution) and  immediately render medical services or advice as the case may be. </p>
                        </div>
                        
                        <div class="text">
                          <h1>User Login  </h1>
                          <p>&nbsp;</p>
                          <form id="form1" method="post" action="staff_login.php">
                            <table bgcolor="#FFFFC1">
                              <tr>
                                <td bgcolor="#FFFFC1" class="style3">Name</td>
                                <td colspan="3"><input name="name" type="text" id="name" style="background:#003366; color:#FFFFFF" /></td>
                              </tr>
                              <tr>
                                <td bgcolor="#FFFFC1" class="style3">Password</td>
                                <td colspan="3"><input name="password" type="password" id="password" style="background:#003366; color:#FFFFFF" /></td>
                              </tr>
                              <tr>
                                <td bgcolor="#FFFFC1" class="style3">User Id </td>
                                <td colspan="3"><select name="user_id" id="user_id" onchange="selAction(this);" style="background:#003366; color:#FFFFFF">
                                    <option bindto="" value="Please Select an employee type:">Please Select a Login type:</option>
                                    <option bindto="">Medical Consultant</option>
                                    <option>Records</option>
                                    <option bindto="">Pharmacist</option>
                                    <option bindto="">Laboratory Staff</option>
                                    <option bindto="">Accounts</option>
                                    <option bindto="trVol" value="Nursing Officer">Nursing Officer</option>
                                    <option bindto="trMan" value="Management">Management</option>
                                </select></td>
                              </tr>
                              <tbody id="trVol" style="display:none;">
                                <tr>
                                  <td bgcolor="#FFFFC1" class="style3">Select Nursing Officer Type</td>
                                  <td><select name="user_id1" id="user_id1" style="background:#003366; color:#FFFFFF">
                                      <option selected="selected"></option>
                                      <option>Clinic Nurse</option>
                                      <option>Ward Nurse</option>
                                  </select></td>
                                </tr>
                              </tbody>
                              <tbody id="trMan" style="display:none;">
                                <tr>
                                  <td bgcolor="#FFFFC1" class="style3">Select Managment Position</td>
                                  <td><select name="user_id2" id="user_id2" style="background:#003366; color:#FFFFFF">
                                      <option selected="selected"></option>
                                      <option>CMD</option>
                                      <option>CMAC</option>
                                      <option>Chief Accountant</option>
                                      <option>Dir. of Pharmacy</option>
                                      <option>Dir. of Nursing</option>
                                  </select></td>
                                </tr>
                              </tbody>
                              <tr>
                                <td></tbody></td>
                              </tr>
                              <tr>
                                <td><input name="Login" type="submit" id="Login" style="background-color:#000033;color:#CCCCCC;font-weight:bold;font:'Century Gothic'" value="Login" /></td>
                              </tr>
                            </table>
                            <p>&nbsp;</p>
                          </form>
                          <p><a href="#">Forgot Password?</a> </p>
                      </div>
                        <p>&nbsp;</p>
                    </div>
                    
                      <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
                    </div>
                </div>
            </div>
        
        </div>
    <!-- content ends -->
     <!-- footer begins -->
            <div id="footer">
          
		    <p>Copyright  2010. <a href="#">Powered by e-NERGY Software Solutions</a></p> 
	</div>
        <!-- footer ends -->
</div>

</div>




</body>
</html>
