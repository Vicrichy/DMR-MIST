-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2011 at 05:48 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `emr`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `item` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'NOT PAID',
  `date_added` varchar(100) NOT NULL,
  `section` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `hospital_no`, `item`, `amount`, `quantity`, `status`, `date_added`, `section`, `timestamp`) VALUES
(1, 'UUTH/2010/15269', 'Panadol', '100', '', 'PAID', '06-Oct-2010', '', '2010-10-05 06:47:56'),
(2, 'UUTH/2010/15269', 'X-ray', '1500', '', 'PAID', '06-Oct-2010', '', '2010-10-05 12:00:22'),
(3, 'UUTH/2010/15269', 'Ultrascan', '1500', '', 'PAID', '06-Oct-2010', '', '2010-10-05 12:00:22'),
(4, 'UUTH/2010/31124', 'Hematocrit', '500', '', '', '05-Oct-2010', '', '2010-10-05 12:42:54'),
(5, 'UUTH/2010/31124', 'Fibrinogen', '500', '', '', '05-Oct-2010', '', '2010-10-05 12:42:54'),
(6, 'UUTH/2010/31124', 'Coombs Test Direct', '500', '', '', '05-Oct-2010', '', '2010-10-05 12:42:54'),
(7, 'UUTH/2010/31124', 'Blood Viscocity', '500', '', '', '05-Oct-2010', '', '2010-10-05 13:23:27'),
(8, 'UUTH/2010/31124', 'Ultrascan', '1500', '', '', '05-Oct-2010', '', '2010-10-05 13:23:27'),
(9, 'UUTH/2010/32270', 'White Blood Cell', '500', '', 'PAID', '05-Oct-2010', '', '2010-10-05 16:15:19'),
(10, 'UUTH/2010/32270', 'Blood Viscocity', '500', '', 'PAID', '05-Oct-2010', '', '2010-10-05 16:15:19'),
(11, 'UUTH/2010/32270', 'MED/104', '250', '', 'PAID', '05-Oct-2010', '', '2010-10-05 16:31:00'),
(12, 'UUTH/2010/32270', 'MED/114', '40', '', 'PAID', '05-Oct-2010', '', '2010-10-05 16:31:00'),
(22, 'UUTH/2010/15210', 'Complete Blood Test', '500', '', 'PAID', '07-Oct-2010', '', '2010-10-07 18:24:00'),
(23, 'UUTH/2010/15210', 'X-RAY', '1500', '', 'PAID', '07-Oct-2010', '', '2010-10-07 18:24:00'),
(24, 'UUTH/2010/15210', 'MED/100', '250', '', 'PAID', '07-Oct-2010', '', '2010-10-07 18:29:43'),
(25, 'UUTH/2010/15210', 'MED/114', '60', '', 'PAID', '07-Oct-2010', '', '2010-10-07 18:29:43'),
(26, 'UUTH/2010/27364', 'Complete Blood Test', '500', '', 'PAID', '07-Oct-2010', '', '2010-10-07 20:02:20'),
(27, 'UUTH/2010/27364', 'X-RAY', '1500', '', 'PAID', '07-Oct-2010', '', '2010-10-07 20:02:20'),
(28, 'UUTH/2010/27364', 'MED/100', '100', '', 'PAID', '07-Oct-2010', '', '2010-10-07 20:09:55'),
(29, 'UUTH/2010/27364', 'MED/114', '40', '', 'PAID', '07-Oct-2010', '', '2010-10-07 20:09:55'),
(30, 'UUTH/2010/15307', 'Complete Blood Test', '500', '', '', '08-Oct-2010', '', '2010-10-08 05:37:04'),
(31, 'UUTH/2010/15307', 'G6PD', '500', '', '', '08-Oct-2010', '', '2010-10-08 05:37:04'),
(32, 'UUTH/2010/15307', 'MED/100', '20', '', 'PAID', '08-Oct-2010', '', '2010-10-08 07:39:55'),
(33, 'UUTH/2010/23843', 'REGISTRATION FEE', '450', '', 'PAID', '08-Oct-2010', 'RECORDS', '2010-10-08 07:51:57'),
(34, 'UUTH/2010/23843', 'REGISTRATION FEE', '450', '', 'PAID', '08-Oct-2010', 'A&E ward', '2010-10-08 07:54:52'),
(35, 'UUTH/2010/13726', 'REGISTRATION FEE', '200', '', 'PAID', '08-Oct-2010', 'RECORDS', '2010-10-08 08:05:53'),
(36, 'UUTH/2010/23843', 'Plasma Viscocity', '500', '', 'PAID', '08-Oct-2010', 'Lab', '2010-10-08 09:34:53'),
(37, 'UUTH/2010/23843', 'Ferritin', '500', '', 'PAID', '08-Oct-2010', 'Lab', '2010-10-08 09:34:53'),
(38, 'UUTH/2010/23843', 'G6PD', '500', '', 'PAID', '08-Oct-2010', 'Lab', '2010-10-08 09:34:53'),
(39, 'UUTH/2010/23843', 'Spirometry', '500', '', 'PAID', '08-Oct-2010', 'Lab', '2010-10-08 09:34:53'),
(40, 'UUTH/2010/23843', 'X-RAY', '1500', '', 'PAID', '08-Oct-2010', 'Lab', '2010-10-08 09:34:53'),
(41, 'UUTH/2010/23843', 'MED/100', '50', '', 'PAID', '08-Oct-2010', 'Pharmacy', '2010-10-08 09:35:34'),
(42, 'UUTH/2010/20774', 'REGISTRATION FEE', '450', '', 'PAID', '08-Oct-2010', 'RECORDS', '2010-10-08 11:38:54'),
(43, 'UUTH/2010/20774', 'Complete Blood Test', '500', '', 'PAID', '08-Oct-2010', 'Lab', '2010-10-08 11:48:15'),
(44, 'UUTH/2010/20774', 'X-RAY', '1500', '', 'PAID', '08-Oct-2010', 'Lab', '2010-10-08 11:48:15'),
(45, 'UUTH/2010/20774', 'MED/100', '100', '', 'PAID', '08-Oct-2010', 'Pharmacy', '2010-10-08 11:57:46'),
(46, 'UUTH/2010/20774', 'MED/114', '60', '', 'PAID', '08-Oct-2010', 'Pharmacy', '2010-10-08 11:57:46'),
(47, 'UUTH/2010/23843', 'Panadol', '100', '20', 'PAID', '08-Oct-2010', 'Pharmacy', '2010-10-08 22:54:01'),
(48, 'UUTH/2010/23843', 'Lonart', '40', '20', 'PAID', '08-Oct-2010', 'Pharmacy', '2010-10-08 22:54:01'),
(49, 'UUTH/2010/23843', 'Flagyl', '100', '20', 'PAID', '08-Oct-2010', 'Pharmacy', '2010-10-08 22:54:01'),
(50, '', 'REGISTRATION FEE', '200', '', 'PAID', '28-Jan-2011', 'RECORDS', '2011-01-28 13:04:01'),
(51, 'UUTH/2010/15269', 'White Blood Cell', '500', '', 'NOT PAID', '27-Mar-2011', 'Lab', '2011-03-27 19:39:59'),
(52, 'UUTH/2010/15269', 'TIBC', '500', '', 'NOT PAID', '27-Mar-2011', 'Lab', '2011-03-27 19:39:59');

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE IF NOT EXISTS `admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(50) NOT NULL,
  `ward` varchar(50) NOT NULL,
  `bed` varchar(20) NOT NULL,
  `doctor_incharge` varchar(100) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `next_of_kin` varchar(100) NOT NULL,
  `amount_paid` varchar(20) NOT NULL,
  `date_added` varchar(50) NOT NULL,
  `payment_purpose` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`id`, `hospital_no`, `ward`, `bed`, `doctor_incharge`, `purpose`, `next_of_kin`, `amount_paid`, `date_added`, `payment_purpose`, `timestamp`) VALUES
(1, 'UUTH/2010/6416', 'A&E', '1', '', 'Recovery', 'John Asuquo', 'N 200', '19-Sep-2010', 'Technology Fee, Admission Fee', '2010-09-19 12:26:49'),
(2, 'UUTH/2010/31124', 'A&E', '1', '', 'Recovery', 'John Bassey', 'N 200', '21-Sep-2010', 'Technology Fee, Admission Fee', '2010-09-21 18:21:56'),
(3, 'UUTH/2010/31124', 'Pediatric', '1', '', 'Recovery', 'Kadiri Mohammed', 'N 200', '26-Sep-2010', 'Technology Fee, Admission Fee', '2010-09-26 15:17:21'),
(4, 'UUTH/2010/30527', '', '', '', '', '', '', '', '', '2010-10-07 17:18:54'),
(5, 'UUTH/2010/30527', 'A&E', '1', '', 'Recovery', 'Medical Consultant', 'N 200', '07-Oct-2010', 'Technology Fee, ', '2010-10-07 17:45:15'),
(7, 'UUTH/2010/15307', 'A&E', '1', 'Chukwuemeka Kalu', 'Recovery', 'Medical Consultant', 'N 450', '08-Oct-2010', 'Technology Fee, ', '2010-10-08 05:37:56'),
(10, 'UUTH/2010/23843', 'A&E', '1', 'Chukwuemeka Kalu', 'Recovery', 'Bassey Bassey', 'N 450', '08-Oct-2010', 'Technology Fee, ', '2010-10-08 07:54:52');

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE IF NOT EXISTS `clinic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `clinic`
--


-- --------------------------------------------------------

--
-- Table structure for table `discharge`
--

CREATE TABLE IF NOT EXISTS `discharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `ward` varchar(100) NOT NULL,
  `bed` varchar(100) NOT NULL,
  `reason` text NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `discharged_by` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `discharge`
--

INSERT INTO `discharge` (`id`, `hospital_no`, `ward`, `bed`, `reason`, `date_added`, `discharged_by`, `timestamp`) VALUES
(1, 'UUTH/2010/30527', 'A&E', '1', 'Recovered Fully', '08-Oct-2010', '', '2010-10-07 18:09:59'),
(2, 'UUTH/2010/15307', 'A&E', '1', 'Fully recovered', '08-Oct-2010', 'Chukwuemeka Kalu', '2010-10-08 07:28:25'),
(3, 'UUTH/2010/23843', 'A&E', '1', '', '08-Oct-2010', 'Chukwuemeka Kalu', '2010-10-08 21:19:46'),
(4, 'UUTH/2010/23843', '', '', '', '', 'Chukwuemeka Kalu', '2010-10-08 23:30:14');

-- --------------------------------------------------------

--
-- Table structure for table `examination`
--

CREATE TABLE IF NOT EXISTS `examination` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(50) NOT NULL,
  `subjective` text NOT NULL,
  `objective` text NOT NULL,
  `assessment1` text NOT NULL,
  `ICD_code_1` varchar(100) NOT NULL,
  `assessment2` text NOT NULL,
  `ICD_code_2` varchar(100) NOT NULL,
  `date_added` varchar(50) NOT NULL,
  `admission` varchar(100) NOT NULL DEFAULT 'NO',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `examination`
--

INSERT INTO `examination` (`id`, `hospital_no`, `subjective`, `objective`, `assessment1`, `ICD_code_1`, `assessment2`, `ICD_code_2`, `date_added`, `admission`, `timestamp`) VALUES
(1, 'UUTH/2010/31124', 'Cholera', 'Cholera', 'Cholera', 'J1122(Cholera)', 'N/A', 'N/A(N/A)', '26-Sep-2010', '', '2010-09-26 07:40:42'),
(2, 'UUTH/2010/15269', 'malaria', 'malaria', 'malaria', 'j678(acute malaria)', 'N/A', 'N/A(N/A)', '26-Sep-2010', '', '2010-09-26 16:21:31'),
(3, 'UUTH/2010/32270', 'Malaria', 'Malaria', 'Acute Malaria', 'J1122(Acute Malaria)', 'N/A', 'N/A(N/A)', '05-Oct-2010', '', '2010-10-05 16:13:09'),
(4, 'UUTH/2010/30527', 'N/A', 'N/A', 'N/A', 'N/A(N/A)', 'N/A', 'N/A(N/A)', '07-Oct-2010', 'DISCHARGED', '2010-10-07 17:18:54'),
(5, 'UUTH/2010/15210', 'Malaria', 'Acute Malaria', 'Acute Malaria', 'J1122(12991)', 'N/A', 'N/A(N/A)', '07-Oct-2010', '', '2010-10-07 18:23:08'),
(6, 'UUTH/2010/27364', 'Colds, fever, coughing', 'Malaria', 'Acute Malaria', 'J1122(yy3332)', 'N/A', 'N/A(N/A)', '07-Oct-2010', '', '2010-10-07 20:01:42'),
(7, 'UUTH/2010/15307', 'N/A', 'N/A', 'N/A', 'N/A(N/A)', 'N/A', 'N/A(N/A)', '08-Oct-2010', 'DISCHARGED', '2010-10-08 05:33:40'),
(8, 'UUTH/2010/23843', 'N/A', 'N/A', 'N/A', 'N/A(N/A)', 'N/A', 'N/A(N/A)', '08-Oct-2010', 'DISCHARGED', '2010-10-08 07:53:58'),
(9, 'UUTH/2010/20774', 'Fever, colds', 'Chest HN1;\r\n', 'Malaria', 'J2120(Acute Malaria)', 'N/A', 'N/A(N/A)', '08-Oct-2010', '', '2010-10-08 11:45:44');

-- --------------------------------------------------------

--
-- Table structure for table `expenditure`
--

CREATE TABLE IF NOT EXISTS `expenditure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` varchar(100) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `expenditure`
--

INSERT INTO `expenditure` (`id`, `item`, `cost`, `date`, `timestamp`) VALUES
(1, 'Stationary', '12000', '07-Oct-2010', '2010-10-07 11:54:45');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE IF NOT EXISTS `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `invoice`
--


-- --------------------------------------------------------

--
-- Table structure for table `labs`
--

CREATE TABLE IF NOT EXISTS `labs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `labs`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=113 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user_id`, `name`, `time`) VALUES
(1, 'Records', 'Paulina Etim', '2010-10-08 11:14:08'),
(2, 'CMD', 'Okon Akpan', '2010-10-08 11:14:29'),
(3, 'CMAC', 'Okon Bassey', '2010-10-08 11:18:11'),
(4, 'Dir. of Nursing', 'Uduak Silas', '2010-10-08 11:26:18'),
(5, 'Clinic Nurse', 'Theresa Abang', '2010-10-08 11:28:56'),
(6, 'Dir. of Nursing', 'Uduak Silas', '2010-10-08 11:29:25'),
(7, 'Ward Nurse', 'Essien Udoete', '2010-10-08 11:30:46'),
(8, 'Dir. of Nursing', 'Uduak Silas', '2010-10-08 11:31:33'),
(9, 'Records', 'Paulina Etim', '2010-10-08 11:37:15'),
(10, 'Clinic Nurse', 'Theresa Abang', '2010-10-08 11:39:46'),
(11, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-08 11:42:48'),
(12, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-08 11:47:31'),
(13, 'Accounts', 'Victor Essien', '2010-10-08 11:49:50'),
(14, 'Laboratory Staff', 'Rebecca Utakwu', '2010-10-08 11:52:28'),
(15, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-08 11:56:14'),
(16, 'Accounts', 'Victor Essien', '2010-10-08 11:58:03'),
(17, 'Pharmacist', 'Mercy Johnson', '2010-10-08 11:59:31'),
(18, 'Accounts', 'Victor Essien', '2010-10-08 12:01:18'),
(19, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-08 12:03:42'),
(20, 'CMD', 'Okon Akpan', '2010-10-08 12:06:16'),
(21, 'CMD', 'Okon Akpan', '2010-10-08 14:23:57'),
(22, 'CMD', 'Okon Akpan', '2010-10-08 20:51:21'),
(23, 'Accounts', 'Victor Essien', '2010-10-08 21:09:44'),
(24, 'Ward Nurse', 'Essien Udoete', '2010-10-08 21:18:52'),
(25, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-08 21:19:37'),
(26, 'Ward Nurse', 'Essien Udoete', '2010-10-08 21:20:00'),
(27, 'Accounts', 'Victor Essien', '2010-10-08 21:26:56'),
(28, 'Ward Nurse', 'Essien Udoete', '2010-10-08 21:28:17'),
(29, 'Records', 'Paulina Etim', '2010-10-08 21:39:05'),
(30, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-08 22:50:49'),
(31, 'Accounts', 'Victor Essien', '2010-10-08 22:56:52'),
(32, 'Ward Nurse', 'Essien Udoete', '2010-10-08 23:21:13'),
(33, 'Ward Nurse', 'Essien Udoete', '2010-10-08 23:24:04'),
(34, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-08 23:29:57'),
(35, 'CMD', 'Okon Akpan', '2010-10-09 10:17:54'),
(36, 'Records', 'Chris Inyang', '2010-10-09 10:23:05'),
(37, 'CMD', 'Okon Akpan', '2010-10-09 10:23:22'),
(38, 'CMD', 'Okon Akpan', '2010-10-09 11:57:32'),
(39, 'Dir. of Pharmacy', 'Priscillia Effiong', '2010-10-09 12:02:18'),
(40, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-09 12:04:31'),
(41, 'Ward Nurse', 'Essien Udoete', '2010-10-09 12:09:04'),
(42, 'CMD', 'Okon Akpan', '2010-10-09 23:20:35'),
(43, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-10 10:45:30'),
(44, 'CMD', 'Okon Akpan', '2010-10-10 22:38:45'),
(45, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-10 22:39:00'),
(46, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-14 11:17:14'),
(47, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-14 23:56:40'),
(48, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 00:01:06'),
(49, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 00:01:52'),
(50, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 00:19:38'),
(51, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 00:44:12'),
(52, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 13:07:10'),
(53, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 13:20:41'),
(54, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 13:30:28'),
(55, 'Records', 'Paulina Etim', '2010-10-15 15:21:31'),
(56, 'Clinic Nurse', 'Theresa Abang', '2010-10-15 15:24:04'),
(57, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 15:24:33'),
(58, 'Accounts', 'Victor Essien', '2010-10-15 15:25:28'),
(59, 'Laboratory Staff', 'Rebecca Utakwu', '2010-10-15 15:25:48'),
(60, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 15:26:23'),
(61, 'Pharmacist', 'Mercy Johnson', '2010-10-15 15:26:56'),
(62, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 19:37:02'),
(63, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 20:28:36'),
(64, 'Laboratory Staff', 'Rebecca Utakwu', '2010-10-15 21:09:40'),
(65, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-15 21:10:37'),
(66, 'Laboratory Staff', 'Rebecca Utakwu', '2010-10-15 21:13:55'),
(67, 'Records', 'Paulina Etim', '2010-10-16 13:27:53'),
(68, 'Clinic Nurse', 'Theresa Abang', '2010-10-16 13:28:35'),
(69, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-16 13:28:58'),
(70, 'Laboratory Staff', 'Rebecca Utakwu', '2010-10-16 13:30:25'),
(71, 'Pharmacist', 'Mercy Johnson', '2010-10-16 13:30:48'),
(72, 'Ward Nurse', 'Essien Udoete', '2010-10-16 13:31:18'),
(73, 'Accounts', 'Victor Essien', '2010-10-16 13:32:02'),
(74, 'CMD', 'Okon Akpan', '2010-10-16 13:32:46'),
(75, 'CMAC', 'Okon Bassey', '2010-10-16 13:34:10'),
(76, 'Dir. of Nursing', 'Uduak Silas', '2010-10-16 13:35:19'),
(77, 'Chief Accountant', 'Etim Asuquo', '2010-10-16 13:35:55'),
(78, 'Dir. of Pharmacy', 'Priscillia Effiong', '2010-10-16 13:36:31'),
(79, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-16 13:37:32'),
(80, 'CMD', 'Okon Akpan', '2010-10-16 16:41:25'),
(81, 'Medical Consultant', 'Chukwuemeka Kalu', '2010-10-16 20:18:34'),
(82, 'CMD', 'Okon Akpan', '2010-10-16 20:20:49'),
(83, 'CMD', 'Okon Akpan', '2010-10-18 20:48:13'),
(84, 'Accounts', 'Victor Essien', '2011-01-22 11:49:20'),
(85, 'Laboratory Staff', 'Rebecca Utakwu', '2011-01-22 12:03:58'),
(86, 'Laboratory Staff', 'Rebecca Utakwu', '2011-01-25 06:17:50'),
(87, 'Laboratory Staff', 'Rebecca Utakwu', '2011-01-26 05:20:25'),
(88, 'Accounts', 'Victor Essien', '2011-01-26 06:17:32'),
(89, 'Accounts', 'Victor Essien', '2011-01-26 06:18:39'),
(90, 'Accounts', 'Victor Essien', '2011-01-26 06:19:57'),
(91, 'Accounts', 'Victor Essien', '2011-01-26 06:24:39'),
(92, 'Chief Accountant', 'Etim Asuquo', '2011-01-26 06:54:23'),
(93, 'CMAC', 'Okon Bassey', '2011-01-26 15:49:16'),
(94, 'CMD', 'Okon Akpan', '2011-01-26 16:19:52'),
(95, 'Laboratory Staff', 'Rebecca Utakwu', '2011-01-26 16:46:12'),
(96, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-01-27 22:59:21'),
(97, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-01-27 22:59:39'),
(98, 'Clinic Nurse', 'Theresa Abang', '2011-01-27 23:34:11'),
(99, 'Pharmacist', 'Mercy Johnson', '2011-01-27 23:51:24'),
(100, 'Records', 'Paulina Etim', '2011-01-28 00:03:41'),
(101, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-01-28 12:56:53'),
(102, 'CMD', 'Okon Akpan', '2011-01-28 12:59:58'),
(103, 'Records', 'Paulina Etim', '2011-01-28 13:00:30'),
(104, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-03-27 19:32:46'),
(105, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-03-27 19:34:31'),
(106, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-03-27 19:41:44'),
(107, 'CMD', 'Okon Akpan', '2011-03-27 19:45:20'),
(108, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-03-27 19:47:53'),
(109, 'CMD', 'Okon Akpan', '2011-03-27 19:49:51'),
(110, 'CMAC', 'Okon Bassey', '2011-03-27 19:53:35'),
(111, 'CMAC', 'Okon Bassey', '2011-03-27 19:54:46'),
(112, 'Medical Consultant', 'Chukwuemeka Kalu', '2011-03-27 19:59:07');

-- --------------------------------------------------------

--
-- Table structure for table `old_patient`
--

CREATE TABLE IF NOT EXISTS `old_patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(30) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `medical_personnel` varchar(100) NOT NULL,
  `amount_paid` varchar(50) NOT NULL,
  `visit_status` varchar(50) NOT NULL,
  `reg_point` varchar(50) NOT NULL,
  `payment_purpose` varchar(100) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `old_patient`
--

INSERT INTO `old_patient` (`id`, `hospital_no`, `purpose`, `medical_personnel`, `amount_paid`, `visit_status`, `reg_point`, `payment_purpose`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/6416', 'Consultation', 'Medical Consultant', 'N 450', 'Not Attended to', 'Registration Point 1', 'Registration Fee, Technology Fee', '19-Sep-2010', '2010-09-19 08:32:36'),
(2, 'UUTH/2010/31124', 'Check-up', 'Medical Consultant', 'N 450', 'Not Attended to', 'Registration Point 1', 'Registration Fee, Technology Fee', '26-Sep-2010', '2010-09-26 15:04:44');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `date_of_birth` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `ministry` varchar(100) NOT NULL,
  `next_of_kin` varchar(100) NOT NULL,
  `next_of_kin_address` text NOT NULL,
  `next_of_kin_phone` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `amount_paid` varchar(20) NOT NULL,
  `hospital_no` varchar(20) NOT NULL,
  `reg_point` varchar(30) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `medical_personnel` varchar(100) NOT NULL,
  `payment_purpose` varchar(100) NOT NULL,
  `date_added` varchar(50) NOT NULL,
  `doctor_incharge` varchar(100) NOT NULL,
  `admission` varchar(100) NOT NULL DEFAULT 'NO',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `title`, `fname`, `lname`, `date_of_birth`, `sex`, `occupation`, `ministry`, `next_of_kin`, `next_of_kin_address`, `next_of_kin_phone`, `status`, `amount_paid`, `hospital_no`, `reg_point`, `purpose`, `phone`, `email`, `address`, `medical_personnel`, `payment_purpose`, `date_added`, `doctor_incharge`, `admission`, `timestamp`) VALUES
(1, '', ' Barak', ' Bassey', '1-Jan-1976', 'Male', 'Civil Servant', '', 'John Bassey', '', '', 'Not Attended to', 'N 200', 'UUTH/2010/31124', '', 'Consultation', '+2348039450998', 'aceheart2010@yahoo.com', 'Marian', 'Medical Consultant', '', 'Sun-Sep-2010', '', 'NO', '2010-09-19 07:17:19'),
(2, '', 'Nkoyo', 'Otu', '1-Jan-1980', 'Male', 'Civil Servant', '', 'John Otu', '', '', 'Not Attended to', 'N 200', 'UUTH/2010/6416', '', 'Consultation', '08039098042', 'aceheart2010@yahoo.com', 'Marian', 'Medical Consultant', 'Registration fee, Technology fee', 'Sun-Sep-2010', '', 'NO', '2010-09-19 07:23:47'),
(3, '', 'Prisca', 'Bassey', '1-Jan-1987', 'Female', 'Civil Servant', '', 'John Bassey', '', '', 'Not Attended to', 'N 200', 'UUTH/2010/15369', 'Registration Point 1', 'Consultation', '08039098042', 'busaosowo@yahoo.com', 'Marian', 'Medical Consultant', 'Registration fee, Technology fee', 'Sun-Sep-2010', '', 'NO', '2010-09-19 07:26:21'),
(4, '', 'Atim', 'Asuquo', '1-Jan-1990', 'Female', 'Civil Servant', '', 'John Asuquo', '', '', 'Not Attended to', 'N 200', 'UUTH/2010/32270', 'Registration Point 1', 'Consultation', '08039098042', 'busaosowo@yahoo.com', 'Marian', 'Medical Consultant', 'Registration fee, Technology fee', '19-Sep-2010', '', 'NO', '2010-09-19 07:29:29'),
(5, '', 'justina', 'moses', '1-Jan-1979', 'Female', 'Civil Servant', '', 'John Bassey', '', '', 'Not Attended to', 'N 200', 'UUTH/2010/13884', 'Registration Point 1', 'Consultation', '091218989', 'eremirasine@yahoo.com', 'Marian', 'Medical Consultant', ', Technology Fee', '19-Sep-2010', '', 'NO', '2010-09-19 08:09:43'),
(6, '', 'Salim', 'Mohammed', '1-Jan-1980', 'Male', 'Civil Servant', '', 'Kadiri Mohammed', '', '', 'Not Attended to', '', 'UUTH/2010/15269', 'Registration Point 1', 'Consultation', '08074164001', 'beckytakss@yahoo.com', 'cali', 'Medical Consultant', 'Registration Fee, Technology Fee', '26-Sep-2010', '', 'NO', '2010-09-26 15:20:43'),
(7, 'Hon.', 'Naomi', ' Bassey', '1-Jan-2010', 'Male', 'Civil Servant', 'Works', 'John Bassey', '08039098042', 'Home', 'Not Attended to', '', 'UUTH/2010/1886', 'Registration Point 1', 'Consultation', '+2348039450998', '08034176962', 'Home', 'Medical Consultant', 'Registration Fee, Technology Fee', '07-Oct-2010', '', 'NO', '2010-10-07 16:58:55'),
(8, 'Hon.', 'Akan', ' Bassey', '1-Jan-2010', 'Male', 'Civil Servant', 'Works', 'John Asuquo', '08039098042', 'Home', 'Not Attended to', '', 'UUTH/2010/30527', 'Registration Point 1', 'Consultation', '+2348039450998', '08034176962', 'Home', 'Medical Consultant', 'Registration Fee, Technology Fee', '07-Oct-2010', '', 'DISCHARGED', '2010-10-07 17:00:36'),
(10, 'Chief', 'Bassey', 'Okon', '1-Jan-2010', 'Male', 'Self-employed', '', 'Bassey Bassey', '08039098042', 'Marian', 'Not Attended to', 'N 450', 'UUTH/2010/15210', 'Registration Point 1', 'Consultation', '+2348039450998', 'busaosowo@yahoo.com', 'Marian', 'Medical Consultant', 'Registration Fee, Technology Fee', '07-Oct-2010', '', 'NO', '2010-10-07 18:17:27'),
(11, 'Chief', 'Moses', 'Akpan', '1-Jan-2010', 'Male', 'Civil Servant', 'Works', 'John Otu', '08039098042', 'Marian', 'Not Attended to', 'N 450', 'UUTH/2010/27364', 'Registration Point 1', 'Consultation', '+2348039450998', 'aceheart2010@yahoo.com', 'Marian road', 'Medical Consultant', 'Registration Fee, Technology Fee', '07-Oct-2010', '', 'NO', '2010-10-07 19:55:39'),
(12, 'Hon.', 'Akan', 'Bassey', '1-Jan-2010', 'Female', 'Civil Servant', 'Works', 'Bassey Bassey', '08039098042', 'Home', 'Not Attended to', 'N 450', 'UUTH/2010/15307', 'Registration Point 1', 'Check-up', '+2348039450998', 'aceheart2010@yahoo.com', 'Home', 'Medical Consultant', 'Registration Fee, Technology Fee', '08-Oct-2010', 'Chukwuemeka Kalu', 'DISCHARGED', '2010-10-08 05:21:01'),
(13, 'Hon.', 'Moses', 'Otu', '1-Jan-2010', 'Male', 'Civil Servant', 'Works', 'Bassey Bassey', '08039098042', 'Home', 'Not Attended to', 'N 450', 'UUTH/2010/23843', 'Registration Point 1', 'Consultation', '+2348039450998', '08034176962', 'Home', 'Medical Consultant', 'Registration Fee, Technology Fee', '08-Oct-2010', 'Chukwuemeka Kalu', 'DISCHARGED', '2010-10-08 07:51:57'),
(14, 'Hon.', 'test', 'test', '1-Jan-2010', 'Male', 'Civil Servant', 'test', 'test', 'test', 'test', 'Not Attended to', 'N 200', 'UUTH/2010/13726', 'Registration Point 1', 'Consultation', 'test', 'test', 'test', 'Medical Consultant', 'Registration Fee, Technology Fee', '08-Oct-2010', '', 'NO', '2010-10-08 08:05:53'),
(15, 'Hon.', 'Becky', 'Adie', '1-Jan-2010', 'Male', 'Civil Servant', 'Works', 'test', '08039098042', 'test', 'Not Attended to', '450', 'UUTH/2010/20774', 'Registration Point 1', 'Consultation', '08074164001', 'beckytakss@yahoo.com', 'Home', 'Medical Consultant', 'Registration Fee, Technology Fee', '08-Oct-2010', '', 'NO', '2010-10-08 11:38:54'),
(16, 'Hon.', 'xyz', 'xyz', '1-Jan-2011', 'Male', 'Civil Servant', 'Civil', 'xyz', '123', 'xyz', 'Not Attended to', '200', '', 'Registration Point 1', 'Consultation', '080390888080', 'pop@yahoo.com', '59', '', 'Registration Fee, Technology Fee', '28-Jan-2011', '', 'NO', '2011-01-28 13:04:01');

-- --------------------------------------------------------

--
-- Table structure for table `patient_report`
--

CREATE TABLE IF NOT EXISTS `patient_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(50) NOT NULL,
  `activity` text NOT NULL,
  `consultant` varchar(50) NOT NULL,
  `sleep` text NOT NULL,
  `admission_date` varchar(100) NOT NULL,
  `communication` text NOT NULL,
  `nutrition` text NOT NULL,
  `family` text NOT NULL,
  `elimination` text NOT NULL,
  `problems` text NOT NULL,
  `temperature` varchar(30) NOT NULL,
  `palpation` text NOT NULL,
  `pulse` varchar(30) NOT NULL,
  `percussion` text NOT NULL,
  `respiration` varchar(10) NOT NULL,
  `auscultation` text NOT NULL,
  `blood_pressure` varchar(10) NOT NULL,
  `general_summary` text NOT NULL,
  `apex_beat` varchar(10) NOT NULL,
  `ward` varchar(20) NOT NULL,
  `date_added` varchar(50) NOT NULL,
  `death` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `patient_report`
--

INSERT INTO `patient_report` (`id`, `hospital_no`, `activity`, `consultant`, `sleep`, `admission_date`, `communication`, `nutrition`, `family`, `elimination`, `problems`, `temperature`, `palpation`, `pulse`, `percussion`, `respiration`, `auscultation`, `blood_pressure`, `general_summary`, `apex_beat`, `ward`, `date_added`, `death`, `timestamp`) VALUES
(1, 'UUTH/2010/31124', 'None', 'Dr Bassey', 'None', '', 'None', 'None', 'None', 'None', 'None', '12', 'None', '12', 'None', '32', 'None', '3', 'None', '3', 'A&E', '21-Sep-2010', '', '2010-09-21 23:01:26'),
(2, 'UUTH/2010/23843', 'Hey', 'Chukwuemeka Kalu', 'Hey', '1-Jan-2010', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'Hey', 'A&E', '08-Oct-2010', '', '2010-10-08 23:26:12');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE IF NOT EXISTS `pharmacy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `quantity` int(20) NOT NULL,
  `used` int(20) NOT NULL,
  `balance` int(20) NOT NULL,
  `unit_price` int(20) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`id`, `code`, `name`, `quantity`, `used`, `balance`, `unit_price`, `timestamp`) VALUES
(1, 'MED/100', 'Panadol', 1000, 0, 726, 5, '2010-09-26 09:34:56'),
(2, 'MED/102', 'Quinine', 2000, 0, 985, 5, '2010-09-26 09:34:56'),
(3, 'MED/104', 'Flagyl', 10000, 0, 915, 5, '2010-09-26 09:38:38'),
(4, 'MED/106', 'Amplicox', 3000, 0, 985, 5, '2010-09-26 09:38:38'),
(5, 'MED/108', 'Antacid', 1500, 0, 985, 5, '2010-09-26 09:38:38'),
(6, 'MED/110', 'Gellusil', 3000, 0, 985, 10, '2010-09-26 09:38:38'),
(7, 'MED/112', 'Phenolin', 6000, 0, 425, 8, '2010-09-26 09:38:38'),
(8, 'MED/114', 'Lonart', 1000, 0, 865, 2, '2010-09-26 09:38:38');

-- --------------------------------------------------------

--
-- Table structure for table `prescribtion`
--

CREATE TABLE IF NOT EXISTS `prescribtion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `prescribtion_no` varchar(100) NOT NULL,
  `repeat` varchar(100) NOT NULL DEFAULT 'NO',
  `doctor` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'NOT DISPENSED',
  `number` varchar(100) NOT NULL,
  `financial_status` varchar(100) NOT NULL DEFAULT 'NOT CLEARED',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `prescribtion`
--

INSERT INTO `prescribtion` (`id`, `hospital_no`, `date_added`, `prescribtion_no`, `repeat`, `doctor`, `status`, `number`, `financial_status`) VALUES
(2, 'UUTH/2010/15269', '05-Oct-2010', 'UUTH/PRES/1548', '', 'Pharmacist', 'DISPENSED', '2', 'CLEARED'),
(3, 'UUTH/2010/32270', '05-Oct-2010', 'UUTH/PRES/27102', '', 'Medical Consultant', 'NOT DISPENSED', '2', 'CLEARED'),
(4, 'UUTH/2010/15210', '07-Oct-2010', 'UUTH/PRES/14584', '', 'Medical Consultant', 'DISPENSED', '2', 'CLEARED'),
(5, 'UUTH/2010/27364', '07-Oct-2010', 'UUTH/PRES/8353', '', 'Medical Consultant', 'DISPENSED', '2', 'CLEARED'),
(6, 'UUTH/2010/15307', '08-Oct-2010', 'UUTH/PRES/1618', '', 'Medical Consultant', 'DISPENSED', '1', 'CLEARED'),
(7, 'UUTH/2010/23843', '08-Oct-2010', 'UUTH/PRES/16555', '', 'Medical Consultant', 'NOT DISPENSED', '1', 'CLEARED'),
(8, 'UUTH/2010/20774', '08-Oct-2010', 'UUTH/PRES/15124', '', 'Medical Consultant', 'DISPENSED', '2', 'CLEARED'),
(9, 'UUTH/2010/23843', '08-Oct-2010', 'UUTH/PRES/32322', '', 'Medical Consultant', 'NOT DISPENSED', '4', 'CLEARED');

-- --------------------------------------------------------

--
-- Table structure for table `prescribtions`
--

CREATE TABLE IF NOT EXISTS `prescribtions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prescribtion` varchar(100) NOT NULL,
  `hospital_no` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `dosage` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `prescribtions`
--

INSERT INTO `prescribtions` (`id`, `prescribtion`, `hospital_no`, `price`, `quantity`, `dosage`, `status`, `timestamp`) VALUES
(1, 'MED/100', 'UUTH/2010/15269', '75', '', '15: 3 X 1', 'ISSUED', '0000-00-00 00:00:00'),
(2, 'MED/112', 'UUTH/2010/15269', '640', '', '80: 4 X 5', 'ISSUED', '0000-00-00 00:00:00'),
(3, 'MED/104', 'UUTH/2010/32270', '250', '', '50: 3 X 15', 'ISSUED', '2010-10-05 16:31:00'),
(4, 'MED/114', 'UUTH/2010/32270', '40', '', '20: 3 X 4', 'ISSUED', '2010-10-05 16:31:00'),
(5, 'MED/100', 'UUTH/2010/15210', '250', '', '50: 3 X 4', 'ISSUED', '2010-10-07 18:29:42'),
(6, 'MED/114', 'UUTH/2010/15210', '60', '', '30: 5 X 6', 'ISSUED', '2010-10-07 18:29:43'),
(7, 'MED/100', 'UUTH/2010/27364', '100', '', '20: 5 X 4', 'ISSUED', '2010-10-07 20:09:55'),
(8, 'MED/114', 'UUTH/2010/27364', '40', '', '20: 5 X 4', 'ISSUED', '2010-10-07 20:09:55'),
(9, 'MED/100', 'UUTH/2010/15307', '20', '', '4: 3 X 1', 'ISSUED', '2010-10-08 07:39:55'),
(10, 'MED/100', 'UUTH/2010/23843', '50', '', '10: 3 X 4', '', '2010-10-08 09:35:34'),
(11, 'MED/100', 'UUTH/2010/20774', '100', '', '20: 4 X 5', 'ISSUED', '2010-10-08 11:57:46'),
(12, 'MED/114', 'UUTH/2010/20774', '60', '', '30: 5 X 6', 'ISSUED', '2010-10-08 11:57:46'),
(13, 'Panadol', 'UUTH/2010/23843', '100', '20', '20: 4 X 5', '', '2010-10-08 22:54:01'),
(14, 'Lonart', 'UUTH/2010/23843', '40', '20', '20: 4 X 5', '', '2010-10-08 22:54:01'),
(15, 'Flagyl', 'UUTH/2010/23843', '100', '20', '20: 4 X 5', '', '2010-10-08 22:54:01');

-- --------------------------------------------------------

--
-- Table structure for table `procedure`
--

CREATE TABLE IF NOT EXISTS `procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `procedure` varchar(100) NOT NULL,
  `hospital_no` varchar(50) NOT NULL,
  `cost` varchar(20) NOT NULL,
  `instruction` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `procedure`
--

INSERT INTO `procedure` (`id`, `procedure`, `hospital_no`, `cost`, `instruction`) VALUES
(1, 'Arachidonic acid', 'UUTH/2010/15269', '500', ''),
(2, 'Ferritin', 'UUTH/2010/15269', '500', ''),
(3, 'G6PD', 'UUTH/2010/15269', '500', ''),
(4, 'Spirometry', 'UUTH/2010/15269', '', ''),
(5, 'Bronchoscopy', 'UUTH/2010/15269', '500', ''),
(6, 'Ultrascan', 'UUTH/2010/15269', '1500', ''),
(7, 'X-RAY', 'UUTH/2010/15269', '1500', ''),
(8, 'Hematocrit', 'UUTH/2010/31124', '500', ''),
(9, 'Fibrinogen', 'UUTH/2010/31124', '500', ''),
(10, 'Coombs Test Direct', 'UUTH/2010/31124', '500', ''),
(11, 'Blood Viscocity', 'UUTH/2010/31124', '500', ''),
(12, 'Ultrascan', 'UUTH/2010/31124', '1500', ''),
(13, 'White Blood Cell', 'UUTH/2010/32270', '500', ''),
(14, 'Blood Viscocity', 'UUTH/2010/32270', '500', ''),
(26, 'Complete Blood Test', 'UUTH/2010/15210', '500', ''),
(27, 'X-RAY', 'UUTH/2010/15210', '1500', 'Complete x-ray'),
(28, 'Complete Blood Test', 'UUTH/2010/27364', '500', ''),
(29, 'X-RAY', 'UUTH/2010/27364', '1500', 'Complete, chest'),
(30, 'Complete Blood Test', 'UUTH/2010/15307', '500', ''),
(31, 'G6PD', 'UUTH/2010/15307', '500', ''),
(32, 'Plasma Viscocity', 'UUTH/2010/23843', '500', ''),
(33, 'Ferritin', 'UUTH/2010/23843', '500', ''),
(34, 'G6PD', 'UUTH/2010/23843', '500', ''),
(35, 'Spirometry', 'UUTH/2010/23843', '', ''),
(36, 'X-RAY', 'UUTH/2010/23843', '1500', ''),
(37, 'Complete Blood Test', 'UUTH/2010/20774', '500', ''),
(38, 'X-RAY', 'UUTH/2010/20774', '1500', ''),
(39, 'White Blood Cell', 'UUTH/2010/15269', '500', ''),
(40, 'TIBC', 'UUTH/2010/15269', '500', '');

-- --------------------------------------------------------

--
-- Table structure for table `procedures`
--

CREATE TABLE IF NOT EXISTS `procedures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(50) NOT NULL,
  `date` varchar(100) NOT NULL,
  `section/service` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `repeat` varchar(20) NOT NULL DEFAULT 'NO',
  `purpose` varchar(100) NOT NULL,
  `requested_by` varchar(100) NOT NULL,
  `doctor/staff` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `financial_status` varchar(100) NOT NULL DEFAULT 'NOT CLEARED',
  `schedule` varchar(100) NOT NULL DEFAULT 'NOT SCHEDULED',
  `schedule_date` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `procedures`
--

INSERT INTO `procedures` (`id`, `hospital_no`, `date`, `section/service`, `number`, `repeat`, `purpose`, `requested_by`, `doctor/staff`, `status`, `financial_status`, `schedule`, `schedule_date`, `timestamp`) VALUES
(1, 'UUTH/2010/15269', '27-Mar-2011', 'Laboratory', '9', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'WAITING', 'NOT CLEARED', '4-Oct-2010 at 9:00am', '4-Oct-2010', '2010-10-02 10:51:32'),
(2, 'UUTH/2010/31124', '05-Oct-2010', 'Laboratory', '5', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'WAITING', 'NOT CLEARED', 'NOT YET SCHEDULED', '', '2010-10-05 12:42:54'),
(3, 'UUTH/2010/31124', '05-Oct-2010', 'Laboratory', '5', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'WAITING', 'NOT CLEARED', 'NOT YET SCHEDULED', '', '2010-10-05 13:23:26'),
(4, 'UUTH/2010/32270', '05-Oct-2010', 'Laboratory', '2', 'YES', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'PATIENT TESTED', 'NOT CLEARED', '6-Oct-2010 at 4:30pm', '6-Oct-2010', '2010-10-05 16:15:18'),
(11, 'UUTH/2010/15210', '07-Oct-2010', 'Laboratory', '2', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'PATIENT TESTED', 'CLEARED', '7-Oct-2010 at 7:00pm', '7-Oct-2010', '2010-10-07 18:23:59'),
(12, 'UUTH/2010/27364', '07-Oct-2010', 'Laboratory', '2', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'PATIENT TESTED', 'CLEARED', 'NOT YET SCHEDULED', '', '2010-10-07 20:02:20'),
(13, 'UUTH/2010/15307', '08-Oct-2010', 'Laboratory', '2', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'WAITING', 'CLEARED', 'NOT YET SCHEDULED', '', '2010-10-08 05:37:04'),
(14, 'UUTH/2010/23843', '08-Oct-2010', 'Laboratory', '5', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'WAITING', 'CLEARED', 'NOT YET SCHEDULED', '', '2010-10-08 09:34:53'),
(15, 'UUTH/2010/20774', '08-Oct-2010', 'Laboratory', '2', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'PATIENT TESTED', 'CLEARED', 'NOT YET SCHEDULED', '', '2010-10-08 11:48:15'),
(16, 'UUTH/2010/15269', '27-Mar-2011', 'Laboratory', '9', '', 'Lab Check', 'Medical Consultant', 'Laboratory Staff', 'WAITING', 'NOT CLEARED', 'NOT YET SCHEDULED', '', '2011-03-27 19:39:58');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE IF NOT EXISTS `receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `hospital_no` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `items` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`id`, `code`, `hospital_no`, `total`, `date`, `items`, `timestamp`) VALUES
(1, '30167', 'UUTH/2010/15269', '3100', '06-Oct-2010', 'Panadol<br>X-ray<br>Ultrascan<br>', '2010-10-06 17:06:46'),
(2, '24260', 'UUTH/2010/15269', '3100', '06-Oct-2010', 'Panadol<br>X-ray<br>Ultrascan<br>', '2010-10-06 17:11:23'),
(3, '465', 'UUTH/2010/15210', '2310', '07-Oct-2010', 'Complete Blood Test<br>X-RAY<br>MED/100<br>MED/114<br>', '2010-10-07 18:32:27'),
(4, '8902', 'UUTH/2010/27364', '2140', '07-Oct-2010', 'Complete Blood Test<br>X-RAY<br>MED/100<br>MED/114<br>', '2010-10-07 20:13:07'),
(5, '28605', 'UUTH/2010/20774', '2610', '08-Oct-2010', 'REGISTRATION FEE<br>Complete Blood Test<br>X-RAY<br>MED/100<br>MED/114<br>', '2010-10-08 12:01:42'),
(6, '3667', 'UUTH/2010/23843', '4690', '08-Oct-2010', 'REGISTRATION FEE<br>REGISTRATION FEE<br>Plasma Viscocity<br>Ferritin<br>G6PD<br>Spirometry<br>X-RAY<br>MED/100<br>Panadol<br>Lonart<br>Flagyl<br>', '2010-10-08 22:57:06');

-- --------------------------------------------------------

--
-- Table structure for table `referred_patient`
--

CREATE TABLE IF NOT EXISTS `referred_patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `next_of_kin` varchar(100) NOT NULL,
  `visit_status` varchar(50) NOT NULL,
  `referral_hospital` varchar(100) NOT NULL,
  `amount_paid` varchar(30) NOT NULL,
  `hospital_no` varchar(30) NOT NULL,
  `reg_point` varchar(100) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `medical_personnel` varchar(30) NOT NULL,
  `referral_id` varchar(30) NOT NULL,
  `payment_purpose` varchar(50) NOT NULL,
  `date_added` varchar(29) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `referred_patient`
--

INSERT INTO `referred_patient` (`id`, `fname`, `lname`, `date_of_birth`, `sex`, `occupation`, `next_of_kin`, `visit_status`, `referral_hospital`, `amount_paid`, `hospital_no`, `reg_point`, `purpose`, `phone`, `email`, `address`, `medical_personnel`, `referral_id`, `payment_purpose`, `date_added`, `timestamp`) VALUES
(1, 'Atim', 'Akpan', '1-Jan-1979', 'Male', 'Civil Servant', 'John Asuquo', 'Not Attended to', 'UCTH', 'N 200', 'REF/UUTH/2010/32429', 'Registration Point 1', 'Consultation', '08039098042', 'eremirasine@yahoo.com', 'Marian', 'Medical Consultant', '', 'Registration Fee, Technology Fee', '19-Sep-2010', '2010-09-19 09:48:57');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ward` varchar(50) NOT NULL,
  `deaths` varchar(50) NOT NULL,
  `nurses` varchar(50) NOT NULL,
  `general_summary` text NOT NULL,
  `critical_cases` varchar(50) NOT NULL,
  `referrals` varchar(50) NOT NULL,
  `discharges` varchar(50) NOT NULL,
  `admissions` varchar(50) NOT NULL,
  `births` varchar(50) NOT NULL,
  `recommendations` text NOT NULL,
  `problems` text NOT NULL,
  `date_added` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `ward`, `deaths`, `nurses`, `general_summary`, `critical_cases`, `referrals`, `discharges`, `admissions`, `births`, `recommendations`, `problems`, `date_added`, `timestamp`) VALUES
(1, 'A&E', '5', '6', 'Fine day.', '1', '1', '2', '3', '', 'None', 'None', '21-Sep-2010', '2010-09-21 21:59:39');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE IF NOT EXISTS `results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `procedure` varchar(100) NOT NULL,
  `result` text NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `hospital_no`, `procedure`, `result`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/15269', 'Arachidonic acid', 'Positive', '04-Oct-2010', '2010-10-04 14:52:16'),
(2, 'UUTH/2010/32270', 'White Blood Cell', 'Positive', '05-Oct-2010', '2010-10-05 16:27:05'),
(3, 'UUTH/2010/32270', 'Blood Viscocity', 'Positive', '05-Oct-2010', '2010-10-05 16:27:05'),
(4, 'UUTH/2010/15210', 'Complete Blood Test', 'Positive', '07-Oct-2010', '2010-10-07 18:28:16'),
(5, 'UUTH/2010/15210', 'X-RAY', 'Positive', '07-Oct-2010', '2010-10-07 18:28:16'),
(6, 'UUTH/2010/27364', 'Complete Blood Test', 'Positive', '07-Oct-2010', '2010-10-07 20:07:17'),
(7, 'UUTH/2010/27364', 'X-RAY', 'Positive', '07-Oct-2010', '2010-10-07 20:07:17'),
(8, 'UUTH/2010/20774', 'Complete Blood Test', 'Positive', '08-Oct-2010', '2010-10-08 11:55:12'),
(9, 'UUTH/2010/20774', 'X-RAY', 'Positive', '08-Oct-2010', '2010-10-08 11:55:12');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(50) NOT NULL,
  `reference` varchar(50) NOT NULL,
  `service` varchar(50) NOT NULL,
  `schedule` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `medical_personnel` varchar(50) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Waiting',
  `date_added` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `hospital_no`, `reference`, `service`, `schedule`, `date`, `medical_personnel`, `purpose`, `status`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/31124', 'Non-referenced Patient', 'General Practice', '1-Jan-2010 at 08:00am', '1-Jan-2010', 'Medical Consultant', 'Consultation', 'Waiting', '22-Sep-2010', '2010-09-22 22:18:19'),
(2, 'UUTH/2010/15269', 'Non-referenced Patient', 'General Practice', '26-Sep-2010 at 9:00am', '26-Sep-2010', 'Medical Consultant', 'General examination', 'Waiting', '26-Sep-2010', '2010-09-26 16:18:06'),
(3, 'UUTH/2010/32270', 'Non-referenced Patient', 'General Practice', '6-Oct-2010 at 4:30pm', '6-Oct-2010', 'Medical Consultant', 'Consultation', 'Waiting', '05-Oct-2010', '2010-10-05 16:10:22'),
(4, 'UUTH/2010/15210', 'Non-referenced Patient', 'General Practice', '7-Oct-2010 at 6:30pm', '7-Oct-2010', 'Medical Consultant', 'General examination', 'Waiting', '07-Oct-2010', '2010-10-07 18:20:32'),
(5, 'UUTH/2010/27364', 'Non-referenced Patient', 'General Practice', '7-Oct-2010 at 10:00pm', '7-Oct-2010', 'Medical Consultant', 'Check-up', 'Waiting', '07-Oct-2010', '2010-10-07 19:57:18'),
(6, 'UUTH/2010/15307', 'Non-referenced Patient', 'General Practice', '8-Oct-2010 at 08:00am', '8-Oct-2010', 'Medical Consultant', 'Consultation', 'Waiting', '08-Oct-2010', '2010-10-08 05:25:25'),
(7, 'UUTH/2010/20774', 'Non-referenced Patient', 'General Practice', '8-Oct-2010 at 8:30', '8-Oct-2010', 'Medical Consultant', 'Consultation', 'Waiting', '08-Oct-2010', '2010-10-08 11:41:39');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `password` varchar(25) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `department` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `user_id`, `password`, `sex`, `phone`, `email`, `department`, `timestamp`, `time`, `status`) VALUES
(1, 'Paulina Etim', 'Records', 'test', 'Female', '08039098042', 'pallyboys@yahoo.com', 'Records', '2010-09-09 17:46:40', '2011-01-28 13:00:30', 'AVAILABLE'),
(2, 'Chukwuemeka Kalu', 'Medical Consultant', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'General Practice', '2010-09-09 17:46:40', '2011-03-27 19:59:07', 'AVAILABLE'),
(3, 'Mercy Johnson', 'Pharmacist', 'test', 'Female', '08039098042', 'pallyboys@yahoo.com', 'Pharmacy', '2010-09-09 17:46:40', '2011-01-27 23:51:24', 'NOT AVAILABLE'),
(4, 'Rebecca Utakwu', 'Laboratory Staff', 'test', 'Female', '08039098042', 'pallyboys@yahoo.com', 'Pathology', '2010-09-09 17:46:40', '2011-01-26 16:46:12', 'NOT AVAILABLE'),
(5, 'Victor Essien', 'Accounts', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'Accounts', '2010-09-09 17:46:40', '2011-01-26 06:24:39', 'NOT AVAILABLE'),
(6, 'Okon Akpan', 'CMD', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'Management', '2010-09-09 17:48:02', '2011-03-27 19:49:51', 'NOT AVAILABLE'),
(7, 'Theresa Abang', 'Clinic Nurse', 'test', 'Female', '08039098042', 'pallyboys@yahoo.com', 'Nursing', '2010-09-10 23:28:10', '2011-01-27 23:34:11', 'NOT AVAILABLE'),
(8, 'Sylvester Okon', 'store officer', 'test', 'male', '08039098042', 'pallyboys@yahoo.com', 'Store', '2010-09-11 15:17:32', '0000-00-00 00:00:00', ''),
(9, 'Akan Udoette', 'Ward Nurse', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'Nursing', '2010-10-06 11:34:43', '2010-10-16 13:31:18', 'NOT AVAILABLE'),
(10, 'Okon Bassey', 'CMAC', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'General Health', '2010-10-06 13:12:34', '2011-03-27 19:54:47', 'NOT AVAILABLE'),
(11, 'Etim Asuquo', 'Chief Accountant', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'Accounts', '2010-10-06 13:12:34', '2011-01-26 06:54:23', 'NOT AVAILABLE'),
(12, 'Priscillia Effiong', 'Dir. of Pharmacy', 'test', 'Female', '08039098042', 'pallyboys@yahoo.com', 'Pharmacy', '2010-10-06 13:12:34', '2010-10-16 13:36:31', 'NOT AVAILABLE'),
(13, 'Monday Williams', 'Dir. of Planning', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'Planning', '2010-10-06 13:12:34', '0000-00-00 00:00:00', ''),
(14, 'Uduak Silas', 'Dir. of Nursing', 'test', 'Female', '08039098042', 'pallyboys@yahoo.com', 'Nursing', '2010-10-06 13:12:34', '2010-10-16 13:35:19', 'NOT AVAILABLE'),
(15, 'Essien Udoete', 'Ward Nurse', 'test', 'Female', '08039098042', 'pallyboys@yahoo.com', 'Nursing', '2010-10-08 08:03:18', '2010-10-16 13:31:18', 'NOT AVAILABLE'),
(16, 'Bassey Andem', 'Medical Consultant', 'test', 'Male', '08039098042', 'pallyboys@yahoo.com', 'General Practice', '2010-10-09 10:22:23', '2011-03-27 19:59:07', 'AVAILABLE'),
(17, 'Mary Udofia', 'Pharmacist', 'test', 'Female', '08039088020', 'pallyboys@yahoo.com', 'Pharmacy', '2010-10-09 10:22:23', '2011-01-27 23:51:24', 'NOT AVAILABLE'),
(18, 'Chris Inyang', 'Records', 'test', 'Male', '08039098020', 'pallyboys@yahoo.com', 'Records', '2010-10-09 10:22:23', '2011-01-28 13:00:30', 'AVAILABLE'),
(19, 'Inyang Otu', 'Laboratory Staff', 'test', 'Female', '0803908020', 'pallyboys@yahoo.com', 'Laboratory Staff', '2010-10-09 10:22:23', '2011-01-26 16:46:12', 'NOT AVAILABLE');

-- --------------------------------------------------------

--
-- Table structure for table `staff_reports`
--

CREATE TABLE IF NOT EXISTS `staff_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `report` text NOT NULL,
  `report_date` varchar(100) NOT NULL,
  `sent_to` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `staff_reports`
--

INSERT INTO `staff_reports` (`id`, `staff`, `date`, `report`, `report_date`, `sent_to`, `timestamp`) VALUES
(1, 'CMAC', '07-Oct-2010', 'hey sir', '01-Jan-2010', 'CMD', '2010-10-07 12:40:53'),
(2, 'Dir. Of Nursing', '07-Oct-2010', 'hey sir', '01-Jan-2010', 'CMAC', '2010-10-07 12:41:22'),
(3, 'Chief Accountant', '07-Oct-2010', 'hi', '01-Jan-2010', 'CMD', '2010-10-07 13:14:24'),
(4, 'Dir. Of Pharmacy', '07-Oct-2010', 'Love u sir', '01-Jan-2010', 'CMAC', '2010-10-07 13:17:02'),
(5, 'CMAC', '07-Oct-2010', 'Reports for yesterday', '6-Oct-2010', 'CMD', '2010-10-07 20:17:11');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE IF NOT EXISTS `store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `store`
--


-- --------------------------------------------------------

--
-- Table structure for table `vital_signs`
--

CREATE TABLE IF NOT EXISTS `vital_signs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(50) NOT NULL,
  `systole` varchar(20) NOT NULL,
  `diastole` varchar(20) NOT NULL,
  `pulse` varchar(20) NOT NULL,
  `temperature` varchar(10) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `oxygen` varchar(10) NOT NULL,
  `respiration` varchar(10) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `vital_signs`
--

INSERT INTO `vital_signs` (`id`, `hospital_no`, `systole`, `diastole`, `pulse`, `temperature`, `weight`, `height`, `oxygen`, `respiration`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/31124', '2', '3', '1(Regular,', '4', '70', '1', '1', '1', '22-Sep-2010', '2010-09-22 06:44:04'),
(2, 'UUTH/2010/6416', '2', '3', '12(Regular,Normal)', '12', '70', '1', '1', '1', '22-Sep-2010', '2010-09-22 06:45:26'),
(3, 'UUTH/2010/15269', '8', '9', '7(Regular,Normal)', '31', '67', '1', '67', '32', '26-Sep-2010', '2010-09-26 16:18:41'),
(4, 'UUTH/2010/32270', '122', '3', '12(Regular,Normal)', '1111', '70', '111', '67', '234', '05-Oct-2010', '2010-10-05 16:10:50'),
(5, 'UUTH/2010/15210', '10', '10', '12(Regular,Normal)', '35.7', '70', '1.67', '67', '32', '07-Oct-2010', '2010-10-07 18:19:46'),
(6, 'UUTH/2010/27364', '122', '10', '12(Regular,Normal)', '12', '67', '1.67', '67', '234', '07-Oct-2010', '2010-10-07 19:56:47'),
(7, 'UUTH/2010/15307', '122', '10', '12(Regular,Normal)', '35.7', '67', '1.67', '67', '234', '08-Oct-2010', '2010-10-08 05:24:52'),
(8, 'UUTH/2010/20774', '12', '12', '12(Regular,Normal)', '12', '12', '12', '12', '12', '08-Oct-2010', '2010-10-08 11:41:14');

-- --------------------------------------------------------

--
-- Table structure for table `wards`
--

CREATE TABLE IF NOT EXISTS `wards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `no_of_beds` varchar(100) NOT NULL,
  `no_of_patients` varchar(100) NOT NULL,
  `no_of_nurses` varchar(100) NOT NULL,
  `nurses_on_duty` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `wards`
--

INSERT INTO `wards` (`id`, `name`, `no_of_beds`, `no_of_patients`, `no_of_nurses`, `nurses_on_duty`) VALUES
(1, 'A&E', '47', '-2', '10', '5'),
(2, 'Male Surgical', '30', '0', '10', '5'),
(3, 'Female Surgical', '20', '0', '10', '4'),
(4, 'Maternity', '21', '0', '10', '3'),
(5, 'Post Natal', '30', '0', '10', '2'),
(6, 'Labour', '32', '0', '10', '3'),
(7, 'Pediatric', '21', '0', '10', '3');

-- --------------------------------------------------------

--
-- Table structure for table `written_examination`
--

CREATE TABLE IF NOT EXISTS `written_examination` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `examination` varchar(25) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `written_examination`
--

INSERT INTO `written_examination` (`id`, `hospital_no`, `examination`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/15269', '10468.jpg', '15-Oct-2010', '2010-10-15 00:32:58'),
(2, 'UUTH/2010/15269', '4429.jpg', '15-Oct-2010', '2010-10-15 00:54:09'),
(3, 'UUTH/2010/15269', '1026.jpg', '15-Oct-2010', '2010-10-15 00:59:22'),
(4, 'UUTH/2010/15269', '29312.jpg', '15-Oct-2010', '2010-10-15 13:16:43'),
(5, 'UUTH/2010/15269', '5481.jpg', '15-Oct-2010', '2010-10-15 19:50:26');

-- --------------------------------------------------------

--
-- Table structure for table `written_prescription`
--

CREATE TABLE IF NOT EXISTS `written_prescription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `prescription` varchar(100) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `written_prescription`
--

INSERT INTO `written_prescription` (`id`, `hospital_no`, `prescription`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/15269', '19438.jpg', '15-Oct-2010', '2010-10-15 19:56:45');

-- --------------------------------------------------------

--
-- Table structure for table `written_procedure`
--

CREATE TABLE IF NOT EXISTS `written_procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `examination` varchar(100) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `written_procedure`
--

INSERT INTO `written_procedure` (`id`, `hospital_no`, `examination`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/15307', '', '', '2010-10-15 20:12:26'),
(2, 'UUTH/2010/23843', '', '15-Oct-2010', '2010-10-15 20:15:00'),
(3, 'UUTH/2010/31124', '20300.jpg', '15-Oct-2010', '2010-10-15 20:23:57');

-- --------------------------------------------------------

--
-- Table structure for table `written_results`
--

CREATE TABLE IF NOT EXISTS `written_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_no` varchar(100) NOT NULL,
  `results` varchar(100) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `written_results`
--

INSERT INTO `written_results` (`id`, `hospital_no`, `results`, `date_added`, `timestamp`) VALUES
(1, 'UUTH/2010/15269', '1463.jpg', '15-Oct-2010', '2010-10-15 21:10:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
