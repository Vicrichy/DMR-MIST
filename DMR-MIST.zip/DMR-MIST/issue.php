<?php

session_start();
$hospital_no = $_POST['hospital_no'];

include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist!");
window.location = "pharmacist_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');

$sql2 = mysql_query("SELECT `hospital_no` FROM `prescribtion` WHERE `hospital_no` = '$hospital_no'");

$num_rows2 = @mysql_num_rows($sql2);

if($num_rows2==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number has no prescribtion!");
window.location = "pharmacist_page.php";
</script>
<?php
exit();
}

include('dbconnect.php');

mysql_query("UPDATE `prescribtions` SET `status` = 'ISSUED' WHERE `hospital_no` = '$hospital_no'");

 include('dbconnect.php');
 mysql_query("UPDATE `prescribtion` SET `status` = 'DISPENSED' WHERE `hospital_no` = '$hospital_no'");
?>
<script type="text/javascript">
alert("Prescription Items Successfully issued");
window.location = "pharmacist_page.php";
</script> 