<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$ward = $_POST['ward'];
$bed = $_POST['bed'];
$purpose = $_POST['purpose'];
$next_of_kin = $_POST['next_of_kin'];
$amount_paid = $_POST['amount_paid'];
$tech_fee = $_POST['tech_fee'];
$ad_fee = $_POST['ad_fee'];
$payment_purpose = "$tech_fee, $ad_fee";

$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

include('dbconnect.php');
$check = mysql_query("SELECT `admission` FROM `examination` WHERE `hospital_no` = '$hospital_no' AND `admission` = 'YES'");

$num_rows2 = @mysql_num_rows($check);
if($num_rows2 ==0)
{
?>
<script type="text/javascript">
alert("ERROR: Patient Has not been recommended for admission");
window.location = "ward_nurse_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `patients` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows==0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry Hospital Number does not exist! Please try again");
window.location = "ward_nurse_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');
$sql3 = mysql_query("SELECT `bed` FROM `wards` WHERE `bed` = '$bed' AND `ward` = '$ward'");

$num_rows3 = @mysql_num_rows($sql3);
if($num_rows3 >0)
{
?>
<script type="text/javascript">
alert("ERROR: Bed already occupied");
window.location = "ward_nurse_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');
$sql2 = mysql_query("SELECT `hospital_no`,`ward` FROM `admission` WHERE `hospital_no` = '$hospital_no' AND `ward` = '$ward'");

$num_rows2 = @mysql_num_rows($sql2);
if($num_rows2 >0)
{
?>
<script type="text/javascript">
alert("ERROR: Multiple cases of patient admission");
window.location = "ward_nurse_page.php";
</script>
<?php
}
else
{
include('dbconnect.php');
$ag = mysql_query("SELECT `doctor_incharge` FROM `patients` WHERE `hospital_no` = '$hospital_no'");
$doctor = @mysql_result($ag, 0, "doctor_incharge");
include('dbconnect.php');
mysql_query("INSERT INTO admission(hospital_no,ward,bed,doctor_incharge,purpose,next_of_kin,amount_paid,payment_purpose,date_added)VALUES('$hospital_no','$ward','$bed','$doctor','$purpose','$next_of_kin','$amount_paid','$payment_purpose','$date_added')") or die("Error");

$section = "$ward ward";
mysql_query("INSERT INTO `accounts` SET `hospital_no` = '$hospital_no', `item` = 'REGISTRATION FEE', `amount` = '$amount_paid', `status` = 'PAID', `date_added` = '$date_added',`section` = '$section'") or die("Fatal Error");
include('dbconnect.php');
$vik = mysql_query("SELECT `no_of_beds` FROM `wards` WHERE `name` = '$ward'");
$no_of_beds = @mysql_result($vik, 0, "no_of_beds");
$no_of_beds = $no_of_beds - 1;

include('dbconnect.php');
$viky = mysql_query("SELECT `no_of_patients` FROM `wards` WHERE `name` = '$ward'");
$no_of_patients = @mysql_result($viky, 0, "no_of_patients");
$no_of_patients = $no_of_patients + 1;

mysql_query("UPDATE `wards` SET `no_of_beds` = '$no_of_beds', `no_of_patients` = '$no_of_patients' WHERE `name` = '$ward'");
}
include('dbconnect.php');
mysql_query("UPDATE `patients` SET `admission` = 'YES' WHERE `hospital_no` = '$hospital_no'")or die("Error");
?>
<script type="text/javascript">
alert("Patient Admission Record Added");
window.location = "ward_nurse_page.php";
</script>