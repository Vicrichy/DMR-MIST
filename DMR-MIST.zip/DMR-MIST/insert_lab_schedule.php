<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$time = $_POST['time'];
$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];
$procedures = $_POST['procedures'];

$schedule = "$day-$month-$year at $time";
$schedule_date = "$day-$month-$year";
include('dbconnect.php');
$ag = mysql_query("SELECT `hospital_no` FROM `procedures` WHERE `hospital_no` = '$hospital_no'");
$ag_status = @mysql_num_rows($ag);
if($ag_status ==0)
{
?>
<script type="text/javascript">
alert("ERROR: Patient record not found!");
window.location = "laboratory_page.php";
</script>
<?php
exit();
}
include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `procedures` WHERE `hospital_no` = '$hospital_no' AND `schedule` = '$schedule'");

$num_rows = @mysql_num_rows($sql);

if($num_rows>0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry this Hospital Number has already been scheduled!");
window.location = "laboratory_page.php";
</script>
<?php
exit();
}
mysql_query("UPDATE `procedures` SET `schedule` = '$schedule', `schedule_date` = '$schedule_date' WHERE `hospital_no` = '$hospital_no'") or die("Error");

?>
<script type="text/javascript">
alert("Patient Schedule Added");
window.location = "laboratory_page.php";
</script>