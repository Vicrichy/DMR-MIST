<?php
session_start();
$user_id = addslashes($_POST['user_id']);

$password = addslashes($_POST['password']);
$name = addslashes($_POST['name']);

$_SESSION['user_id1'] = addslashes($_POST['user_id1']);
$_SESSION['user_id2'] = addslashes($_POST['user_id2']);
$_SESSION['password'] = $password;
$_SESSION['name'] = $name;

if($_SESSION['user_id1'] != '')
{
header("location:ward_nurse_login.php");
exit();
}
if($_SESSION['user_id2'] != '')
{
header("location:management_login.php");
exit();
}

include('dbconnect.php');

$sql = mysql_query("SELECT * FROM `staff` WHERE `user_id`='$user_id'
AND `password`='$password' AND `name` = '$name'");

$num_rows = @mysql_num_rows($sql);

if($num_rows<1)
{
?>
<html>
<script type="text/javascript">
alert("INVALID USER ID OR PASSWORD!");
window.location = "index.php";
</script></html>
<?php 
}

else
{
$_SESSION['auth']= 3;

while($row = mysql_fetch_array($sql) )
{
  $_SESSION['name']= $row['name'];
  $_SESSION['user_id']= $row['user_id']; 
  $_SESSION['sex'] = $row['sex'];
  $_SESSION['phone'] = $row['phone'];
  $_SESSION['email'] = $row['email'];
  $_SESSION['department'] = $row['department'];
  $_SESSION['last_login'] = $row['time'];
}  
  include('dbconnect.php');  
  mysql_query("INSERT INTO login SET user_id = '$user_id', time = NOW(), name = '$_SESSION[name]'");
  mysql_query("UPDATE staff SET time = NOW(), status = 'AVAILABLE' WHERE `user_id` = '$user_id' AND `password` = '$password'");

if($user_id == 'Records')
{
 header("location:registration_staff_page.php");
}
elseif($user_id == 'Medical Consultant')
{
 header("location:medical_consultant_page.php");
}
elseif($user_id == 'Pharmacist')
{
 header("location:pharmacist_page.php");
}
elseif($user_id == 'Laboratory Staff')
{
 header("location:laboratory_page.php");
}
elseif($user_id == 'Accounts')
{
 header("location:accounts_page.php");
}
elseif($user_id == 'Management')
{
 header("location:management_page.php");
}
elseif($user_id == 'Nursing Officer')
{
 header("location:nurse_page.php");
}
elseif($user_id == 'Store Officer')
{
 header("location:store_page.php");
}
else
{ 
header("location:index.php");
exit();
}
}
?>  