<?php

session_start();

$hospital_no = $_POST['hospital_no'];
$reference = $_POST['reference'];
$service = $_POST['service'];
$medical_personnel = $_POST['medical_personnel'];
$purpose = $_POST['purpose'];
$month = date("M");
$day = date("d");
$year = date("Y");

$date_added = "$day-$month-$year";

$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];
$time = $_POST['time'];

$schedule = "$day-$month-$year at $time";
$schedule_date = "$day-$month-$year";
include('dbconnect.php');

$sql = mysql_query("SELECT `hospital_no` FROM `schedule` WHERE `hospital_no` = '$hospital_no'");

$num_rows = @mysql_num_rows($sql);

if($num_rows>0)
{
?>
<script type="text/javascript">
alert("ERROR: Sorry this Hospital Number has already been scheduled!");
window.location = "nurse_page.php";
</script>
<?php
exit();
}
mysql_query("INSERT INTO  schedule(hospital_no,reference,service,schedule,date,medical_personnel,purpose,date_added)VALUES('$hospital_no','$reference','$service','$schedule','$schedule_date','$medical_personnel','$purpose','$date_added')") or die("Error");

?>
<script type="text/javascript">
alert("Patient Schedule Added");
window.location = "nurse_page.php";
</script>